import _defineProperty from "@oxc-project/runtime/helpers/defineProperty";
/* THIS FILE IS GENERATED - DO NOT EDIT */
async function QuickJS(moduleArg = {}) {
	var moduleRtn;
	var e = moduleArg, aa = import.meta.url, h = "", m;
	try {
		h = new URL(".", aa).href;
	} catch (_unused) {}
	m = async (a) => {
		a = await fetch(a, { credentials: "same-origin" });
		if (a.ok) return a.arrayBuffer();
		throw Error(a.status + " : " + a.url);
	};
	var q = console.error.bind(console), r, t = !1, u, v, w, x = !1;
	function y() {
		var a = z.buffer;
		A = new Int8Array(a);
		new Int16Array(a);
		B = new Uint8Array(a);
		new Uint16Array(a);
		C = new Int32Array(a);
		D = new Uint32Array(a);
		new Float32Array(a);
		new Float64Array(a);
		new BigInt64Array(a);
		new BigUint64Array(a);
	}
	function E(a) {
		var _e$onAbort;
		(_e$onAbort = e.onAbort) === null || _e$onAbort === void 0 ? void 0 : _e$onAbort.call(e, a);
		a = `Aborted(${a})`;
		q(a);
		t = !0;
		a = new WebAssembly.RuntimeError(a + ". Build with -sASSERTIONS for more info.");
		w === null || w === void 0 ? void 0 : w(a);
		throw a;
	}
	var F;
	async function ba(a) {
		if (!r) try {
			var b = await m(a);
			return new Uint8Array(b);
		} catch (_unused2) {}
		if (a == F && r) a = new Uint8Array(r);
		else throw "both async and sync fetching of the wasm failed";
		return a;
	}
	async function ca(a, b) {
		try {
			var c = await ba(a);
			return await WebAssembly.instantiate(c, b);
		} catch (d) {
			q(`failed to asynchronously prepare wasm: ${d}`), E(d);
		}
	}
	async function da(a) {
		var b = F;
		if (!r) try {
			var c = fetch(b, { credentials: "same-origin" });
			return await WebAssembly.instantiateStreaming(c, a);
		} catch (d) {
			q(`wasm streaming compile failed: ${d}`), q("falling back to ArrayBuffer instantiation");
		}
		return ca(b, a);
	}
	class G {
		constructor(a) {
			_defineProperty(this, "name", "ExitStatus");
			this.message = `Program terminated with exit(${a})`;
			this.status = a;
		}
	}
	var C, A, D, B, H = (a) => {
		for (; a.length > 0;) a.shift()(e);
	}, I = [], J = [], ea = () => {
		var a = e.preRun.shift();
		J.push(a);
	}, K = !0, L = 0, fa = [
		0,
		31,
		60,
		91,
		121,
		152,
		182,
		213,
		244,
		274,
		305,
		335
	], ha = [
		0,
		31,
		59,
		90,
		120,
		151,
		181,
		212,
		243,
		273,
		304,
		334
	], M = {}, N = (a) => {
		if (!(a instanceof G || a == "unwind")) throw a;
	}, O = (a) => {
		var _e$onExit;
		u = a;
		K || L > 0 || ((_e$onExit = e.onExit) === null || _e$onExit === void 0 ? void 0 : _e$onExit.call(e, a), t = !0);
		throw new G(a);
	}, ia = (a) => {
		if (!t) try {
			a();
		} catch (b) {
			N(b);
		} finally {
			if (!(K || L > 0)) try {
				u = a = u, O(a);
			} catch (b) {
				N(b);
			}
		}
	}, P = (a, b, c) => {
		var d = B;
		if (c > 0) {
			c = b + c - 1;
			for (var g = 0; g < a.length; ++g) {
				var f = a.codePointAt(g);
				if (f <= 127) {
					if (b >= c) break;
					d[b++] = f;
				} else if (f <= 2047) {
					if (b + 1 >= c) break;
					d[b++] = 192 | f >> 6;
					d[b++] = 128 | f & 63;
				} else if (f <= 65535) {
					if (b + 2 >= c) break;
					d[b++] = 224 | f >> 12;
					d[b++] = 128 | f >> 6 & 63;
					d[b++] = 128 | f & 63;
				} else {
					if (b + 3 >= c) break;
					d[b++] = 240 | f >> 18;
					d[b++] = 128 | f >> 12 & 63;
					d[b++] = 128 | f >> 6 & 63;
					d[b++] = 128 | f & 63;
					g++;
				}
			}
			d[b] = 0;
		}
	}, ja = new TextDecoder(), Q = (a) => {
		if (a) {
			for (var b = a, c = B, d = b + void 0; c[b] && !(b >= d);) ++b;
			a = ja.decode(B.subarray(a, b));
		} else a = "";
		return a;
	}, R = (a) => {
		for (var b = 0, c = 0; c < a.length; ++c) {
			var d = a.charCodeAt(c);
			d <= 127 ? b++ : d <= 2047 ? b += 2 : d >= 55296 && d <= 57343 ? (b += 4, ++c) : b += 3;
		}
		return b;
	}, T = (a) => {
		var b = R(a) + 1, c = S(b);
		c && P(a, c, b);
		return c;
	};
	function U() {}
	var la = (a, b, c, d) => {
		var g = {
			string: (k) => {
				var n = 0;
				if (k !== null && k !== void 0 && k !== 0) {
					n = R(k) + 1;
					var X = V(n);
					P(k, X, n);
					n = X;
				}
				return n;
			},
			array: (k) => {
				var n = V(k.length);
				A.set(k, n);
				return n;
			}
		};
		a = e["_" + a];
		var f = [], p = 0;
		if (d) for (var l = 0; l < d.length; l++) {
			var Y = g[c[l]];
			Y ? (p === 0 && (p = W()), f[l] = Y(d[l])) : f[l] = d[l];
		}
		c = a(...f);
		return c = function(k) {
			p !== 0 && ka(p);
			return b === "string" ? Q(k) : b === "boolean" ? !!k : k;
		}(c);
	};
	U = (a, b, c) => {
		a = Q(a);
		b = b !== null ? JSON.parse(Q(b)) : [];
		try {
			let d = e.externalCall(a, b);
			return d ? T(d) : null;
		} catch (d) {
			return e.HEAPU8[c] = 1, T(d.message);
		}
	};
	e.noExitRuntime && (K = e.noExitRuntime);
	e.printErr && (q = e.printErr);
	e.wasmBinary && (r = e.wasmBinary);
	if (e.preInit) for (typeof e.preInit == "function" && (e.preInit = [e.preInit]); e.preInit.length > 0;) e.preInit.shift()();
	e.ccall = la;
	e.cwrap = (a, b, c, d) => {
		var g = !c || c.every((f) => f === "number" || f === "boolean");
		return b !== "string" && g && !d ? e["_" + a] : (...f) => la(a, b, c, f, d);
	};
	e.stringToNewUTF8 = T;
	var S, ma, ka, V, W, z, na = {
		e: () => E(""),
		a: () => {
			K = !1;
			L = 0;
		},
		b: function(a, b) {
			a = a < -9007199254740992 || a > 9007199254740992 ? NaN : Number(a);
			a = new Date(a * 1e3);
			C[b >> 2] = a.getSeconds();
			C[b + 4 >> 2] = a.getMinutes();
			C[b + 8 >> 2] = a.getHours();
			C[b + 12 >> 2] = a.getDate();
			C[b + 16 >> 2] = a.getMonth();
			C[b + 20 >> 2] = a.getFullYear() - 1900;
			C[b + 24 >> 2] = a.getDay();
			var c = a.getFullYear();
			C[b + 28 >> 2] = (c % 4 !== 0 || c % 100 === 0 && c % 400 !== 0 ? ha : fa)[a.getMonth()] + a.getDate() - 1 | 0;
			C[b + 36 >> 2] = -(a.getTimezoneOffset() * 60);
			c = new Date(a.getFullYear(), 6, 1).getTimezoneOffset();
			var d = new Date(a.getFullYear(), 0, 1).getTimezoneOffset();
			C[b + 32 >> 2] = (c != d && a.getTimezoneOffset() == Math.min(d, c)) | 0;
		},
		i: (a, b) => {
			M[a] && (clearTimeout(M[a].id), delete M[a]);
			if (!b) return 0;
			var c = setTimeout(() => {
				delete M[a];
				ia(() => ma(a, performance.now()));
			}, b);
			M[a] = {
				id: c,
				A: b
			};
			return 0;
		},
		c: (a, b, c, d) => {
			var g = new Date().getFullYear(), f = new Date(g, 0, 1).getTimezoneOffset();
			g = new Date(g, 6, 1).getTimezoneOffset();
			D[a >> 2] = Math.max(f, g) * 60;
			C[b >> 2] = Number(f != g);
			b = (p) => {
				var l = Math.abs(p);
				return `UTC${p >= 0 ? "-" : "+"}${String(Math.floor(l / 60)).padStart(2, "0")}${String(l % 60).padStart(2, "0")}`;
			};
			a = b(f);
			b = b(g);
			g < f ? (P(a, c, 17), P(b, d, 17)) : (P(a, d, 17), P(b, c, 17));
		},
		g: U,
		f: function(a, b) {
			a = Q(a);
			try {
				var c = window.JSON.parse(a);
			} catch (d) {
				c = a;
			}
			b !== 0 ? window.alert(a) : window.console.log("DUMP", c);
		},
		d: () => Date.now(),
		j: (a) => {
			var b = B.length;
			a >>>= 0;
			if (a > 2147483648) return !1;
			for (var c = 1; c <= 4; c *= 2) {
				var d = b * (1 + .2 / c);
				d = Math.min(d, a + 100663296);
				a: {
					d = (Math.min(2147483648, Math.ceil(Math.max(a, d) / 65536) * 65536) - z.buffer.byteLength + 65535) / 65536 | 0;
					try {
						z.grow(d);
						y();
						var g = 1;
						break a;
					} catch (f) {}
					g = void 0;
				}
				if (g) return !0;
			}
			return !1;
		},
		m: function(a) {
			a = Q(a);
			window.console.log(a);
		},
		h: function(a) {
			a = Q(a);
			return Date.parse(a);
		},
		l: function(a, b, c, d) {
			a = Q(a);
			b = Q(b);
			c = Q(c);
			c = `Quickjs -- ${a}: ${b}\n${c}`;
			d !== 0 ? window.alert(c) : window.console.error(c);
		},
		k: O
	}, Z;
	Z = await async function() {
		var _F;
		function a(c) {
			c = Z = c.exports;
			e._evalInSandbox = c.p;
			e._nukeSandbox = c.q;
			e._init = c.r;
			e._commFun = c.s;
			e._dumpMemoryUse = c.t;
			S = c.u;
			e._free = c.v;
			ma = c.w;
			ka = c.x;
			V = c.y;
			W = c.z;
			z = c.n;
			y();
			return Z;
		}
		var b = { a: na };
		if (e.instantiateWasm) return new Promise((c) => {
			e.instantiateWasm(b, (d, g) => {
				c(a(d, g));
			});
		});
		(_F = F) !== null && _F !== void 0 ? _F : F = e.locateFile ? e.locateFile ? e.locateFile("quickjs-eval.wasm", h) : h + "quickjs-eval.wasm" : new URL("quickjs-eval.wasm", import.meta.url).href;
		return function(c) {
			return a(c.instance);
		}(await da(b));
	}();
	(function() {
		function a() {
			e.calledRun = !0;
			if (!t) {
				var _e$onRuntimeInitializ;
				x = !0;
				Z.o();
				v === null || v === void 0 ? void 0 : v(e);
				(_e$onRuntimeInitializ = e.onRuntimeInitialized) === null || _e$onRuntimeInitializ === void 0 ? void 0 : _e$onRuntimeInitializ.call(e);
				if (e.postRun) for (typeof e.postRun == "function" && (e.postRun = [e.postRun]); e.postRun.length;) {
					var b = e.postRun.shift();
					I.push(b);
				}
				H(I);
			}
		}
		if (e.preRun) for (typeof e.preRun == "function" && (e.preRun = [e.preRun]); e.preRun.length;) ea();
		H(J);
		e.setStatus ? (e.setStatus("Running..."), setTimeout(() => {
			setTimeout(() => e.setStatus(""), 1);
			a();
		}, 1)) : a();
	})();
	x ? moduleRtn = e : moduleRtn = new Promise((a, b) => {
		v = a;
		w = b;
	});
	;
	return moduleRtn;
}
export default QuickJS;
