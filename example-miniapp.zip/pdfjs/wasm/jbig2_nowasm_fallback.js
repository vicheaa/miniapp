import _defineProperty from "@oxc-project/runtime/helpers/defineProperty";
/* THIS FILE IS GENERATED - DO NOT EDIT */
async function JBig2(moduleArg = {}) {
	var Module = moduleArg;
	var ENVIRONMENT_IS_WEB = true;
	var ENVIRONMENT_IS_WORKER = false;
	var programArgs = [];
	var thisProgram = "./this.program";
	var quit_ = (status, toThrow) => {
		throw toThrow;
	};
	var _scriptName = import.meta.url;
	var scriptDirectory = "";
	var readAsync;
	if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
		try {
			scriptDirectory = new URL(".", _scriptName).href;
		} catch (_unused) {}
		{
			readAsync = async (url) => {
				var response = await fetch(url, { credentials: "same-origin" });
				if (response.ok) {
					return response.arrayBuffer();
				}
				throw new Error(response.status + " : " + response.url);
			};
		}
	} else {}
	var out = console.log.bind(console);
	var err = console.error.bind(console);
	var wasmBinary;
	var WebAssembly = {
		Memory: function(opts) {
			this.buffer = new ArrayBuffer(opts["initial"] * 65536);
		},
		Module: function(binary) {},
		Instance: function(module, info) {
			this.exports = (
			// EMSCRIPTEN_START_ASM
function instantiate(ha) {
				var a;
				var b = new Uint8Array(123);
				for (var c = 25; c >= 0; --c) {
					b[48 + c] = 52 + c;
					b[65 + c] = c;
					b[97 + c] = 26 + c;
				}
				b[43] = 62;
				b[47] = 63;
				function i(j, k, l) {
					var d, e, c = 0, f = k, g = l.length, h = k + (g * 3 >> 2) - (l[g - 2] == "=") - (l[g - 1] == "=");
					for (; c < g; c += 4) {
						d = b[l.charCodeAt(c + 1)];
						e = b[l.charCodeAt(c + 2)];
						j[f++] = b[l.charCodeAt(c)] << 2 | d >> 4;
						if (f < h) j[f++] = d << 4 | e >> 2;
						if (f < h) j[f++] = e << 6 | b[l.charCodeAt(c + 3)];
					}
					return j;
				}
				function m(n) {
					i(a, 1024, "TjdmeGNvZGVjMTVTY2FubGluZURlY29kZXJFAAAAAAAAAAAGBwIACAMACwQADAUADgYADwcABgcKAAgLABKAABMIABQJABtAAAkDDQAHAQAIDAAXwAAYgAYqEAArEQA0DgA1DwAMAxYABBcACBQADBMAExoAFxUAGBwAJBsAJxIAKBgAKxkANwABKgIdAAMeAAQtAAUuAAovAAswABIhABMiABQjABUkABYlABcmABofABsgACQ1ACU2ACgnACkoACopACsqACwrAC0sADI9ADM+ADQ/ADUAADZAATeAAUo7AEs8AFIxAFMyAFQzAFU0AFg3AFk4AFo5AFs6AGTAAWUAAmeAAmhAAhCYwAWZAAaaQAabwAbMwALNAAPSQAPTgAPUwAPVAATWQATXgATYwATZAAXaQAXbgAUAAwgABwxABw2ABwoSwAcTAAgUQAgVgAgWwAgXAAkcQAkdgAkewAkfAAr/");
					i(a, 1393, "AgIDAAMCAAICAQADBAACAgYAAwUAAQMHAAIECQAFCAADBAoABQsABwwAAgQNAAcOAAEYDwAFCBIAD0AAFxAAGBEANwAACggABwxABw2ABxcYABgZACgXADcWAGcTAGgUAGwVADYSwAcTAAgUQAgVgAgWwAgXAAkcQAkdgAkewAkfAAokNAAnNwAoOAArOwAsPAAzQAE0gAE1wAE3NQA4NgBSMgBTMwBULABVLQBWLgBXLwBYOQBZOgBaPQBbAAFkMABlMQBmPgBnPwBoHgBpHwBqIABrIQBsKABtKQDIgADJwADKGgDLGwDMHADNHQDSIgDTIwDUJADVJQDWJgDXJwDaKgDbKwAUSoACS8ACTAADTUADUgAFU0AFVIAFVcAFWgAGW0AGZIAGZcAGbAACbUACcoADc8ADdAAEdUAEdoAEd8AE/wAAAAAAANQGAAAMAAAADQAAAA4AAAAPAAAAEAAAAAgWAADgBgAACAcAAE43Znhjb2RlYzEyX0dMT0JBTF9fTl8xMTBGYXhEZWNvZGVyRQAAAADQFQAAAAQAAAFWAQEBAAE0AgYAAAEYAwkAAMEKBAwAACEFBR0AACECJiEAAAFWBwYBAAFUCA4AAAFICQ4AAAE4Cg4AAAEwCxEAAAEkDBIAAAEcDRQAAAEWHRUAAAFWDw4BAAFUEA4AAAFREQ8AAAFIEhAAAAE4ExEAAAE0FBIAAAEwFRMAAAEoFhMAAAEkFxQAAAEiGBUAAAEcGRYAAAEYGhcAAAEWGxgAAAEUHBkAAAESHRoAAAERHhsAAMEKHxwAAMEJIB0AAKEIIR4AACEFIh8AAEEEIyAAAKECJCEAACECJSIAAEEBJiMAABEBJyQAAIUAKCUAAEkAKSYAACUAKicAABUAKygAAAkALCkAAAUALSoAAAEALSsAAAFWLi4AAAAAAgAAAAAAAAAEAAAABAAAAAYAAAAUAAAACAAAAFQAAAAMAAAAVAEAACAAAABUEQAAJZsAAPd7AAAAAAAA8AcAABAAAAAGAAAAAPgAAAAIAACVBwAA+w4AAAEAAAD4AQAACAAAAAQAAAAAHgAAAAIAAOUAAAC9AQAAAwAAAHwAAAAEAAAAAQAAAIADAACAAAAAAAAAAOgIAAARAAAAEgAAABMAAAAUAAAAFQAAABYAAAAXAAAAGAAAABkAAAAIFgAA9AgAAGQJAABOU3QzX18yMTBfX2Z1bmN0aW9uNl9fZnVuY0lNMTRDSkJpZzJfR1JEUHJvY0YxNEZYQ09ERUNfU1RBVFVTUE5TMl8yN1Byb2dyZXNzaXZlQXJpdGhEZWNvZGVTdGF0ZUVFRlMzX1JTMl9TNV9FRUUA0BUAAGwJAABOU3QzX18yMTBfX2Z1bmN0aW9uNl9fYmFzZUlGMTRGWENPREVDX1NUQVRVU1IxNENKQmlnMl9HUkRQcm9jUE5TM18yN1Byb2dyZXNzaXZlQXJpdGhEZWNvZGVTdGF0ZUVFRUUA4BQAAOQJAAAAAAAALAoAAHgKAABNMTRDSkJpZzJfR1JEUHJvY0YxNEZYQ09ERUNfU1RBVFVTUE5TXzI3UHJvZ3Jlc3NpdmVBcml0aERlY29kZVN0YXRlRUUAAACQFAAANAoAAEYxNEZYQ09ERUNfU1RBVFVTUE4xNENKQmlnMl9HUkRQcm9jMjdQcm9ncmVzc2l2ZUFyaXRoRGVjb2RlU3RhdGVFRQAA0BUAAIAKAAAxNENKQmlnMl9HUkRQcm9j");
					i(a, 2724, "YAsAAAUAAAABAAAAkAsAAAgAAAABAAAA0AsAAAkAAAAAAAAAIAwAAAcAAAAAAAAAYAwAAAgAAAAAAAAAoAwAAA4AAAAAAAAAEA0AAA8AAAABAAAAkA0AABUAAAABAAAAQA4AABYAAAABAAAA8A4AABUAAAAAAAAAoA8AAA4AAAAAAAAAEBAAAA4AAAAAAAAAgBAAAA4AAAAAAAAA8BAAAAcAAAAAAAAAMBEAAA0=");
					i(a, 2912, "AQQAAAAAAAACCAAAEAAAAAMQAAAQAQAAACAAAP////8DIAAAEAEB");
					i(a, 2960, "AQAAAAAAAAACAAAAAQAAAAMAAAACAAAABAMAAAMAAAAFBgAACwAAAAAgAAD/////BiAAAEsAAAAGAAAAAAAAAAgIAAAA////AQAAAAAAAAACAAAAAQAAAAMAAAACAAAABAMAAAMAAAAFBgAACwAAAAggAAD//v//ByAAAEsAAAAG");
					i(a, 3104, "AQAAAAEAAAACAAAAAgAAAAMAAAADAAAABAMAAAQAAAAFBgAADAAAAAAgAAD/////BSAAAEw=");
					i(a, 3168, "BwgAAAH///8BAAAAAQAAAAIAAAACAAAAAwAAAAMAAAAEAwAABAAAAAUGAAAMAAAAByAAAAD///8GIAAATAAAAAUKAAAA+P//BAkAAAD8//8ECAAAAP7//wQHAAAA////BQYAAID///8FBQAAwP///wQFAADg////AgcAAAAAAAADBwAAgAAAAAMIAAAAAQAABAkAAAACAAAECgAAAAQAAAYgAAD/9///BiAAAAAIAAAECQAAAPz//wMIAAAA/v//BAcAAAD///8FBgAAgP///wUFAADA////BAUAAOD///8EBQAAAAAAAAUFAAAgAAAABQYAAEAAAAAEBwAAgAAAAAMIAAAAAQAAAwkAAAACAAADCgAAAAQAAAUgAAD/+///BSAAAAAI");
					i(a, 3472, "CAMAAPH///8JAQAA+f///wgBAAD7////CQAAAP3///8HAAAA/v///wQAAAD/////AgEAAAAAAAAFAAAAAgAAAAYAAAADAAAAAwQAAAQAAAAGAQAAFAAAAAQEAAAWAAAABAUAACYAAAAFBgAARgAAAAUHAACGAAAABgcAAAYBAAAHCAAAhgEAAAYKAACGAgAACSAAAPD///8JIAAAhgYAAAI=");
					i(a, 3648, "CAQAAOH///8JAgAA8f///wgCAAD1////CQEAAPn///8HAQAA+////wQBAAD9////AwEAAP////8DAQAAAQAAAAUBAAADAAAABgEAAAUAAAADBQAABwAAAAYCAAAnAAAABAUAACsAAAAEBgAASwAAAAUHAACLAAAABQgAAAsBAAAGCAAACwIAAAcJAAALAwAABgsAAAsFAAAJIAAA4P///wkgAAALDQAAAgAAAAAAAAAHBAAA6////wgAAAD7////BwAAAPz///8FAAAA/f///wICAAD+////BQAAAAIAAAAGAAAAAwAAAAcAAAAEAAAACAAAAAUAAAACBgAABgAAAAUFAABGAAAABgUAAGYAAAAGBgAAhgAAAAYHAADGAAAABggAAEYBAAAGCQAARgIAAAYKAABGBAAABwsAAEYIAAAIIAAA6v///wggAABGEAAAAg==");
					i(a, 4e3, "AQAAAAEAAAACAQAAAgAAAAQAAAAEAAAABAEAAAUAAAAFAQAABwAAAAUCAAAJAAAABgIAAA0AAAAHAgAAEQAAAAcDAAAVAAAABwQAAB0AAAAHBQAALQAAAAcGAABNAAAAACAAAAAAAAAHIAAAjQAAAAEAAAABAAAAAgAAAAIAAAADAQAAAwAAAAUAAAAFAAAABQEAAAYAAAAGAQAACAAAAAcAAAAKAAAABwEAAAsAAAAHAgAADQAAAAcDAAARAAAABwQAABkAAAAIBQAAKQAAAAAgAAAAAAAACCAAAEkAAAABAAAAAQAAAAMAAAACAAAABAAAAAMAAAAFAAAABAAAAAQBAAAFAAAAAwMAAAcAAAAGAQAADwAAAAYCAAARAAAABgMAABUAAAAGBAAAHQAAAAYFAAAtAAAABwYAAE0AAAAAIAAAAAAAAAcgAACNAAAAAwAAAP7///8DAAAA/////wEAAAAAAAAAAwAAAAEAAAADAAAAAgAAAAAgAAD9////ACAAAAM=");
					i(a, 4400, "BwQAAOj///8GAgAA+P///wUBAAD8////BAAAAP7///8DAAAA/////wEAAAAAAAAAAwAAAAEAAAAEAAAAAgAAAAUBAAADAAAABgIAAAUAAAAHBAAACQAAAAcgAADn////ByAAABkAAABiYWRfdmFyaWFudF9hY2Nlc3MAdmVjdG9yAHN0ZDo6YmFkX2Z1bmN0aW9uX2NhbGwAYmFkX2FycmF5X25ld19sZW5ndGgAAAAaAAAAGwAAABwAAAAdAAAAHgAAAB8AAAAgAAAAIQAAAAAAAAAiAAAAIgAAACMAAAAjAAAAIwAAACMAAAAjAAAAIwAAACIAAAAiAAAAIwAAACIAAAAiAAAAIgAAACI=");
					i(a, 4704, "IwAAACMAAAAiAAAAIgAAAAAAAAAiAAAAAAAAACM=");
					i(a, 4872, "GBMAAAsAAAAkAAAAJQAAAAgWAAAkEwAAKBYAAE5TdDNfXzIxN2JhZF9mdW5jdGlvbl9jYWxsRQAAAAAAVBMAAAIAAAAmAAAAJwAAAAgWAABgEwAAKBYAAFN0MThiYWRfdmFyaWFudF9hY2Nlc3MAAAgWAACEEwAAwBUAAE4xMF9fY3h4YWJpdjExNl9fc2hpbV90eXBlX2luZm9FAAAAAAgWAAC0EwAAeBMAAE4xMF9fY3h4YWJpdjExN19fY2xhc3NfdHlwZV9pbmZvRQAAAAgWAADkEwAAeBMAAE4xMF9fY3h4YWJpdjExN19fcGJhc2VfdHlwZV9pbmZvRQAAAAgWAAAUFAAAeBMAAE4xMF9fY3h4YWJpdjEyMF9fZnVuY3Rpb25fdHlwZV9pbmZvRQAAAAAIFgAASBQAANgTAABOMTBfX2N4eGFiaXYxMjlfX3BvaW50ZXJfdG9fbWVtYmVyX3R5cGVfaW5mb0U=");
					i(a, 5248, "/////0RuAAAAAAAACBQAACgAAAApAAAAKgAAACsAAAAsAAAACBYAALAUAACoEwAATjEwX19jeHhhYml2MTIwX19zaV9jbGFzc190eXBlX2luZm9FAAAAAAAAAAA8FAAAKAAAAC0AAAAqAAAAKwAAAC4AAAAAAAAANBUAAAIAAAAvAAAAMAAAAFN0OWV4Y2VwdGlvbgAAAAAIFgAAJBUAACgWAABTdDliYWRfYWxsb2MAAAAACBYAAEAVAAAYFQAAU3QyMGJhZF9hcnJheV9uZXdfbGVuZ3RoAAAAAAAAAABwFQAAAQAAADEAAAAyAAAACBYAAHwVAAAoFgAAU3QxMWxvZ2ljX2Vycm9yAAAAAACgFQAAAQAAADMAAAAyAAAACBYAAKwVAABwFQAAU3QxMmxlbmd0aF9lcnJvcgAAAADQFQAA8BUAAAAAAACoEwAAKAAAADQAAAAqAAAAKwAAADUAAAA2AAAANwAAADgAAABTdDl0eXBlX2luZm8AAAAAAAAAAKQUAAAoAAAAOQAAACoAAAArAAAANQAAADoAAAA7AAAAPAAAANAVAAAIFQ==");
					i(a, 5680, "wBoBAL0=");
				}
				function o() {
					throw new Error("abort");
				}
				function p(q, r, s) {
					a.copyWithin(q, r, r + s);
				}
				function t(q, u, s) {
					q = q >>> 0;
					s = s >>> 0;
					if (q + s > a.length) throw "trap: invalid memory.fill";
					a.fill(u, q, q + s);
				}
				function ga(n) {
					var v = new ArrayBuffer(16777216);
					var w = new Int8Array(v);
					var x = new Int16Array(v);
					var y = new Int32Array(v);
					var z = new Uint8Array(v);
					var A = new Uint16Array(v);
					var B = new Uint32Array(v);
					var C = new Float32Array(v);
					var D = new Float64Array(v);
					var E = Math.imul;
					var F = Math.fround;
					var G = Math.abs;
					var H = Math.clz32;
					var I = Math.min;
					var J = Math.max;
					var K = Math.floor;
					var L = Math.ceil;
					var M = Math.trunc;
					var N = Math.sqrt;
					var O = n.a;
					var P = O.a;
					var Q = O.b;
					var R = O.c;
					var S = O.d;
					var T = O.e;
					var U = O.f;
					var V = O.g;
					var W = O.h;
					var X = O.i;
					var Y = 72384;
					var Z = 0;
					// EMSCRIPTEN_START_FUNCS
					function yc(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, q = 0, r = 0, s = 0, u = 0, v = 0, C = 0, D = 0, F = 0, G = 0, H = 0, I = 0, J = 0, K = 0, L = 0, M = 0, N = 0, O = 0, P = 0, Q = 0, R = 0, S = 0, T = 0, U = 0, V = 0, W = 0, X = 0, _ = 0, $ = 0, aa = 0, ba = 0, ca = 0, da = 0, ea = 0, fa = 0, ga = 0, ha = 0, Ia = 0, Ma = 0, Pa = 0, Qa = 0, Ta = 0, Xa = 0, Ya = 0, gb = 0, hb = 0, qb = 0, rb = 0, sb = 0, tb = 0, ub = 0;
						T = Y - 16 | 0;
						Y = T;
						b = y[a + 4 >> 2];
						c = y[b + 8 >> 2];
						b = y[b + 4 >> 2];
						i = b;
						a: {
							b: {
								c: {
									d: {
										e: {
											if (b >>> 0 < c >>> 0) {
												break e;
											}
											if ((b | 0) == (c | 0)) {
												sb = 2;
												break c;
											}
											ba = a + 80 | 0;
											while (1) {
												if (c >>> 0 > i >>> 0) {
													break e;
												}
												if (i - c >>> 0 < 11) {
													break c;
												}
												f: {
													g: {
														h: {
															n = y[ba >> 2];
															i: {
																if (!n) {
																	b = na(72);
																	w[b + 4 | 0] = 0;
																	y[b >> 2] = 0;
																	t(b + 8 | 0, 0, 64);
																	y[T + 4 >> 2] = 0;
																	eb(ba, b);
																	Vb(T + 4 | 0);
																	j: {
																		i = y[a + 80 >> 2];
																		k: {
																			if (qa(y[a + 4 >> 2], i)) {
																				break k;
																			}
																			if (wa(y[a + 4 >> 2], i + 4 | 0)) {
																				break k;
																			}
																			g = y[a + 4 >> 2];
																			d = y[g + 8 >> 2];
																			b = y[g >> 2];
																			l: {
																				m: {
																					if (B[g + 4 >> 2] <= d >>> 0) {
																						w[T + 15 | 0] = 0;
																						break m;
																					}
																					b = z[b + d | 0];
																					w[T + 15 | 0] = b;
																					if (b >>> 0 < 224) {
																						break m;
																					}
																					if (qa(g, i + 8 | 0)) {
																						break k;
																					}
																					c = y[i + 8 >> 2] & 536870911;
																					y[i + 8 >> 2] = c;
																					if (c >>> 0 > 64) {
																						break k;
																					}
																					d = y[a + 4 >> 2];
																					b = y[d + 8 >> 2];
																					g = b + (c + 8 >>> 3 | 0) | 0;
																					if (b >>> 0 > g >>> 0) {
																						break l;
																					}
																					b = y[d + 4 >> 2];
																					y[d + 8 >> 2] = b >>> 0 > g >>> 0 ? g : b;
																					break l;
																				}
																				if (wa(g, T + 15 | 0)) {
																					break k;
																				}
																				c = z[T + 15 | 0] >>> 5 | 0;
																				y[i + 8 >> 2] = c;
																			}
																			d = z[i + 4 | 0];
																			n: {
																				if (!c) {
																					break n;
																				}
																				b = y[i >> 2];
																				Rb(i + 12 | 0, c);
																				c = 0;
																				b = (b >>> 0 > 65536 ? 4 : b >>> 0 > 256 ? 2 : 1) - 1 | 0;
																				while (1) {
																					if (y[i + 8 >> 2] <= (c | 0)) {
																						break n;
																					}
																					o: {
																						p: {
																							switch (b - 1 | 0) {
																								default:
																									if (wa(y[a + 4 >> 2], T + 15 | 0)) {
																										break k;
																									}
																									n = z[T + 15 | 0];
																									y[y[i + 12 >> 2] + (c << 2) >> 2] = n;
																									break o;
																								case 0:
																									if (Sa(y[a + 4 >> 2], T + 12 | 0)) {
																										break k;
																									}
																									n = A[T + 12 >> 1];
																									y[y[i + 12 >> 2] + (c << 2) >> 2] = n;
																									break o;
																								case 1: break e;
																								case 2: break p;
																							}
																						}
																						if (qa(y[a + 4 >> 2], T + 8 | 0)) {
																							break k;
																						}
																						n = y[T + 8 >> 2];
																						y[y[i + 12 >> 2] + (c << 2) >> 2] = n;
																					}
																					c = c + 1 | 0;
																					if (B[i >> 2] > n >>> 0) {
																						continue;
																					}
																					break;
																				}
																				break k;
																			}
																			b = y[a + 4 >> 2];
																			q: {
																				if (!(d & 64)) {
																					if (wa(b, T + 15 | 0)) {
																						break k;
																					}
																					y[i + 24 >> 2] = z[T + 15 | 0];
																					break q;
																				}
																				if (qa(b, i + 24 | 0)) {
																					break k;
																				}
																			}
																			if (!qa(y[a + 4 >> 2], i + 28 | 0)) {
																				break j;
																			}
																		}
																		eb(ba, 0);
																		break i;
																	}
																	c = y[a + 4 >> 2];
																	b = y[c + 20 >> 2];
																	y[i + 40 >> 2] = y[c + 16 >> 2];
																	y[i + 44 >> 2] = b;
																	b = y[c + 8 >> 2];
																	y[i + 48 >> 2] = 1;
																	y[i + 36 >> 2] = b;
																	y[a + 84 >> 2] = b;
																	n = y[a + 80 >> 2];
																}
																r: {
																	while (1) {
																		g = 0;
																		m = 0;
																		c = 0;
																		f = Y - 304 | 0;
																		Y = f;
																		b = 2;
																		s: {
																			t: {
																				u: {
																					v: {
																						w: {
																							x: {
																								y: {
																									z: {
																										A: {
																											B: {
																												C: {
																													D: {
																														E: {
																															F: {
																																G: {
																																	H: {
																																		I: {
																																			J: {
																																				K: {
																																					L: {
																																						M: {
																																							N: {
																																								O: {
																																									P: {
																																										Q: {
																																											R: {
																																												S: {
																																													d = z[n + 4 | 0] & 63;
																																													switch (d - 16 | 0) {
																																														case 0: break R;
																																														case 1:
																																														case 2:
																																														case 3:
																																														case 5:
																																														case 8:
																																														case 9:
																																														case 10:
																																														case 11:
																																														case 12:
																																														case 13:
																																														case 14:
																																														case 15:
																																														case 16:
																																														case 17:
																																														case 18:
																																														case 19:
																																														case 21:
																																														case 25:
																																														case 28:
																																														case 29:
																																														case 30:
																																														case 31: break B;
																																														case 4:
																																														case 6:
																																														case 7: break Q;
																																														case 20:
																																														case 22:
																																														case 23: break P;
																																														case 24:
																																														case 26:
																																														case 27: break O;
																																														case 32: break N;
																																														case 33: break K;
																																														case 34: break J;
																																														case 35: break u;
																																														case 36: break I;
																																														case 37: break H;
																																														default: break S;
																																													}
																																												}
																																												T: {
																																													switch (d | 0) {
																																														case 0:
																																															b = 0;
																																															h = 0;
																																															q = 0;
																																															e = Y - 432 | 0;
																																															Y = e;
																																															c = 1;
																																															if (!Sa(y[a + 4 >> 2], e + 210 | 0)) {
																																																l = na(56);
																																																y[l + 40 >> 2] = 0;
																																																y[l + 32 >> 2] = 0;
																																																y[l + 36 >> 2] = 0;
																																																y[l + 24 >> 2] = 0;
																																																y[l + 28 >> 2] = 0;
																																																y[l + 16 >> 2] = 0;
																																																y[l + 20 >> 2] = 0;
																																																u = A[e + 210 >> 1];
																																																i = u & 1;
																																																w[l | 0] = i;
																																																g = u >>> 10 & 3;
																																																w[l + 3 | 0] = g;
																																																d = u & 12288;
																																																w[l + 2 | 0] = (d | 0) != 0;
																																																c = (u & 254) >>> 1 & 1;
																																																w[l + 1 | 0] = c;
																																																ga = l + 16 | 0;
																																																U: {
																																																	V: {
																																																		W: {
																																																			if (!i) {
																																																				i = g ? 2 : 8;
																																																				g = l + 44 | 0;
																																																				while (1) {
																																																					if ((b | 0) != (i | 0)) {
																																																						c = 1;
																																																						d = b + g | 0;
																																																						b = b + 1 | 0;
																																																						if (!wa(y[a + 4 >> 2], d)) {
																																																							continue;
																																																						}
																																																						break U;
																																																					}
																																																					break;
																																																				}
																																																				if (z[l + 1 | 0] != 1) {
																																																					break V;
																																																				}
																																																				if (!z[l + 2 | 0]) {
																																																					break W;
																																																				}
																																																				break V;
																																																			}
																																																			if (d | !c) {
																																																				break V;
																																																			}
																																																		}
																																																		g = l + 52 | 0;
																																																		b = 0;
																																																		while (1) {
																																																			if ((b | 0) == 4) {
																																																				break V;
																																																			}
																																																			c = 1;
																																																			d = b + g | 0;
																																																			b = b + 1 | 0;
																																																			if (!wa(y[a + 4 >> 2], d)) {
																																																				continue;
																																																			}
																																																			break;
																																																		}
																																																		break U;
																																																	}
																																																	c = 1;
																																																	if (qa(y[a + 4 >> 2], l + 12 | 0)) {
																																																		break U;
																																																	}
																																																	if (qa(y[a + 4 >> 2], l + 8 | 0) | B[l + 12 >> 2] > 1048576 | B[l + 8 >> 2] > 1048576) {
																																																		break U;
																																																	}
																																																	b = y[n + 8 >> 2];
																																																	k = (b | 0) > 0 ? b : 0;
																																																	b = 0;
																																																	while (1) {
																																																		if ((b | 0) == (k | 0)) {
																																																			I = 1;
																																																			b = 0;
																																																			while (1) if ((b | 0) == (k | 0)) {
																																																				X: {
																																																					Y: {
																																																						Z: {
																																																							_: {
																																																								$: {
																																																									aa: {
																																																										ba: {
																																																											ca: {
																																																												da: {
																																																													ea: {
																																																														fa: {
																																																															if (!(I & 1)) {
																																																																break fa;
																																																															}
																																																															y[l + 4 >> 2] = h;
																																																															gb = Kb(e + 196 | 0, h);
																																																															k = y[gb >> 2];
																																																															ga: {
																																																																if ((k | 0) == y[gb + 4 >> 2]) {
																																																																	break ga;
																																																																}
																																																																b = y[n + 8 >> 2];
																																																																d = (b | 0) > 0 ? b : 0;
																																																																I = 1;
																																																																h = 0;
																																																																g = 0;
																																																																while (1) {
																																																																	if ((d | 0) == (g | 0)) {
																																																																		break ga;
																																																																	}
																																																																	ha: {
																																																																		b = Ka(a, y[y[n + 12 >> 2] + (g << 2) >> 2]);
																																																																		if (z[b + 4 | 0] & 63) {
																																																																			break ha;
																																																																		}
																																																																		b = y[b + 56 >> 2];
																																																																		i = y[b + 24 >> 2];
																																																																		m = y[b + 28 >> 2] - i >> 2;
																																																																		b = 0;
																																																																		while (1) {
																																																																			if ((b | 0) == (m | 0)) {
																																																																				j = 0;
																																																																				i = 0;
																																																																				if (I & 1) {
																																																																					b = h + m | 0;
																																																																					c = b >>> 0 >= m >>> 0;
																																																																					j = c;
																																																																					i = c ? b : 0;
																																																																				}
																																																																				h = i;
																																																																				I = j;
																																																																				break ha;
																																																																			}
																																																																			c = b + h | 0;
																																																																			if (!(c >>> 0 >= b >>> 0 & I)) {
																																																																				break fa;
																																																																			}
																																																																			y[k + (c << 2) >> 2] = y[i + (b << 2) >> 2];
																																																																			b = b + 1 | 0;
																																																																			continue;
																																																																		}
																																																																	}
																																																																	g = g + 1 | 0;
																																																																	continue;
																																																																}
																																																															}
																																																															$a(ga, gb);
																																																															c = 1;
																																																															ia: {
																																																																if (z[l | 0] != 1) {
																																																																	break ia;
																																																																}
																																																																b = u >>> 2 & 3;
																																																																if ((b | 0) == 2) {
																																																																	break X;
																																																																}
																																																																d = u >>> 4 & 3;
																																																																if ((d | 0) == 2) {
																																																																	break X;
																																																																}
																																																																ja: {
																																																																	ka: {
																																																																		switch (b | 0) {
																																																																			case 0:
																																																																				I = ra(a, 4);
																																																																				b = 0;
																																																																				break ja;
																																																																			case 1:
																																																																				I = ra(a, 5);
																																																																				b = 0;
																																																																				break ja;
																																																																			default: break ka;
																																																																		}
																																																																	}
																																																																	b = Ga(a, n, 0);
																																																																	if (!b) {
																																																																		break X;
																																																																	}
																																																																	I = y[b + 68 >> 2];
																																																																	b = 1;
																																																																}
																																																																y[l + 28 >> 2] = I;
																																																																la: {
																																																																	ma: {
																																																																		switch (d | 0) {
																																																																			case 0:
																																																																				d = ra(a, 2);
																																																																				break la;
																																																																			case 1:
																																																																				d = ra(a, 3);
																																																																				break la;
																																																																			default: break ma;
																																																																		}
																																																																	}
																																																																	d = Ga(a, n, b);
																																																																	if (!d) {
																																																																		break X;
																																																																	}
																																																																	b = b + 1 | 0;
																																																																	d = y[d + 68 >> 2];
																																																																}
																																																																y[l + 32 >> 2] = d;
																																																																na: {
																																																																	if (!(u & 64)) {
																																																																		d = ra(a, 1);
																																																																		break na;
																																																																	}
																																																																	d = Ga(a, n, b);
																																																																	if (!d) {
																																																																		break X;
																																																																	}
																																																																	b = b + 1 | 0;
																																																																	d = y[d + 68 >> 2];
																																																																}
																																																																y[l + 36 >> 2] = d;
																																																																if (z[l + 1 | 0] != 1) {
																																																																	break ia;
																																																																}
																																																																oa: {
																																																																	if (!(u & 128)) {
																																																																		b = ra(a, 1);
																																																																		break oa;
																																																																	}
																																																																	b = Ga(a, n, b);
																																																																	if (!b) {
																																																																		break X;
																																																																	}
																																																																	b = y[b + 68 >> 2];
																																																																}
																																																																y[l + 40 >> 2] = b;
																																																															}
																																																															O = z[l + 1 | 0];
																																																															hb = z[l | 0];
																																																															c = z[l + 3 | 0];
																																																															b = z[l + 2 | 0];
																																																															y[e + 192 >> 2] = 0;
																																																															y[e + 184 >> 2] = 0;
																																																															y[e + 188 >> 2] = 0;
																																																															y[e + 180 >> 2] = 0;
																																																															y[e + 172 >> 2] = 0;
																																																															y[e + 176 >> 2] = 0;
																																																															g = b ? 1024 : 8192;
																																																															d = c ? (c | 0) == 1 ? 8192 : 1024 : 65536;
																																																															pa: {
																																																																if (!(!(u & 256) | !q)) {
																																																																	c = 1;
																																																																	if (!(hb & 1)) {
																																																																		b = Jb(e + 184 | 0, y[q + 56 >> 2]);
																																																																		if ((d | 0) != y[e + 188 >> 2] - y[b >> 2] >> 1) {
																																																																			break Y;
																																																																		}
																																																																	}
																																																																	if (!(O & 1)) {
																																																																		break pa;
																																																																	}
																																																																	b = Jb(e + 172 | 0, y[q + 56 >> 2] + 12 | 0);
																																																																	if ((g | 0) == y[e + 176 >> 2] - y[b >> 2] >> 1) {
																																																																		break pa;
																																																																	}
																																																																	break Y;
																																																																}
																																																																if (!(hb & 1)) {
																																																																	fb(e + 184 | 0, d);
																																																																}
																																																																if (!(O & 1)) {
																																																																	break pa;
																																																																}
																																																																fb(e + 172 | 0, g);
																																																															}
																																																															d = y[n + 44 >> 2];
																																																															k = d;
																																																															c = y[n + 40 >> 2];
																																																															y[e + 152 >> 2] = c;
																																																															y[e + 156 >> 2] = d;
																																																															i = y[n + 36 >> 2];
																																																															y[e + 160 >> 2] = i;
																																																															y[n + 52 >> 2] = 2;
																																																															qa: {
																																																																if (!(c | d) | z[a + 48 | 0] != 1) {
																																																																	break qa;
																																																																}
																																																																g = y[a + 108 >> 2];
																																																																b = g;
																																																																while (1) {
																																																																	b = y[b + 4 >> 2];
																																																																	if ((g | 0) == (b | 0)) {
																																																																		break qa;
																																																																	}
																																																																	if ((c | 0) != y[b + 8 >> 2] | (k | 0) != y[b + 12 >> 2] | (i | 0) != y[b + 16 >> 2]) {
																																																																		continue;
																																																																	}
																																																																	break;
																																																																}
																																																																c = Dd(y[b + 24 >> 2]);
																																																																y[e + 232 >> 2] = 0;
																																																																Ib(n + 56 | 0, c);
																																																																Va(e + 232 | 0);
																																																																Cd(y[a + 108 >> 2], e + 152 | 0, b + 24 | 0);
																																																																g = y[a + 108 >> 2];
																																																																d = y[b >> 2];
																																																																c = y[b + 4 >> 2];
																																																																y[d + 4 >> 2] = c;
																																																																y[c >> 2] = d;
																																																																y[g + 8 >> 2] = y[g + 8 >> 2] - 1;
																																																																pc(b);
																																																																break _;
																																																															}
																																																															if (!(hb & 1)) {
																																																																v = Na(y[a + 4 >> 2]);
																																																																y[e + 344 >> 2] = v;
																																																																g = y[e + 172 >> 2];
																																																																c = y[e + 176 >> 2];
																																																																b = y[e + 188 >> 2];
																																																																Q = y[e + 184 >> 2];
																																																																qb = Da();
																																																																y[e + 428 >> 2] = qb;
																																																																ca = Da();
																																																																y[e + 400 >> 2] = ca;
																																																																L = Da();
																																																																y[e + 396 >> 2] = L;
																																																																M = Da();
																																																																y[e + 392 >> 2] = M;
																																																																aa = Q + 810 | 0;
																																																																da = Q + 79434 | 0;
																																																																ha = Q + 3882 | 0;
																																																																Ma = Q + 458 | 0;
																																																																Pa = g;
																																																																ea = c - g >> 1;
																																																																Qa = Fd(e + 232 | 0, ib(y[l + 8 >> 2] + y[l + 4 >> 2] | 0));
																																																																Ia = cb(e + 416 | 0, y[l + 8 >> 2]);
																																																																R = b - Q >> 1;
																																																																Ta = R >>> 0 > 405;
																																																																Xa = R >>> 0 > 39717;
																																																																Ya = R >>> 0 > 1941;
																																																																rb = R >>> 0 > 229;
																																																																q = 0;
																																																																I = 0;
																																																																while (1) {
																																																																	ra: {
																																																																		sa: {
																																																																			ta: {
																																																																				b = y[l + 8 >> 2];
																																																																				if (b >>> 0 > I >>> 0) {
																																																																					y[e + 388 >> 2] = 0;
																																																																					Aa(qb, v, e + 384 | 0);
																																																																					q = y[e + 384 >> 2] + q | 0;
																																																																					if (q >>> 0 <= 65535) {
																																																																						fa = 0;
																																																																						while (1) {
																																																																							if (!Aa(ca, v, e + 380 | 0)) {
																																																																								break ra;
																																																																							}
																																																																							if (B[l + 8 >> 2] <= I >>> 0) {
																																																																								break ta;
																																																																							}
																																																																							fa = y[e + 380 >> 2] + fa | 0;
																																																																							if (fa >>> 0 > 65535) {
																																																																								break ta;
																																																																							}
																																																																							if (!(!q | !fa)) {
																																																																								ua: {
																																																																									va: {
																																																																										wa: {
																																																																											xa: {
																																																																												ya: {
																																																																													za: {
																																																																														Aa: {
																																																																															if (!z[l + 1 | 0]) {
																																																																																D = lb();
																																																																																y[e + 376 >> 2] = D;
																																																																																y[D + 8 >> 2] = q;
																																																																																y[D + 4 >> 2] = fa;
																																																																																w[D | 0] = 0;
																																																																																b = z[l + 3 | 0];
																																																																																w[D + 1 | 0] = 0;
																																																																																w[D + 2 | 0] = 0;
																																																																																w[D + 3 | 0] = b;
																																																																																w[D + 16 | 0] = z[l + 44 | 0];
																																																																																w[D + 17 | 0] = z[l + 45 | 0];
																																																																																w[D + 18 | 0] = z[l + 46 | 0];
																																																																																w[D + 19 | 0] = z[l + 47 | 0];
																																																																																w[D + 20 | 0] = z[l + 48 | 0];
																																																																																w[D + 21 | 0] = z[l + 49 | 0];
																																																																																w[D + 22 | 0] = z[l + 50 | 0];
																																																																																w[D + 23 | 0] = z[l + 51 | 0];
																																																																																U = D + 8 | 0;
																																																																																V = D + 4 | 0;
																																																																																Ba: {
																																																																																	switch (b | 0) {
																																																																																		case 0: break Ba;
																																																																																		case 1: break ya;
																																																																																		case 2: break za;
																																																																																		default: break Aa;
																																																																																	}
																																																																																}
																																																																																if (!Bd(D)) {
																																																																																	break xa;
																																																																																}
																																																																																C = ua(V, U);
																																																																																y[e + 212 >> 2] = C;
																																																																																if (!y[C + 16 >> 2]) {
																																																																																	break wa;
																																																																																}
																																																																																b = y[V >> 2];
																																																																																if (!b) {
																																																																																	break fa;
																																																																																}
																																																																																P = y[U >> 2] & 2147483647;
																																																																																b = b - 1 | 0;
																																																																																N = b >>> 3 | 0;
																																																																																W = (b & 7) + 1 | 0;
																																																																																b = 0;
																																																																																d = 0;
																																																																																h = 0;
																																																																																i = 0;
																																																																																u = 0;
																																																																																c = 0;
																																																																																while (1) {
																																																																																	m = d;
																																																																																	F = b;
																																																																																	Ca: {
																																																																																		Da: {
																																																																																			if ((u | 0) != (P | 0)) {
																																																																																				ja(e + 404 | 0, C, u);
																																																																																				b = y[e + 408 >> 2];
																																																																																				d = y[e + 404 >> 2];
																																																																																				if (z[D + 1 | 0] != 1) {
																																																																																					g = c;
																																																																																					break Da;
																																																																																				}
																																																																																				if (z[v | 0]) {
																																																																																					break wa;
																																																																																				}
																																																																																				if (!Xa) {
																																																																																					break fa;
																																																																																				}
																																																																																				g = 0;
																																																																																				k = ka(v, da);
																																																																																				if ((k | 0) == (c | 0)) {
																																																																																					break Da;
																																																																																				}
																																																																																				y[e + 332 >> 2] = b;
																																																																																				y[e + 328 >> 2] = d;
																																																																																				y[e + 224 >> 2] = F;
																																																																																				y[e + 220 >> 2] = m;
																																																																																				g = y[e + 332 >> 2];
																																																																																				y[e + 40 >> 2] = y[e + 328 >> 2];
																																																																																				y[e + 44 >> 2] = g;
																																																																																				g = y[e + 224 >> 2];
																																																																																				y[e + 32 >> 2] = y[e + 220 >> 2];
																																																																																				y[e + 36 >> 2] = g;
																																																																																				Ca(e + 40 | 0, e + 32 | 0);
																																																																																				c = c ^ k;
																																																																																				break Ca;
																																																																																			}
																																																																																			y[e + 212 >> 2] = 0;
																																																																																			break va;
																																																																																		}
																																																																																		Ea: {
																																																																																			Fa: {
																																																																																				Ga: {
																																																																																					if (u >>> 0 <= 1) {
																																																																																						J = 0;
																																																																																						r = 0;
																																																																																						k = (u | 0) != 1;
																																																																																						if (!k) {
																																																																																							if (!F) {
																																																																																								break fa;
																																																																																							}
																																																																																							r = z[m | 0];
																																																																																						}
																																																																																						h = r & 240;
																																																																																						while (1) {
																																																																																							if ((J | 0) != (N | 0)) {
																																																																																								if (!k) {
																																																																																									c = J + 1 | 0;
																																																																																									if (c >>> 0 >= F >>> 0) {
																																																																																										break fa;
																																																																																									}
																																																																																									r = z[c + m | 0] | r << 8;
																																																																																								}
																																																																																								c = 7;
																																																																																								s = 0;
																																																																																								while (1) {
																																																																																									if ((c | 0) >= 0) {
																																																																																										if (z[v | 0]) {
																																																																																											break wa;
																																																																																										}
																																																																																										if (h >>> 0 >= R >>> 0) {
																																																																																											break fa;
																																																																																										}
																																																																																										i = h << 1;
																																																																																										j = ka(v, i + Q | 0);
																																																																																										h = j | (r >>> c & 16 | i & 63470);
																																																																																										s = j << c | s;
																																																																																										c = c - 1 | 0;
																																																																																										continue;
																																																																																									}
																																																																																									break;
																																																																																								}
																																																																																								if ((b | 0) == (J | 0)) {
																																																																																									break fa;
																																																																																								}
																																																																																								w[d + J | 0] = s;
																																																																																								J = J + 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																							break;
																																																																																						}
																																																																																						j = r << 8;
																																																																																						c = 0;
																																																																																						s = 0;
																																																																																						while (1) {
																																																																																							if ((c | 0) == (W | 0)) {
																																																																																								break Ga;
																																																																																							}
																																																																																							if (z[v | 0]) {
																																																																																								break wa;
																																																																																							}
																																																																																							if (h >>> 0 >= R >>> 0) {
																																																																																								break fa;
																																																																																							}
																																																																																							k = h << 1;
																																																																																							K = ka(v, k + Q | 0);
																																																																																							i = 7 - c | 0;
																																																																																							h = K | (j >>> i & 16 | k & 63470);
																																																																																							s = K << i | s;
																																																																																							c = c + 1 | 0;
																																																																																							continue;
																																																																																						}
																																																																																					}
																																																																																					if (!h | !F | (b >>> 0 < N >>> 0 | N >>> 0 > F - 1 >>> 0) | N >>> 0 > h - 1 >>> 0) {
																																																																																						break fa;
																																																																																					}
																																																																																					r = z[m | 0];
																																																																																					J = z[i | 0] << 6;
																																																																																					h = r & 240 | J & 14336;
																																																																																					H = d + N | 0;
																																																																																					k = m;
																																																																																					j = d;
																																																																																					while (1) {
																																																																																						Ha: {
																																																																																							K = J << 8;
																																																																																							if ((j | 0) == (H | 0)) {
																																																																																								break Ha;
																																																																																							}
																																																																																							k = k + 1 | 0;
																																																																																							r = z[k | 0] | r << 8;
																																																																																							i = i + 1 | 0;
																																																																																							J = K | z[i | 0] << 6;
																																																																																							c = 7;
																																																																																							s = 0;
																																																																																							while (1) {
																																																																																								if ((c | 0) >= 0) {
																																																																																									if (z[v | 0]) {
																																																																																										break wa;
																																																																																									}
																																																																																									if (h >>> 0 >= R >>> 0) {
																																																																																										break fa;
																																																																																									}
																																																																																									h = h << 1;
																																																																																									K = ka(v, h + Q | 0);
																																																																																									h = K | (r >>> c & 16 | (J >>> c & 2048 | h & 63470));
																																																																																									s = K << c | s;
																																																																																									c = c - 1 | 0;
																																																																																									continue;
																																																																																								}
																																																																																								break;
																																																																																							}
																																																																																							w[j | 0] = s;
																																																																																							j = j + 1 | 0;
																																																																																							continue;
																																																																																						}
																																																																																						break;
																																																																																					}
																																																																																					k = r << 8;
																																																																																					s = 0;
																																																																																					G = 0;
																																																																																					while (1) {
																																																																																						if ((s | 0) == (W | 0)) {
																																																																																							break Fa;
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break wa;
																																																																																						}
																																																																																						if (h >>> 0 >= R >>> 0) {
																																																																																							break fa;
																																																																																						}
																																																																																						i = h << 1;
																																																																																						c = ka(v, i + Q | 0);
																																																																																						j = 7 - s | 0;
																																																																																						G = c << j | G;
																																																																																						h = c | (k >>> j & 16 | (K >>> j & 2048 | i & 63470));
																																																																																						s = s + 1 | 0;
																																																																																						continue;
																																																																																					}
																																																																																				}
																																																																																				if (b >>> 0 <= N >>> 0) {
																																																																																					break fa;
																																																																																				}
																																																																																				w[d + N | 0] = s;
																																																																																				break Ea;
																																																																																			}
																																																																																			if (b >>> 0 <= N >>> 0) {
																																																																																				break fa;
																																																																																			}
																																																																																			w[H | 0] = G;
																																																																																		}
																																																																																		c = g;
																																																																																	}
																																																																																	u = u + 1 | 0;
																																																																																	h = F;
																																																																																	i = m;
																																																																																	continue;
																																																																																}
																																																																															}
																																																																															Aa(L, v, e + 328 | 0);
																																																																															c = y[e + 328 >> 2];
																																																																															if (c >>> 0 >= 2) {
																																																																																F = xa(6);
																																																																																y[e + 220 >> 2] = F;
																																																																																u = xa(8);
																																																																																y[e + 212 >> 2] = u;
																																																																																m = xa(11);
																																																																																y[e + 376 >> 2] = m;
																																																																																h = xa(15);
																																																																																y[e + 372 >> 2] = h;
																																																																																j = xa(15);
																																																																																y[e + 368 >> 2] = j;
																																																																																k = xa(15);
																																																																																y[e + 364 >> 2] = k;
																																																																																i = xa(15);
																																																																																y[e + 360 >> 2] = i;
																																																																																g = xa(1);
																																																																																y[e + 356 >> 2] = g;
																																																																																H = Qb();
																																																																																y[e + 352 >> 2] = H;
																																																																																b = z[l | 0];
																																																																																y[H + 20 >> 2] = 1;
																																																																																y[H + 16 >> 2] = c;
																																																																																y[H + 12 >> 2] = q;
																																																																																y[H + 8 >> 2] = fa;
																																																																																w[H + 1 | 0] = 1;
																																																																																w[H | 0] = b;
																																																																																b = y[l + 4 >> 2] + I | 0;
																																																																																y[H + 24 >> 2] = b;
																																																																																K = Kb(e + 404 | 0, b);
																																																																																b = y[l + 4 >> 2];
																																																																																c = y[l + 16 >> 2];
																																																																																if (b >>> 0 > y[l + 20 >> 2] - c >> 2 >>> 0) {
																																																																																	break fa;
																																																																																}
																																																																																P = y[K >> 2];
																																																																																zd(c, b, P, y[e + 408 >> 2] - P >> 2);
																																																																																d = y[Ia >> 2];
																																																																																b = 0;
																																																																																while (1) if ((b | 0) == (I | 0)) {
																																																																																	$a(H + 124 | 0, K);
																																																																																	x[H + 4 >> 1] = 0;
																																																																																	y[H + 136 >> 2] = 0;
																																																																																	y[H + 140 >> 2] = 1;
																																																																																	w[H + 3 | 0] = 0;
																																																																																	y[H + 172 >> 2] = g;
																																																																																	y[H + 168 >> 2] = i;
																																																																																	y[H + 164 >> 2] = k;
																																																																																	y[H + 160 >> 2] = j;
																																																																																	y[H + 156 >> 2] = h;
																																																																																	y[H + 152 >> 2] = m;
																																																																																	y[H + 148 >> 2] = u;
																																																																																	y[H + 144 >> 2] = F;
																																																																																	w[H + 2 | 0] = z[l + 2 | 0];
																																																																																	w[H + 176 | 0] = z[l + 52 | 0];
																																																																																	w[H + 177 | 0] = z[l + 53 | 0];
																																																																																	w[H + 178 | 0] = z[l + 54 | 0];
																																																																																	w[H + 179 | 0] = z[l + 55 | 0];
																																																																																	b = Ed(H, v, Pa, ea, Qa);
																																																																																	y[e + 348 >> 2] = 0;
																																																																																	oa(e + 388 | 0, b);
																																																																																	la(e + 348 | 0);
																																																																																	b = y[e + 388 >> 2];
																																																																																	va(K);
																																																																																	qc(e + 352 | 0);
																																																																																	pa(e + 356 | 0);
																																																																																	pa(e + 360 | 0);
																																																																																	pa(e + 364 | 0);
																																																																																	pa(e + 368 | 0);
																																																																																	pa(e + 372 | 0);
																																																																																	pa(e + 376 | 0);
																																																																																	pa(e + 212 | 0);
																																																																																	pa(e + 220 | 0);
																																																																																	if (!b) {
																																																																																		break ta;
																																																																																	}
																																																																																	break ua;
																																																																																} else {
																																																																																	c = b << 2;
																																																																																	y[(c + P | 0) + (y[l + 4 >> 2] << 2) >> 2] = y[c + d >> 2];
																																																																																	b = b + 1 | 0;
																																																																																	continue;
																																																																																}
																																																																															}
																																																																															b = 0;
																																																																															if ((c | 0) != 1) {
																																																																																break ua;
																																																																															}
																																																																															b = y[l + 4 >> 2];
																																																																															Ac(y[Qa + 36 >> 2], v, e + 404 | 0);
																																																																															d = y[e + 404 >> 2];
																																																																															if (d >>> 0 >= b + I >>> 0) {
																																																																																break ta;
																																																																															}
																																																																															b = y[l + 4 >> 2];
																																																																															if (b >>> 0 > d >>> 0) {
																																																																																b = y[ga >> 2] + (d << 2) | 0;
																																																																															} else {
																																																																																b = d - b | 0;
																																																																																c = y[Ia >> 2];
																																																																																if (b >>> 0 >= y[Ia + 4 >> 2] - c >> 2 >>> 0) {
																																																																																	break fa;
																																																																																}
																																																																																b = c + (b << 2) | 0;
																																																																															}
																																																																															c = y[b >> 2];
																																																																															if (!c) {
																																																																																break ta;
																																																																															}
																																																																															Aa(y[Qa + 28 >> 2], v, e + 220 | 0);
																																																																															Aa(y[Qa + 32 >> 2], v, e + 212 | 0);
																																																																															d = kb();
																																																																															y[e + 376 >> 2] = d;
																																																																															y[d + 8 >> 2] = q;
																																																																															y[d + 4 >> 2] = fa;
																																																																															b = z[l + 2 | 0];
																																																																															y[d + 20 >> 2] = c;
																																																																															w[d | 0] = b;
																																																																															y[d + 12 >> 2] = y[e + 220 >> 2];
																																																																															b = y[e + 212 >> 2];
																																																																															w[d + 1 | 0] = 0;
																																																																															y[d + 16 >> 2] = b;
																																																																															w[d + 24 | 0] = z[l + 52 | 0];
																																																																															w[d + 25 | 0] = z[l + 53 | 0];
																																																																															w[d + 26 | 0] = z[l + 54 | 0];
																																																																															w[d + 27 | 0] = z[l + 55 | 0];
																																																																															b = jb(d, v, Pa, ea);
																																																																															y[e + 372 >> 2] = 0;
																																																																															oa(e + 388 | 0, b);
																																																																															la(e + 372 | 0);
																																																																															b = y[e + 388 >> 2];
																																																																															Ua(e + 376 | 0);
																																																																															if (!b) {
																																																																																break ta;
																																																																															}
																																																																															break ua;
																																																																														}
																																																																														Ia: {
																																																																															Ja: {
																																																																																if (Hb(D)) {
																																																																																	C = ua(V, U);
																																																																																	y[e + 212 >> 2] = C;
																																																																																	if (!y[C + 16 >> 2]) {
																																																																																		break Ja;
																																																																																	}
																																																																																	b = y[V >> 2];
																																																																																	if (!b) {
																																																																																		break fa;
																																																																																	}
																																																																																	b = b - 1 | 0;
																																																																																	K = b >>> 3 | 0;
																																																																																	P = (b & 7) + 1 | 0;
																																																																																	h = 0;
																																																																																	g = 0;
																																																																																	d = 0;
																																																																																	c = 0;
																																																																																	while (1) {
																																																																																		Ka: {
																																																																																			La: {
																																																																																				if (B[U >> 2] > d >>> 0) {
																																																																																					ja(e + 404 | 0, C, d);
																																																																																					j = y[e + 408 >> 2];
																																																																																					i = y[e + 404 >> 2];
																																																																																					if (z[D + 1 | 0] != 1) {
																																																																																						k = c;
																																																																																						break La;
																																																																																					}
																																																																																					if (z[v | 0]) {
																																																																																						break Ja;
																																																																																					}
																																																																																					if (!Ta) {
																																																																																						break fa;
																																																																																					}
																																																																																					k = 0;
																																																																																					m = ka(v, aa);
																																																																																					if ((m | 0) == (c | 0)) {
																																																																																						break La;
																																																																																					}
																																																																																					y[e + 332 >> 2] = j;
																																																																																					y[e + 328 >> 2] = i;
																																																																																					y[e + 224 >> 2] = h;
																																																																																					y[e + 220 >> 2] = g;
																																																																																					b = y[e + 332 >> 2];
																																																																																					y[e + 8 >> 2] = y[e + 328 >> 2];
																																																																																					y[e + 12 >> 2] = b;
																																																																																					b = y[e + 224 >> 2];
																																																																																					y[e >> 2] = y[e + 220 >> 2];
																																																																																					y[e + 4 >> 2] = b;
																																																																																					Ca(e + 8 | 0, e);
																																																																																					c = c ^ m;
																																																																																					break Ka;
																																																																																				}
																																																																																				y[e + 212 >> 2] = 0;
																																																																																				break Ia;
																																																																																			}
																																																																																			c = 0;
																																																																																			r = 0;
																																																																																			Ma: {
																																																																																				if (!d) {
																																																																																					Na: {
																																																																																						while (1) {
																																																																																							h = 7;
																																																																																							s = 0;
																																																																																							if ((r | 0) == (K | 0)) {
																																																																																								break Na;
																																																																																							}
																																																																																							Oa: {
																																																																																								while (1) {
																																																																																									if ((h | 0) >= 0) {
																																																																																										if (z[v | 0]) {
																																																																																											break Oa;
																																																																																										}
																																																																																										if (c >>> 0 >= R >>> 0) {
																																																																																											break fa;
																																																																																										}
																																																																																										b = c << 1;
																																																																																										g = ka(v, b + Q | 0);
																																																																																										c = g | b & 1006;
																																																																																										s = g << h | s;
																																																																																										h = h - 1 | 0;
																																																																																										continue;
																																																																																									}
																																																																																									break;
																																																																																								}
																																																																																								if ((j | 0) == (r | 0)) {
																																																																																									break fa;
																																																																																								}
																																																																																								w[i + r | 0] = s;
																																																																																								r = r + 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																							break;
																																																																																						}
																																																																																						if (r >>> 0 < K >>> 0) {
																																																																																							break Ja;
																																																																																						}
																																																																																					}
																																																																																					h = 0;
																																																																																					s = 0;
																																																																																					while (1) {
																																																																																						if ((h | 0) == (P | 0)) {
																																																																																							break Ma;
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break Ja;
																																																																																						}
																																																																																						if (c >>> 0 >= R >>> 0) {
																																																																																							break fa;
																																																																																						}
																																																																																						b = c << 1;
																																																																																						g = ka(v, b + Q | 0);
																																																																																						c = g | b & 1006;
																																																																																						s = g << 7 - h | s;
																																																																																						h = h + 1 | 0;
																																																																																						continue;
																																																																																					}
																																																																																				}
																																																																																				if (!h) {
																																																																																					break fa;
																																																																																				}
																																																																																				m = h - 1 | 0;
																																																																																				r = z[g | 0];
																																																																																				h = r >>> 1 & 112;
																																																																																				u = 0;
																																																																																				while (1) {
																																																																																					Pa: {
																																																																																						if ((u | 0) != (K | 0)) {
																																																																																							if ((m | 0) == (u | 0)) {
																																																																																								break fa;
																																																																																							}
																																																																																							b = u + 1 | 0;
																																																																																							r = z[b + g | 0] | r << 8;
																																																																																							c = 7;
																																																																																							s = 0;
																																																																																							while (1) {
																																																																																								if ((c | 0) < 0) {
																																																																																									break Pa;
																																																																																								}
																																																																																								if (z[v | 0]) {
																																																																																									break Ja;
																																																																																								}
																																																																																								if (h >>> 0 >= R >>> 0) {
																																																																																									break fa;
																																																																																								}
																																																																																								h = h << 1;
																																																																																								F = ka(v, h + Q | 0);
																																																																																								h = F | (r >>> c + 1 & 16 | h & 1006);
																																																																																								s = F << c | s;
																																																																																								c = c - 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																						}
																																																																																						g = r << 8;
																																																																																						c = 0;
																																																																																						s = 0;
																																																																																						while (1) {
																																																																																							if ((c | 0) != (P | 0)) {
																																																																																								if (z[v | 0]) {
																																																																																									break Ja;
																																																																																								}
																																																																																								if (h >>> 0 >= R >>> 0) {
																																																																																									break fa;
																																																																																								}
																																																																																								b = h << 1;
																																																																																								m = ka(v, b + Q | 0);
																																																																																								h = m | (g >>> 8 - c & 16 | b & 1006);
																																																																																								s = m << 7 - c | s;
																																																																																								c = c + 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																							break;
																																																																																						}
																																																																																						break Ma;
																																																																																					}
																																																																																					if ((j | 0) == (u | 0)) {
																																																																																						break fa;
																																																																																					}
																																																																																					w[i + u | 0] = s;
																																																																																					u = b;
																																																																																					continue;
																																																																																				}
																																																																																			}
																																																																																			if (j >>> 0 <= K >>> 0) {
																																																																																				break fa;
																																																																																			}
																																																																																			w[i + K | 0] = s;
																																																																																			c = k;
																																																																																		}
																																																																																		d = d + 1 | 0;
																																																																																		h = j;
																																																																																		g = i;
																																																																																		continue;
																																																																																	}
																																																																																}
																																																																																C = ua(V, U);
																																																																																y[e + 212 >> 2] = C;
																																																																																Qa: {
																																																																																	Ra: {
																																																																																		c = y[C + 16 >> 2];
																																																																																		if (!c) {
																																																																																			break Ra;
																																																																																		}
																																																																																		h = y[C + 12 >> 2];
																																																																																		while (1) {
																																																																																			if ((c | 0) > 0) {
																																																																																				w[h | 0] = 0;
																																																																																				c = c - 1 | 0;
																																																																																				h = h + 1 | 0;
																																																																																				continue;
																																																																																			}
																																																																																			break;
																																																																																		}
																																																																																		b = 0;
																																																																																		u = 0;
																																																																																		c = 0;
																																																																																		_ = 0;
																																																																																		while (1) {
																																																																																			Sa: {
																																																																																				Ta: {
																																																																																					if (B[U >> 2] > _ >>> 0) {
																																																																																						ja(e + 404 | 0, C, _);
																																																																																						g = y[e + 408 >> 2];
																																																																																						d = y[e + 404 >> 2];
																																																																																						if (z[D + 1 | 0] != 1) {
																																																																																							m = c;
																																																																																							break Ta;
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break Ra;
																																																																																						}
																																																																																						if (!Ta) {
																																																																																							break fa;
																																																																																						}
																																																																																						m = 0;
																																																																																						i = ka(v, aa);
																																																																																						if ((i | 0) == (c | 0)) {
																																																																																							break Ta;
																																																																																						}
																																																																																						y[e + 332 >> 2] = g;
																																																																																						y[e + 328 >> 2] = d;
																																																																																						y[e + 224 >> 2] = u;
																																																																																						y[e + 220 >> 2] = b;
																																																																																						b = y[e + 332 >> 2];
																																																																																						y[e + 24 >> 2] = y[e + 328 >> 2];
																																																																																						y[e + 28 >> 2] = b;
																																																																																						b = y[e + 224 >> 2];
																																																																																						y[e + 16 >> 2] = y[e + 220 >> 2];
																																																																																						y[e + 20 >> 2] = b;
																																																																																						c = c ^ i;
																																																																																						Ca(e + 24 | 0, e + 16 | 0);
																																																																																						break Sa;
																																																																																					}
																																																																																					y[e + 212 >> 2] = 0;
																																																																																					break Qa;
																																																																																				}
																																																																																				G = 0;
																																																																																				j = 0;
																																																																																				i = 0;
																																																																																				if (z[D + 2 | 0] == 1) {
																																																																																					ja(e + 404 | 0, y[D + 12 >> 2], _);
																																																																																					j = y[e + 408 >> 2];
																																																																																					i = y[e + 404 >> 2];
																																																																																				}
																																																																																				ja(e + 404 | 0, C, w[D + 17 | 0] + _ | 0);
																																																																																				P = y[e + 408 >> 2];
																																																																																				F = y[e + 404 >> 2];
																																																																																				h = y[C + 20 >> 2];
																																																																																				G = !u | (h | 0) < 2 ? G : z[b | 0] >>> 6 & 1;
																																																																																				G = !u | (h | 0) <= 0 ? G : z[b | 0] >>> 6 & 2 | G;
																																																																																				r = 0;
																																																																																				c = 0;
																																																																																				while (1) {
																																																																																					if (B[V >> 2] <= c >>> 0) {
																																																																																						c = m;
																																																																																						break Sa;
																																																																																					}
																																																																																					Ua: {
																																																																																						Va: {
																																																																																							if (z[D + 2 | 0] == 1) {
																																																																																								if (ia(y[y[D + 12 >> 2] + 20 >> 2], c, i, j)) {
																																																																																									break Va;
																																																																																								}
																																																																																							}
																																																																																							k = ia(h, w[D + 16 | 0] + c | 0, F, P);
																																																																																							if (z[v | 0]) {
																																																																																								break Ra;
																																																																																							}
																																																																																							k = G << 5 | k << 4 | r;
																																																																																							if (k >>> 0 >= R >>> 0) {
																																																																																								break fa;
																																																																																							}
																																																																																							k = ka(v, Q + (k << 1) | 0);
																																																																																							h = y[C + 20 >> 2];
																																																																																							if (!k) {
																																																																																								break Va;
																																																																																							}
																																																																																							Ea(h, c, d, g, 1);
																																																																																							h = y[C + 20 >> 2];
																																																																																							k = 1;
																																																																																							break Ua;
																																																																																						}
																																																																																						k = 0;
																																																																																					}
																																																																																					G = ia(h, c + 2 | 0, b, u) | G << 1 & 30;
																																																																																					c = c + 1 | 0;
																																																																																					r = r << 1 & 14 | k;
																																																																																					continue;
																																																																																				}
																																																																																			}
																																																																																			_ = _ + 1 | 0;
																																																																																			b = d;
																																																																																			u = g;
																																																																																			continue;
																																																																																		}
																																																																																	}
																																																																																	C = 0;
																																																																																}
																																																																																break va;
																																																																															}
																																																																															C = 0;
																																																																														}
																																																																														break va;
																																																																													}
																																																																													Wa: {
																																																																														Xa: {
																																																																															if (Hb(D)) {
																																																																																C = ua(V, U);
																																																																																y[e + 212 >> 2] = C;
																																																																																if (!y[C + 16 >> 2]) {
																																																																																	break Xa;
																																																																																}
																																																																																b = y[V >> 2];
																																																																																if (!b) {
																																																																																	break fa;
																																																																																}
																																																																																b = b - 1 | 0;
																																																																																N = b >>> 3 | 0;
																																																																																W = (b & 7) + 1 | 0;
																																																																																P = y[U >> 2];
																																																																																b = 0;
																																																																																d = 0;
																																																																																h = 0;
																																																																																i = 0;
																																																																																u = 0;
																																																																																c = 0;
																																																																																while (1) {
																																																																																	m = d;
																																																																																	F = b;
																																																																																	Ya: {
																																																																																		Za: {
																																																																																			if ((u | 0) != (P | 0)) {
																																																																																				ja(e + 404 | 0, C, u);
																																																																																				b = y[e + 408 >> 2];
																																																																																				d = y[e + 404 >> 2];
																																																																																				if (z[D + 1 | 0] != 1) {
																																																																																					g = c;
																																																																																					break Za;
																																																																																				}
																																																																																				if (z[v | 0]) {
																																																																																					break Xa;
																																																																																				}
																																																																																				if (!rb) {
																																																																																					break fa;
																																																																																				}
																																																																																				g = 0;
																																																																																				k = ka(v, Ma);
																																																																																				if ((k | 0) == (c | 0)) {
																																																																																					break Za;
																																																																																				}
																																																																																				y[e + 332 >> 2] = b;
																																																																																				y[e + 328 >> 2] = d;
																																																																																				y[e + 224 >> 2] = F;
																																																																																				y[e + 220 >> 2] = m;
																																																																																				g = y[e + 332 >> 2];
																																																																																				y[e + 104 >> 2] = y[e + 328 >> 2];
																																																																																				y[e + 108 >> 2] = g;
																																																																																				g = y[e + 224 >> 2];
																																																																																				y[e + 96 >> 2] = y[e + 220 >> 2];
																																																																																				y[e + 100 >> 2] = g;
																																																																																				Ca(e + 104 | 0, e + 96 | 0);
																																																																																				c = c ^ k;
																																																																																				break Ya;
																																																																																			}
																																																																																			y[e + 212 >> 2] = 0;
																																																																																			break Wa;
																																																																																		}
																																																																																		_a: {
																																																																																			$a: {
																																																																																				ab: {
																																																																																					if (u >>> 0 <= 1) {
																																																																																						J = 0;
																																																																																						r = 0;
																																																																																						k = (u | 0) != 1;
																																																																																						if (!k) {
																																																																																							if (!F) {
																																																																																								break fa;
																																																																																							}
																																																																																							r = z[m | 0];
																																																																																						}
																																																																																						h = r >>> 3 & 28;
																																																																																						while (1) {
																																																																																							if ((J | 0) != (N | 0)) {
																																																																																								if (!k) {
																																																																																									c = J + 1 | 0;
																																																																																									if (c >>> 0 >= F >>> 0) {
																																																																																										break fa;
																																																																																									}
																																																																																									r = z[c + m | 0] | r << 8;
																																																																																								}
																																																																																								c = 7;
																																																																																								s = 0;
																																																																																								while (1) {
																																																																																									if ((c | 0) >= 0) {
																																																																																										if (z[v | 0]) {
																																																																																											break Xa;
																																																																																										}
																																																																																										if (h >>> 0 >= R >>> 0) {
																																																																																											break fa;
																																																																																										}
																																																																																										i = h << 1;
																																																																																										j = ka(v, i + Q | 0);
																																																																																										h = j | (r >>> c + 3 & 4 | i & 890);
																																																																																										s = j << c | s;
																																																																																										c = c - 1 | 0;
																																																																																										continue;
																																																																																									}
																																																																																									break;
																																																																																								}
																																																																																								if ((b | 0) == (J | 0)) {
																																																																																									break fa;
																																																																																								}
																																																																																								w[d + J | 0] = s;
																																																																																								J = J + 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																							break;
																																																																																						}
																																																																																						k = r << 8;
																																																																																						c = 0;
																																																																																						s = 0;
																																																																																						while (1) {
																																																																																							if ((c | 0) == (W | 0)) {
																																																																																								break ab;
																																																																																							}
																																																																																							if (z[v | 0]) {
																																																																																								break Xa;
																																																																																							}
																																																																																							if (h >>> 0 >= R >>> 0) {
																																																																																								break fa;
																																																																																							}
																																																																																							i = h << 1;
																																																																																							j = ka(v, i + Q | 0);
																																																																																							h = j | (k >>> 10 - c & 4 | i & 890);
																																																																																							s = j << 7 - c | s;
																																																																																							c = c + 1 | 0;
																																																																																							continue;
																																																																																						}
																																																																																					}
																																																																																					if (!h | !F | (b >>> 0 < N >>> 0 | N >>> 0 > F - 1 >>> 0) | N >>> 0 > h - 1 >>> 0) {
																																																																																						break fa;
																																																																																					}
																																																																																					r = z[m | 0];
																																																																																					J = z[i | 0] << 1;
																																																																																					h = r >>> 3 & 28 | J & 384;
																																																																																					H = d + N | 0;
																																																																																					k = m;
																																																																																					j = d;
																																																																																					while (1) {
																																																																																						bb: {
																																																																																							K = J << 8;
																																																																																							if ((j | 0) == (H | 0)) {
																																																																																								break bb;
																																																																																							}
																																																																																							k = k + 1 | 0;
																																																																																							r = z[k | 0] | r << 8;
																																																																																							i = i + 1 | 0;
																																																																																							J = K | z[i | 0] << 1;
																																																																																							c = 7;
																																																																																							s = 0;
																																																																																							while (1) {
																																																																																								if ((c | 0) >= 0) {
																																																																																									if (z[v | 0]) {
																																																																																										break Xa;
																																																																																									}
																																																																																									if (h >>> 0 >= R >>> 0) {
																																																																																										break fa;
																																																																																									}
																																																																																									h = h << 1;
																																																																																									K = ka(v, h + Q | 0);
																																																																																									h = K | (r >>> c + 3 & 4 | (J >>> c & 128 | h & 890));
																																																																																									s = K << c | s;
																																																																																									c = c - 1 | 0;
																																																																																									continue;
																																																																																								}
																																																																																								break;
																																																																																							}
																																																																																							w[j | 0] = s;
																																																																																							j = j + 1 | 0;
																																																																																							continue;
																																																																																						}
																																																																																						break;
																																																																																					}
																																																																																					j = r << 8;
																																																																																					s = 0;
																																																																																					G = 0;
																																																																																					while (1) {
																																																																																						if ((s | 0) == (W | 0)) {
																																																																																							break $a;
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break Xa;
																																																																																						}
																																																																																						if (h >>> 0 >= R >>> 0) {
																																																																																							break fa;
																																																																																						}
																																																																																						k = h << 1;
																																																																																						i = ka(v, k + Q | 0);
																																																																																						c = 7 - s | 0;
																																																																																						G = i << c | G;
																																																																																						h = i | (j >>> 10 - s & 4 | (K >>> c & 128 | k & 890));
																																																																																						s = s + 1 | 0;
																																																																																						continue;
																																																																																					}
																																																																																				}
																																																																																				if (b >>> 0 <= N >>> 0) {
																																																																																					break fa;
																																																																																				}
																																																																																				w[d + N | 0] = s;
																																																																																				break _a;
																																																																																			}
																																																																																			if (b >>> 0 <= N >>> 0) {
																																																																																				break fa;
																																																																																			}
																																																																																			w[H | 0] = G;
																																																																																		}
																																																																																		c = g;
																																																																																	}
																																																																																	u = u + 1 | 0;
																																																																																	h = F;
																																																																																	i = m;
																																																																																	continue;
																																																																																}
																																																																															}
																																																																															C = ua(V, U);
																																																																															y[e + 212 >> 2] = C;
																																																																															cb: {
																																																																																db: {
																																																																																	c = y[C + 16 >> 2];
																																																																																	if (!c) {
																																																																																		break db;
																																																																																	}
																																																																																	h = y[C + 12 >> 2];
																																																																																	while (1) {
																																																																																		if ((c | 0) > 0) {
																																																																																			w[h | 0] = 0;
																																																																																			c = c - 1 | 0;
																																																																																			h = h + 1 | 0;
																																																																																			continue;
																																																																																		}
																																																																																		break;
																																																																																	}
																																																																																	i = 0;
																																																																																	d = 0;
																																																																																	g = 0;
																																																																																	b = 0;
																																																																																	c = 0;
																																																																																	S = 0;
																																																																																	while (1) {
																																																																																		eb: {
																																																																																			fb: {
																																																																																				if (B[U >> 2] > S >>> 0) {
																																																																																					ja(e + 404 | 0, C, S);
																																																																																					u = y[e + 408 >> 2];
																																																																																					j = y[e + 404 >> 2];
																																																																																					if (z[D + 1 | 0] != 1) {
																																																																																						k = c;
																																																																																						break fb;
																																																																																					}
																																																																																					if (z[v | 0]) {
																																																																																						break db;
																																																																																					}
																																																																																					if (!rb) {
																																																																																						break fa;
																																																																																					}
																																																																																					k = 0;
																																																																																					h = ka(v, Ma);
																																																																																					if ((h | 0) == (c | 0)) {
																																																																																						break fb;
																																																																																					}
																																																																																					y[e + 332 >> 2] = u;
																																																																																					y[e + 328 >> 2] = j;
																																																																																					y[e + 224 >> 2] = b;
																																																																																					y[e + 220 >> 2] = g;
																																																																																					d = y[e + 332 >> 2];
																																																																																					y[e + 120 >> 2] = y[e + 328 >> 2];
																																																																																					y[e + 124 >> 2] = d;
																																																																																					d = y[e + 224 >> 2];
																																																																																					y[e + 112 >> 2] = y[e + 220 >> 2];
																																																																																					y[e + 116 >> 2] = d;
																																																																																					c = c ^ h;
																																																																																					Ca(e + 120 | 0, e + 112 | 0);
																																																																																					break eb;
																																																																																				}
																																																																																				y[e + 212 >> 2] = 0;
																																																																																				break cb;
																																																																																			}
																																																																																			G = 0;
																																																																																			_ = 0;
																																																																																			m = 0;
																																																																																			if (z[D + 2 | 0] == 1) {
																																																																																				ja(e + 404 | 0, y[D + 12 >> 2], S);
																																																																																				_ = y[e + 408 >> 2];
																																																																																				m = y[e + 404 >> 2];
																																																																																			}
																																																																																			ja(e + 404 | 0, C, w[D + 17 | 0] + S | 0);
																																																																																			K = y[e + 408 >> 2];
																																																																																			P = y[e + 404 >> 2];
																																																																																			h = y[C + 20 >> 2];
																																																																																			G = !d | (h | 0) < 2 ? G : z[i | 0] >>> 6 & 1;
																																																																																			G = !d | (h | 0) <= 0 ? G : z[i | 0] >>> 6 & 2 | G;
																																																																																			r = 0;
																																																																																			r = !b | (h | 0) < 2 ? r : z[g | 0] >>> 6 & 1;
																																																																																			r = !b | (h | 0) <= 0 ? r : z[g | 0] >>> 6 & 2 | r;
																																																																																			J = 0;
																																																																																			c = 0;
																																																																																			while (1) {
																																																																																				if (B[V >> 2] <= c >>> 0) {
																																																																																					c = k;
																																																																																					break eb;
																																																																																				}
																																																																																				gb: {
																																																																																					hb: {
																																																																																						if (z[D + 2 | 0] == 1) {
																																																																																							if (ia(y[y[D + 12 >> 2] + 20 >> 2], c, m, _)) {
																																																																																								break hb;
																																																																																							}
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break db;
																																																																																						}
																																																																																						h = r << 3 | G << 7 | ia(h, w[D + 16 | 0] + c | 0, P, K) << 2 | J;
																																																																																						if (h >>> 0 >= R >>> 0) {
																																																																																							break fa;
																																																																																						}
																																																																																						F = ka(v, Q + (h << 1) | 0);
																																																																																						h = y[C + 20 >> 2];
																																																																																						if (!F) {
																																																																																							break hb;
																																																																																						}
																																																																																						Ea(h, c, j, u, 1);
																																																																																						h = y[C + 20 >> 2];
																																																																																						H = 1;
																																																																																						break gb;
																																																																																					}
																																																																																					H = 0;
																																																																																				}
																																																																																				F = c + 2 | 0;
																																																																																				G = ia(h, F, i, d) | G << 1 & 6;
																																																																																				r = ia(h, F, g, b) | r << 1 & 14;
																																																																																				c = c + 1 | 0;
																																																																																				J = J << 1 & 2 | H;
																																																																																				continue;
																																																																																			}
																																																																																		}
																																																																																		S = S + 1 | 0;
																																																																																		i = g;
																																																																																		d = b;
																																																																																		g = j;
																																																																																		b = u;
																																																																																		continue;
																																																																																	}
																																																																																}
																																																																																C = 0;
																																																																															}
																																																																															break va;
																																																																														}
																																																																														C = 0;
																																																																													}
																																																																													break va;
																																																																												}
																																																																												ib: {
																																																																													jb: {
																																																																														if (yd(D)) {
																																																																															C = ua(V, U);
																																																																															y[e + 212 >> 2] = C;
																																																																															if (!y[C + 16 >> 2]) {
																																																																																break jb;
																																																																															}
																																																																															b = y[V >> 2];
																																																																															if (!b) {
																																																																																break fa;
																																																																															}
																																																																															b = b - 1 | 0;
																																																																															N = b >>> 3 | 0;
																																																																															W = (b & 7) + 1 | 0;
																																																																															P = y[U >> 2];
																																																																															b = 0;
																																																																															d = 0;
																																																																															h = 0;
																																																																															i = 0;
																																																																															u = 0;
																																																																															c = 0;
																																																																															while (1) {
																																																																																m = d;
																																																																																F = b;
																																																																																kb: {
																																																																																	lb: {
																																																																																		if ((u | 0) != (P | 0)) {
																																																																																			ja(e + 404 | 0, C, u);
																																																																																			b = y[e + 408 >> 2];
																																																																																			d = y[e + 404 >> 2];
																																																																																			if (z[D + 1 | 0] != 1) {
																																																																																				g = c;
																																																																																				break lb;
																																																																																			}
																																																																																			if (z[v | 0]) {
																																																																																				break jb;
																																																																																			}
																																																																																			if (!Ya) {
																																																																																				break fa;
																																																																																			}
																																																																																			g = 0;
																																																																																			k = ka(v, ha);
																																																																																			if ((k | 0) == (c | 0)) {
																																																																																				break lb;
																																																																																			}
																																																																																			y[e + 332 >> 2] = b;
																																																																																			y[e + 328 >> 2] = d;
																																																																																			y[e + 224 >> 2] = F;
																																																																																			y[e + 220 >> 2] = m;
																																																																																			g = y[e + 332 >> 2];
																																																																																			y[e + 72 >> 2] = y[e + 328 >> 2];
																																																																																			y[e + 76 >> 2] = g;
																																																																																			g = y[e + 224 >> 2];
																																																																																			y[e + 64 >> 2] = y[e + 220 >> 2];
																																																																																			y[e + 68 >> 2] = g;
																																																																																			Ca(e + 72 | 0, e - -64 | 0);
																																																																																			c = c ^ k;
																																																																																			break kb;
																																																																																		}
																																																																																		y[e + 212 >> 2] = 0;
																																																																																		break ib;
																																																																																	}
																																																																																	mb: {
																																																																																		nb: {
																																																																																			ob: {
																																																																																				if (u >>> 0 <= 1) {
																																																																																					J = 0;
																																																																																					r = 0;
																																																																																					k = (u | 0) != 1;
																																																																																					if (!k) {
																																																																																						if (!F) {
																																																																																							break fa;
																																																																																						}
																																																																																						r = z[m | 0];
																																																																																					}
																																																																																					h = r >>> 1 & 120;
																																																																																					while (1) {
																																																																																						if ((J | 0) != (N | 0)) {
																																																																																							if (!k) {
																																																																																								c = J + 1 | 0;
																																																																																								if (c >>> 0 >= F >>> 0) {
																																																																																									break fa;
																																																																																								}
																																																																																								r = z[c + m | 0] | r << 8;
																																																																																							}
																																																																																							c = 7;
																																																																																							s = 0;
																																																																																							while (1) {
																																																																																								if ((c | 0) >= 0) {
																																																																																									if (z[v | 0]) {
																																																																																										break jb;
																																																																																									}
																																																																																									if (h >>> 0 >= R >>> 0) {
																																																																																										break fa;
																																																																																									}
																																																																																									i = h << 1;
																																																																																									j = ka(v, i + Q | 0);
																																																																																									h = j | (r >>> c + 1 & 8 | i & 7670);
																																																																																									s = j << c | s;
																																																																																									c = c - 1 | 0;
																																																																																									continue;
																																																																																								}
																																																																																								break;
																																																																																							}
																																																																																							if ((b | 0) == (J | 0)) {
																																																																																								break fa;
																																																																																							}
																																																																																							w[d + J | 0] = s;
																																																																																							J = J + 1 | 0;
																																																																																							continue;
																																																																																						}
																																																																																						break;
																																																																																					}
																																																																																					k = r << 8;
																																																																																					c = 0;
																																																																																					s = 0;
																																																																																					while (1) {
																																																																																						if ((c | 0) == (W | 0)) {
																																																																																							break ob;
																																																																																						}
																																																																																						if (z[v | 0]) {
																																																																																							break jb;
																																																																																						}
																																																																																						if (h >>> 0 >= R >>> 0) {
																																																																																							break fa;
																																																																																						}
																																																																																						i = h << 1;
																																																																																						j = ka(v, i + Q | 0);
																																																																																						h = j | (k >>> 8 - c & 8 | i & 7670);
																																																																																						s = j << 7 - c | s;
																																																																																						c = c + 1 | 0;
																																																																																						continue;
																																																																																					}
																																																																																				}
																																																																																				if (!h | !F | (b >>> 0 < N >>> 0 | N >>> 0 > F - 1 >>> 0) | N >>> 0 > h - 1 >>> 0) {
																																																																																					break fa;
																																																																																				}
																																																																																				r = z[m | 0];
																																																																																				J = z[i | 0] << 4;
																																																																																				h = r >>> 1 & 120 | J & 3584;
																																																																																				H = d + N | 0;
																																																																																				k = m;
																																																																																				j = d;
																																																																																				while (1) {
																																																																																					pb: {
																																																																																						K = J << 8;
																																																																																						if ((j | 0) == (H | 0)) {
																																																																																							break pb;
																																																																																						}
																																																																																						k = k + 1 | 0;
																																																																																						r = z[k | 0] | r << 8;
																																																																																						i = i + 1 | 0;
																																																																																						J = K | z[i | 0] << 4;
																																																																																						c = 7;
																																																																																						s = 0;
																																																																																						while (1) {
																																																																																							if ((c | 0) >= 0) {
																																																																																								if (z[v | 0]) {
																																																																																									break jb;
																																																																																								}
																																																																																								if (h >>> 0 >= R >>> 0) {
																																																																																									break fa;
																																																																																								}
																																																																																								h = h << 1;
																																																																																								K = ka(v, h + Q | 0);
																																																																																								h = K | (r >>> c + 1 & 8 | (J >>> c & 512 | h & 7670));
																																																																																								s = K << c | s;
																																																																																								c = c - 1 | 0;
																																																																																								continue;
																																																																																							}
																																																																																							break;
																																																																																						}
																																																																																						w[j | 0] = s;
																																																																																						j = j + 1 | 0;
																																																																																						continue;
																																																																																					}
																																																																																					break;
																																																																																				}
																																																																																				j = r << 8;
																																																																																				s = 0;
																																																																																				G = 0;
																																																																																				while (1) {
																																																																																					if ((s | 0) == (W | 0)) {
																																																																																						break nb;
																																																																																					}
																																																																																					if (z[v | 0]) {
																																																																																						break jb;
																																																																																					}
																																																																																					if (h >>> 0 >= R >>> 0) {
																																																																																						break fa;
																																																																																					}
																																																																																					k = h << 1;
																																																																																					i = ka(v, k + Q | 0);
																																																																																					c = 7 - s | 0;
																																																																																					G = i << c | G;
																																																																																					h = i | (j >>> 8 - s & 8 | (K >>> c & 512 | k & 7670));
																																																																																					s = s + 1 | 0;
																																																																																					continue;
																																																																																				}
																																																																																			}
																																																																																			if (b >>> 0 <= N >>> 0) {
																																																																																				break fa;
																																																																																			}
																																																																																			w[d + N | 0] = s;
																																																																																			break mb;
																																																																																		}
																																																																																		if (b >>> 0 <= N >>> 0) {
																																																																																			break fa;
																																																																																		}
																																																																																		w[H | 0] = G;
																																																																																	}
																																																																																	c = g;
																																																																																}
																																																																																u = u + 1 | 0;
																																																																																h = F;
																																																																																i = m;
																																																																																continue;
																																																																															}
																																																																														}
																																																																														C = ua(V, U);
																																																																														y[e + 212 >> 2] = C;
																																																																														qb: {
																																																																															rb: {
																																																																																c = y[C + 16 >> 2];
																																																																																if (!c) {
																																																																																	break rb;
																																																																																}
																																																																																h = y[C + 12 >> 2];
																																																																																while (1) {
																																																																																	if ((c | 0) > 0) {
																																																																																		w[h | 0] = 0;
																																																																																		c = c - 1 | 0;
																																																																																		h = h + 1 | 0;
																																																																																		continue;
																																																																																	}
																																																																																	break;
																																																																																}
																																																																																i = 0;
																																																																																g = 0;
																																																																																d = 0;
																																																																																b = 0;
																																																																																c = 0;
																																																																																S = 0;
																																																																																while (1) {
																																																																																	sb: {
																																																																																		tb: {
																																																																																			if (B[U >> 2] > S >>> 0) {
																																																																																				ja(e + 404 | 0, C, S);
																																																																																				u = y[e + 408 >> 2];
																																																																																				j = y[e + 404 >> 2];
																																																																																				if (z[D + 1 | 0] != 1) {
																																																																																					k = c;
																																																																																					break tb;
																																																																																				}
																																																																																				if (z[v | 0]) {
																																																																																					break rb;
																																																																																				}
																																																																																				if (!Ya) {
																																																																																					break fa;
																																																																																				}
																																																																																				k = 0;
																																																																																				h = ka(v, ha);
																																																																																				if ((h | 0) == (c | 0)) {
																																																																																					break tb;
																																																																																				}
																																																																																				y[e + 332 >> 2] = u;
																																																																																				y[e + 328 >> 2] = j;
																																																																																				y[e + 224 >> 2] = b;
																																																																																				y[e + 220 >> 2] = d;
																																																																																				g = y[e + 332 >> 2];
																																																																																				y[e + 88 >> 2] = y[e + 328 >> 2];
																																																																																				y[e + 92 >> 2] = g;
																																																																																				g = y[e + 224 >> 2];
																																																																																				y[e + 80 >> 2] = y[e + 220 >> 2];
																																																																																				y[e + 84 >> 2] = g;
																																																																																				c = c ^ h;
																																																																																				Ca(e + 88 | 0, e + 80 | 0);
																																																																																				break sb;
																																																																																			}
																																																																																			y[e + 212 >> 2] = 0;
																																																																																			break qb;
																																																																																		}
																																																																																		G = 0;
																																																																																		_ = 0;
																																																																																		m = 0;
																																																																																		if (z[D + 2 | 0] == 1) {
																																																																																			ja(e + 404 | 0, y[D + 12 >> 2], S);
																																																																																			_ = y[e + 408 >> 2];
																																																																																			m = y[e + 404 >> 2];
																																																																																		}
																																																																																		ja(e + 404 | 0, C, w[D + 17 | 0] + S | 0);
																																																																																		K = y[e + 408 >> 2];
																																																																																		P = y[e + 404 >> 2];
																																																																																		h = y[C + 20 >> 2];
																																																																																		G = !g | (h | 0) < 3 ? G : z[i | 0] >>> 5 & 1;
																																																																																		G = !g | (h | 0) < 2 ? G : z[i | 0] >>> 5 & 2 | G;
																																																																																		G = !g | (h | 0) <= 0 ? G : z[i | 0] >>> 5 & 4 | G;
																																																																																		r = 0;
																																																																																		r = !b | (h | 0) < 3 ? r : z[d | 0] >>> 5 & 1;
																																																																																		r = !b | (h | 0) < 2 ? r : z[d | 0] >>> 5 & 2 | r;
																																																																																		r = !b | (h | 0) <= 0 ? r : z[d | 0] >>> 5 & 4 | r;
																																																																																		J = 0;
																																																																																		c = 0;
																																																																																		while (1) {
																																																																																			if (B[V >> 2] <= c >>> 0) {
																																																																																				c = k;
																																																																																				break sb;
																																																																																			}
																																																																																			ub: {
																																																																																				vb: {
																																																																																					if (z[D + 2 | 0] == 1) {
																																																																																						if (ia(y[y[D + 12 >> 2] + 20 >> 2], c, m, _)) {
																																																																																							break vb;
																																																																																						}
																																																																																					}
																																																																																					if (z[v | 0]) {
																																																																																						break rb;
																																																																																					}
																																																																																					h = r << 4 | G << 9 | ia(h, w[D + 16 | 0] + c | 0, P, K) << 3 | J;
																																																																																					if (h >>> 0 >= R >>> 0) {
																																																																																						break fa;
																																																																																					}
																																																																																					F = ka(v, Q + (h << 1) | 0);
																																																																																					h = y[C + 20 >> 2];
																																																																																					if (!F) {
																																																																																						break vb;
																																																																																					}
																																																																																					Ea(h, c, j, u, 1);
																																																																																					h = y[C + 20 >> 2];
																																																																																					H = 1;
																																																																																					break ub;
																																																																																				}
																																																																																				H = 0;
																																																																																			}
																																																																																			F = c + 3 | 0;
																																																																																			G = ia(h, F, i, g) | G << 1 & 14;
																																																																																			r = ia(h, F, d, b) | r << 1 & 30;
																																																																																			c = c + 1 | 0;
																																																																																			J = J << 1 & 6 | H;
																																																																																			continue;
																																																																																		}
																																																																																	}
																																																																																	S = S + 1 | 0;
																																																																																	i = d;
																																																																																	g = b;
																																																																																	d = j;
																																																																																	b = u;
																																																																																	continue;
																																																																																}
																																																																															}
																																																																															C = 0;
																																																																														}
																																																																														break va;
																																																																													}
																																																																													C = 0;
																																																																												}
																																																																												break va;
																																																																											}
																																																																											C = ua(V, U);
																																																																											y[e + 212 >> 2] = C;
																																																																											wb: {
																																																																												xb: {
																																																																													c = y[C + 16 >> 2];
																																																																													if (!c) {
																																																																														break xb;
																																																																													}
																																																																													h = y[C + 12 >> 2];
																																																																													while (1) {
																																																																														if ((c | 0) > 0) {
																																																																															w[h | 0] = 0;
																																																																															c = c - 1 | 0;
																																																																															h = h + 1 | 0;
																																																																															continue;
																																																																														}
																																																																														break;
																																																																													}
																																																																													j = 0;
																																																																													g = 0;
																																																																													b = 0;
																																																																													d = 0;
																																																																													c = 0;
																																																																													S = 0;
																																																																													while (1) {
																																																																														yb: {
																																																																															zb: {
																																																																																if (B[U >> 2] > S >>> 0) {
																																																																																	ja(e + 404 | 0, C, S);
																																																																																	u = y[e + 408 >> 2];
																																																																																	m = y[e + 404 >> 2];
																																																																																	if (z[D + 1 | 0] != 1) {
																																																																																		i = c;
																																																																																		break zb;
																																																																																	}
																																																																																	if (z[v | 0]) {
																																																																																		break xb;
																																																																																	}
																																																																																	if (!Xa) {
																																																																																		break fa;
																																																																																	}
																																																																																	i = 0;
																																																																																	k = ka(v, da);
																																																																																	if ((k | 0) == (c | 0)) {
																																																																																		break zb;
																																																																																	}
																																																																																	y[e + 332 >> 2] = u;
																																																																																	y[e + 328 >> 2] = m;
																																																																																	y[e + 224 >> 2] = d;
																																																																																	y[e + 220 >> 2] = b;
																																																																																	g = y[e + 332 >> 2];
																																																																																	y[e + 56 >> 2] = y[e + 328 >> 2];
																																																																																	y[e + 60 >> 2] = g;
																																																																																	g = y[e + 224 >> 2];
																																																																																	y[e + 48 >> 2] = y[e + 220 >> 2];
																																																																																	y[e + 52 >> 2] = g;
																																																																																	c = c ^ k;
																																																																																	Ca(e + 56 | 0, e + 48 | 0);
																																																																																	break yb;
																																																																																}
																																																																																y[e + 212 >> 2] = 0;
																																																																																break wb;
																																																																															}
																																																																															r = 0;
																																																																															k = 0;
																																																																															_ = 0;
																																																																															if (z[D + 2 | 0] == 1) {
																																																																																ja(e + 404 | 0, y[D + 12 >> 2], S);
																																																																																_ = y[e + 408 >> 2];
																																																																																k = y[e + 404 >> 2];
																																																																															}
																																																																															c = e + 404 | 0;
																																																																															ja(c, C, w[D + 17 | 0] + S | 0);
																																																																															X = y[e + 408 >> 2];
																																																																															$ = y[e + 404 >> 2];
																																																																															ja(c, C, w[D + 19 | 0] + S | 0);
																																																																															s = y[e + 408 >> 2];
																																																																															N = y[e + 404 >> 2];
																																																																															ja(c, C, w[D + 21 | 0] + S | 0);
																																																																															W = y[e + 408 >> 2];
																																																																															H = y[e + 404 >> 2];
																																																																															ja(c, C, w[D + 23 | 0] + S | 0);
																																																																															K = y[e + 408 >> 2];
																																																																															P = y[e + 404 >> 2];
																																																																															h = y[C + 20 >> 2];
																																																																															r = !g | (h | 0) < 2 ? r : z[j | 0] >>> 6 & 1;
																																																																															r = !g | (h | 0) <= 0 ? r : z[j | 0] >>> 6 & 2 | r;
																																																																															G = 0;
																																																																															G = !d | (h | 0) < 3 ? G : z[b | 0] >>> 5 & 1;
																																																																															G = !d | (h | 0) < 2 ? G : z[b | 0] >>> 5 & 2 | G;
																																																																															G = !d | (h | 0) <= 0 ? G : z[b | 0] >>> 5 & 4 | G;
																																																																															J = 0;
																																																																															c = 0;
																																																																															while (1) {
																																																																																if (B[V >> 2] <= c >>> 0) {
																																																																																	c = i;
																																																																																	break yb;
																																																																																}
																																																																																Ab: {
																																																																																	Bb: {
																																																																																		if (z[D + 2 | 0] == 1) {
																																																																																			if (ia(y[y[D + 12 >> 2] + 20 >> 2], c, k, _)) {
																																																																																				break Bb;
																																																																																			}
																																																																																		}
																																																																																		if (z[v | 0]) {
																																																																																			break xb;
																																																																																		}
																																																																																		h = G << 5 | r << 12 | ia(h, w[D + 16 | 0] + c | 0, $, X) << 4 | ia(h, w[D + 18 | 0] + c | 0, N, s) << 10 | ia(h, w[D + 20 | 0] + c | 0, H, W) << 11 | ia(h, w[D + 22 | 0] + c | 0, P, K) << 15 | J;
																																																																																		if (h >>> 0 >= R >>> 0) {
																																																																																			break fa;
																																																																																		}
																																																																																		F = ka(v, Q + (h << 1) | 0);
																																																																																		h = y[C + 20 >> 2];
																																																																																		if (!F) {
																																																																																			break Bb;
																																																																																		}
																																																																																		Ea(h, c, m, u, 1);
																																																																																		h = y[C + 20 >> 2];
																																																																																		F = 1;
																																																																																		break Ab;
																																																																																	}
																																																																																	F = 0;
																																																																																}
																																																																																r = ia(h, c + 2 | 0, j, g) | r << 1 & 6;
																																																																																G = ia(h, c + 3 | 0, b, d) | G << 1 & 30;
																																																																																c = c + 1 | 0;
																																																																																J = J << 1 & 14 | F;
																																																																																continue;
																																																																															}
																																																																														}
																																																																														S = S + 1 | 0;
																																																																														j = b;
																																																																														g = d;
																																																																														b = m;
																																																																														d = u;
																																																																														continue;
																																																																													}
																																																																												}
																																																																												C = 0;
																																																																											}
																																																																											break va;
																																																																										}
																																																																										C = 0;
																																																																									}
																																																																									la(e + 212 | 0);
																																																																									y[e + 404 >> 2] = 0;
																																																																									oa(e + 388 | 0, C);
																																																																									la(e + 404 | 0);
																																																																									b = y[e + 388 >> 2];
																																																																									ta(e + 376 | 0);
																																																																									if (b) {
																																																																										break ua;
																																																																									}
																																																																									break ta;
																																																																								}
																																																																								c = y[Ia >> 2];
																																																																								y[e + 388 >> 2] = 0;
																																																																								oa((I << 2) + c | 0, b);
																																																																							}
																																																																							I = I + 1 | 0;
																																																																							continue;
																																																																						}
																																																																					}
																																																																					break ta;
																																																																				}
																																																																				y[e + 412 >> 2] = 0;
																																																																				y[e + 404 >> 2] = 0;
																																																																				y[e + 408 >> 2] = 0;
																																																																				xd(e + 404 | 0, b + y[l + 4 >> 2] | 0);
																																																																				k = y[e + 404 >> 2];
																																																																				I = 0;
																																																																				b = 0;
																																																																				s = 0;
																																																																				Cb: {
																																																																					while (1) {
																																																																						if (y[l + 8 >> 2] + y[l + 4 >> 2] >>> 0 > b >>> 0) {
																																																																							Aa(M, v, e + 212 | 0);
																																																																							g = y[e + 212 >> 2];
																																																																							c = g + b | 0;
																																																																							if (!(c >>> 0 <= y[l + 8 >> 2] + y[l + 4 >> 2] >>> 0 & c >>> 0 >= g >>> 0)) {
																																																																								b = 0;
																																																																								break Cb;
																																																																							}
																																																																							y[e + 328 >> 2] = k;
																																																																							y[e + 332 >> 2] = 0;
																																																																							d = oc(e + 328 | 0, b);
																																																																							wd(e + 220 | 0, y[d >> 2], y[d + 4 >> 2], g, I);
																																																																							s = (I & 1 ? g : 0) + s | 0;
																																																																							I = I ^ 1;
																																																																							b = c;
																																																																							continue;
																																																																						}
																																																																						break;
																																																																					}
																																																																					b = 0;
																																																																					if (B[l + 12 >> 2] < s >>> 0) {
																																																																						break Cb;
																																																																					}
																																																																					b = nc();
																																																																					i = y[Ia >> 2];
																																																																					c = 0;
																																																																					I = 0;
																																																																					while (1) {
																																																																						d = y[l + 4 >> 2];
																																																																						if (d + y[l + 8 >> 2] >>> 0 <= c >>> 0) {
																																																																							break Cb;
																																																																						}
																																																																						if (!(!(y[k + (c >>> 3 & 536870908) >> 2] >>> c & 1) | B[l + 12 >> 2] <= I >>> 0)) {
																																																																							Db: {
																																																																								if (c >>> 0 < d >>> 0) {
																																																																									d = y[y[ga >> 2] + (c << 2) >> 2];
																																																																									if (!d) {
																																																																										d = 0;
																																																																										break Db;
																																																																									}
																																																																									d = mc(d);
																																																																									break Db;
																																																																								}
																																																																								g = i + (c - d << 2) | 0;
																																																																								d = y[g >> 2];
																																																																								y[g >> 2] = 0;
																																																																							}
																																																																							ud(b, d);
																																																																							I = I + 1 | 0;
																																																																						}
																																																																						c = c + 1 | 0;
																																																																						continue;
																																																																					}
																																																																				}
																																																																				lc(e + 404 | 0);
																																																																				break sa;
																																																																			}
																																																																			la(e + 388 | 0);
																																																																			b = 0;
																																																																		}
																																																																		Za(Ia);
																																																																		rc(Qa);
																																																																		Ba(e + 392 | 0);
																																																																		Ba(e + 396 | 0);
																																																																		Ba(e + 400 | 0);
																																																																		Ba(e + 428 | 0);
																																																																		y[e + 232 >> 2] = 0;
																																																																		Ib(n + 56 | 0, b);
																																																																		Va(e + 232 | 0);
																																																																		if (y[n + 56 >> 2]) {
																																																																			sa(y[a + 4 >> 2]);
																																																																			d = y[a + 4 >> 2];
																																																																			b = y[d + 8 >> 2];
																																																																			if (b >>> 0 <= 4294967293) {
																																																																				c = b + 2 | 0;
																																																																				b = y[d + 4 >> 2];
																																																																				y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																																																																			}
																																																																			ta(e + 344 | 0);
																																																																			break $;
																																																																		}
																																																																		ta(e + 344 | 0);
																																																																		break Z;
																																																																	}
																																																																	la(e + 388 | 0);
																																																																	continue;
																																																																}
																																																															}
																																																															c = y[e + 172 >> 2];
																																																															b = y[e + 176 >> 2];
																																																															M = y[a + 4 >> 2];
																																																															X = td(M);
																																																															y[e + 428 >> 2] = X;
																																																															$ = cb(e + 416 | 0, y[l + 8 >> 2]);
																																																															y[e + 412 >> 2] = 0;
																																																															y[e + 404 >> 2] = 0;
																																																															y[e + 408 >> 2] = 0;
																																																															if (!z[l + 1 | 0]) {
																																																																Rb(e + 404 | 0, y[l + 8 >> 2]);
																																																															}
																																																															N = c;
																																																															i = b - c >> 1;
																																																															y[e + 400 >> 2] = 0;
																																																															y[e + 396 >> 2] = 0;
																																																															g = 0;
																																																															q = 0;
																																																															Eb: {
																																																																while (1) {
																																																																	if (B[l + 8 >> 2] > q >>> 0) {
																																																																		if (ya(X, y[l + 28 >> 2], e + 212 | 0)) {
																																																																			break ba;
																																																																		}
																																																																		g = y[e + 212 >> 2] + g | 0;
																																																																		y[e + 400 >> 2] = g;
																																																																		if (g >>> 0 > 65535) {
																																																																			break ba;
																																																																		}
																																																																		I = 0;
																																																																		y[e + 392 >> 2] = 0;
																																																																		k = 0;
																																																																		c = q;
																																																																		while (1) {
																																																																			Fb: {
																																																																				b = ya(X, y[l + 32 >> 2], e + 388 | 0);
																																																																				y[e + 384 >> 2] = b;
																																																																				Gb: {
																																																																					switch (b | 0) {
																																																																						case 0: break Gb;
																																																																						case 1: break Fb;
																																																																						default: break ca;
																																																																					}
																																																																				}
																																																																				if (B[l + 8 >> 2] <= c >>> 0) {
																																																																					break ca;
																																																																				}
																																																																				I = y[e + 388 >> 2] + I | 0;
																																																																				if (I >>> 0 > 65535) {
																																																																					break ca;
																																																																				}
																																																																				k = k + I | 0;
																																																																				Hb: {
																																																																					if (!I | !g) {
																																																																						break Hb;
																																																																					}
																																																																					if (z[l + 1 | 0] == 1) {
																																																																						if (ya(X, y[l + 40 >> 2], e + 380 | 0)) {
																																																																							break ca;
																																																																						}
																																																																						oa(e + 396 | 0, 0);
																																																																						d = y[e + 380 >> 2];
																																																																						Ib: {
																																																																							if (d >>> 0 >= 2) {
																																																																								H = xa(6);
																																																																								y[e + 376 >> 2] = H;
																																																																								K = xa(8);
																																																																								y[e + 372 >> 2] = K;
																																																																								P = xa(11);
																																																																								y[e + 368 >> 2] = P;
																																																																								ea = xa(15);
																																																																								y[e + 364 >> 2] = ea;
																																																																								F = xa(15);
																																																																								y[e + 360 >> 2] = F;
																																																																								u = xa(15);
																																																																								y[e + 356 >> 2] = u;
																																																																								m = xa(15);
																																																																								y[e + 352 >> 2] = m;
																																																																								j = xa(1);
																																																																								y[e + 348 >> 2] = j;
																																																																								L = Qb();
																																																																								y[e + 344 >> 2] = L;
																																																																								b = z[l | 0];
																																																																								y[L + 20 >> 2] = 1;
																																																																								y[L + 16 >> 2] = d;
																																																																								y[L + 12 >> 2] = g;
																																																																								y[L + 8 >> 2] = I;
																																																																								w[L + 1 | 0] = 1;
																																																																								w[L | 0] = b;
																																																																								b = y[l + 4 >> 2];
																																																																								h = b + c | 0;
																																																																								y[L + 24 >> 2] = h;
																																																																								d = ib(b + y[l + 8 >> 2] | 0);
																																																																								y[e + 336 >> 2] = 0;
																																																																								y[e + 328 >> 2] = 0;
																																																																								y[e + 332 >> 2] = 0;
																																																																								b = e + 328 | 0;
																																																																								y[e + 232 >> 2] = b;
																																																																								if (h) {
																																																																									d = d >>> 0 <= 1 ? 1 : d;
																																																																									Kd(b, h);
																																																																									b = y[e + 332 >> 2];
																																																																									h = h + b | 0;
																																																																									while (1) {
																																																																										if ((b | 0) != (h | 0)) {
																																																																											w[b | 0] = d;
																																																																											b = b + 1 | 0;
																																																																											continue;
																																																																										}
																																																																										break;
																																																																									}
																																																																									y[e + 332 >> 2] = h;
																																																																								}
																																																																								w[e + 236 | 0] = 1;
																																																																								d = e + 232 | 0;
																																																																								gc(d);
																																																																								b = y[e + 328 >> 2];
																																																																								b = tc(d, b, y[e + 332 >> 2] - b | 0);
																																																																								Id(L + 28 | 0, b);
																																																																								Oa(b);
																																																																								s = Kb(d, y[L + 24 >> 2]);
																																																																								b = y[l + 4 >> 2];
																																																																								d = y[l + 16 >> 2];
																																																																								if (b >>> 0 > y[l + 20 >> 2] - d >> 2 >>> 0) {
																																																																									break ea;
																																																																								}
																																																																								W = y[s >> 2];
																																																																								zd(d, b, W, y[e + 236 >> 2] - W >> 2);
																																																																								h = y[$ >> 2];
																																																																								b = 0;
																																																																								while (1) if ((b | 0) == (c | 0)) {
																																																																									$a(L + 124 | 0, s);
																																																																									x[L + 4 >> 1] = 0;
																																																																									y[L + 136 >> 2] = 0;
																																																																									y[L + 140 >> 2] = 1;
																																																																									w[L + 3 | 0] = 0;
																																																																									y[L + 172 >> 2] = j;
																																																																									y[L + 168 >> 2] = m;
																																																																									y[L + 164 >> 2] = u;
																																																																									y[L + 160 >> 2] = F;
																																																																									y[L + 156 >> 2] = ea;
																																																																									y[L + 152 >> 2] = P;
																																																																									y[L + 148 >> 2] = K;
																																																																									y[L + 144 >> 2] = H;
																																																																									w[L + 2 | 0] = z[l + 2 | 0];
																																																																									w[L + 176 | 0] = z[l + 52 | 0];
																																																																									w[L + 177 | 0] = z[l + 53 | 0];
																																																																									w[L + 178 | 0] = z[l + 54 | 0];
																																																																									w[L + 179 | 0] = z[l + 55 | 0];
																																																																									b = Gd(L, M, N, i);
																																																																									y[e + 228 >> 2] = 0;
																																																																									oa(e + 396 | 0, b);
																																																																									la(e + 228 | 0);
																																																																									b = y[e + 396 >> 2];
																																																																									va(s);
																																																																									va(e + 328 | 0);
																																																																									qc(e + 344 | 0);
																																																																									pa(e + 348 | 0);
																																																																									pa(e + 352 | 0);
																																																																									pa(e + 356 | 0);
																																																																									pa(e + 360 | 0);
																																																																									pa(e + 364 | 0);
																																																																									pa(e + 368 | 0);
																																																																									pa(e + 372 | 0);
																																																																									pa(e + 376 | 0);
																																																																									if (b) {
																																																																										break Ib;
																																																																									}
																																																																									break ca;
																																																																								} else {
																																																																									d = b << 2;
																																																																									y[(d + W | 0) + (y[l + 4 >> 2] << 2) >> 2] = y[d + h >> 2];
																																																																									b = b + 1 | 0;
																																																																									continue;
																																																																								}
																																																																							}
																																																																							if ((d | 0) != 1) {
																																																																								h = y[$ >> 2];
																																																																								b = y[e + 396 >> 2];
																																																																								break Ib;
																																																																							}
																																																																							d = y[l + 4 >> 2];
																																																																							b = y[l + 8 >> 2];
																																																																							y[e + 232 >> 2] = 0;
																																																																							b = ib(b + d | 0);
																																																																							if (Fa(M, b >>> 0 <= 1 ? 1 : b, e + 232 | 0)) {
																																																																								break ca;
																																																																							}
																																																																							d = y[e + 232 >> 2];
																																																																							b = y[l + 4 >> 2];
																																																																							if (d >>> 0 >= b + c >>> 0) {
																																																																								break ca;
																																																																							}
																																																																							h = y[$ >> 2];
																																																																							if (b >>> 0 > d >>> 0) {
																																																																								b = y[ga >> 2] + (d << 2) | 0;
																																																																							} else {
																																																																								b = d - b | 0;
																																																																								if (b >>> 0 >= y[$ + 4 >> 2] - h >> 2 >>> 0) {
																																																																									break ea;
																																																																								}
																																																																								b = (b << 2) + h | 0;
																																																																							}
																																																																							d = y[b >> 2];
																																																																							if (!d) {
																																																																								break ca;
																																																																							}
																																																																							j = xa(15);
																																																																							y[e + 328 >> 2] = j;
																																																																							b = xa(1);
																																																																							y[e + 376 >> 2] = b;
																																																																							Jb: {
																																																																								Kb: {
																																																																									if (ya(X, j, e + 372 | 0)) {
																																																																										break Kb;
																																																																									}
																																																																									if (ya(X, j, e + 368 | 0)) {
																																																																										break Kb;
																																																																									}
																																																																									if (!ya(X, b, e + 384 | 0)) {
																																																																										break Jb;
																																																																									}
																																																																								}
																																																																								y[e + 392 >> 2] = k;
																																																																								pa(e + 376 | 0);
																																																																								pa(e + 328 | 0);
																																																																								break ba;
																																																																							}
																																																																							sa(M);
																																																																							m = y[M + 8 >> 2];
																																																																							j = kb();
																																																																							y[e + 364 >> 2] = j;
																																																																							y[j + 8 >> 2] = g;
																																																																							y[j + 4 >> 2] = I;
																																																																							b = z[l + 2 | 0];
																																																																							y[j + 20 >> 2] = d;
																																																																							w[j | 0] = b;
																																																																							y[j + 12 >> 2] = y[e + 372 >> 2];
																																																																							b = y[e + 368 >> 2];
																																																																							d = 0;
																																																																							w[j + 1 | 0] = 0;
																																																																							y[j + 16 >> 2] = b;
																																																																							w[j + 24 | 0] = z[l + 52 | 0];
																																																																							w[j + 25 | 0] = z[l + 53 | 0];
																																																																							w[j + 26 | 0] = z[l + 54 | 0];
																																																																							w[j + 27 | 0] = z[l + 55 | 0];
																																																																							b = Na(M);
																																																																							y[e + 360 >> 2] = b;
																																																																							b = jb(j, b, N, i);
																																																																							y[e + 356 >> 2] = 0;
																																																																							oa(e + 396 | 0, b);
																																																																							la(e + 356 | 0);
																																																																							b = y[e + 396 >> 2];
																																																																							if (b) {
																																																																								sa(M);
																																																																								d = y[M + 8 >> 2];
																																																																								if (d >>> 0 <= 4294967293) {
																																																																									j = d + 2 | 0;
																																																																									d = y[M + 4 >> 2];
																																																																									d = d >>> 0 > j >>> 0 ? j : d;
																																																																									y[M + 8 >> 2] = d;
																																																																								}
																																																																								d = y[e + 384 >> 2] == (d - m | 0);
																																																																							}
																																																																							ta(e + 360 | 0);
																																																																							Ua(e + 364 | 0);
																																																																							pa(e + 376 | 0);
																																																																							pa(e + 328 | 0);
																																																																							if (!d) {
																																																																								break ca;
																																																																							}
																																																																						}
																																																																						y[e + 396 >> 2] = 0;
																																																																						oa((c << 2) + h | 0, b);
																																																																						if (z[l + 1 | 0]) {
																																																																							break Hb;
																																																																						}
																																																																					}
																																																																					y[y[e + 404 >> 2] + (c << 2) >> 2] = I;
																																																																				}
																																																																				c = c + 1 | 0;
																																																																				continue;
																																																																			}
																																																																			break;
																																																																		}
																																																																		y[e + 392 >> 2] = k;
																																																																		if (!z[l + 1 | 0]) {
																																																																			if (ya(X, y[l + 36 >> 2], e + 232 | 0)) {
																																																																				break ba;
																																																																			}
																																																																			sa(M);
																																																																			y[e + 328 >> 2] = 0;
																																																																			Lb: {
																																																																				if (!y[e + 232 >> 2]) {
																																																																					if ((k | 0) > 65535) {
																																																																						break Eb;
																																																																					}
																																																																					j = k + 7 >>> 3 | 0;
																																																																					b = ze(j, 0, g, 0);
																																																																					if (Z) {
																																																																						break Eb;
																																																																					}
																																																																					k = y[M + 4 >> 2];
																																																																					d = y[M + 8 >> 2];
																																																																					if (k >>> 0 < d >>> 0) {
																																																																						break fa;
																																																																					}
																																																																					if (b >>> 0 > k - d >>> 0) {
																																																																						break Eb;
																																																																					}
																																																																					I = 0;
																																																																					b = ua(e + 392 | 0, e + 400 | 0);
																																																																					y[e + 388 >> 2] = 0;
																																																																					oa(e + 328 | 0, b);
																																																																					la(e + 388 | 0);
																																																																					s = y[e + 328 >> 2];
																																																																					while (1) {
																																																																						if ((g | 0) == (I | 0)) {
																																																																							break Lb;
																																																																						}
																																																																						ja(e + 220 | 0, s, I);
																																																																						d = y[M + 8 >> 2];
																																																																						b = y[M + 4 >> 2];
																																																																						if (d >>> 0 > b >>> 0 | j >>> 0 > b - d >>> 0 | j >>> 0 > B[e + 224 >> 2]) {
																																																																							break fa;
																																																																						}
																																																																						if (j) {
																																																																							if (j) {
																																																																								p(y[e + 220 >> 2], y[M >> 2] + d | 0, j);
																																																																							}
																																																																							d = y[M + 8 >> 2];
																																																																						}
																																																																						b = d;
																																																																						d = d + j | 0;
																																																																						if (b >>> 0 <= d >>> 0) {
																																																																							b = y[M + 4 >> 2];
																																																																							y[M + 8 >> 2] = b >>> 0 > d >>> 0 ? d : b;
																																																																						}
																																																																						I = I + 1 | 0;
																																																																						continue;
																																																																					}
																																																																				}
																																																																				b = lb();
																																																																				y[e + 388 >> 2] = b;
																																																																				y[b + 8 >> 2] = g;
																																																																				y[b + 4 >> 2] = k;
																																																																				w[b | 0] = 1;
																																																																				db(b, e + 328 | 0, M);
																																																																				sa(M);
																																																																				ta(e + 388 | 0);
																																																																				s = y[e + 328 >> 2];
																																																																			}
																																																																			Mb: {
																																																																				if (!s) {
																																																																					break Mb;
																																																																				}
																																																																				u = c >>> 0 < q >>> 0 ? q : c;
																																																																				m = y[$ >> 2];
																																																																				b = 0;
																																																																				h = y[e + 404 >> 2];
																																																																				while (1) {
																																																																					if ((q | 0) == (u | 0)) {
																																																																						break Mb;
																																																																					}
																																																																					j = q << 2;
																																																																					k = j + h | 0;
																																																																					d = nb(s, b, 0, y[k >> 2], g);
																																																																					y[e + 388 >> 2] = 0;
																																																																					oa(j + m | 0, d);
																																																																					q = q + 1 | 0;
																																																																					la(e + 388 | 0);
																																																																					b = y[k >> 2] + b | 0;
																																																																					continue;
																																																																				}
																																																																			}
																																																																			la(e + 328 | 0);
																																																																		}
																																																																		q = c;
																																																																		continue;
																																																																	}
																																																																	break;
																																																																}
																																																																i = xa(1);
																																																																y[e + 392 >> 2] = i;
																																																																y[e + 240 >> 2] = 0;
																																																																y[e + 232 >> 2] = 0;
																																																																y[e + 236 >> 2] = 0;
																																																																xd(e + 232 | 0, y[l + 8 >> 2] + y[l + 4 >> 2] | 0);
																																																																k = y[e + 232 >> 2];
																																																																c = 0;
																																																																b = 0;
																																																																h = 0;
																																																																while (1) {
																																																																	if (y[l + 8 >> 2] + y[l + 4 >> 2] >>> 0 > b >>> 0) {
																																																																		Nb: {
																																																																			Ob: {
																																																																				if (ya(X, i, e + 388 | 0)) {
																																																																					break Ob;
																																																																				}
																																																																				j = y[e + 388 >> 2];
																																																																				d = j + b | 0;
																																																																				if (d >>> 0 < j >>> 0) {
																																																																					break Ob;
																																																																				}
																																																																				if (d >>> 0 <= y[l + 8 >> 2] + y[l + 4 >> 2] >>> 0) {
																																																																					break Nb;
																																																																				}
																																																																			}
																																																																			b = 0;
																																																																			break da;
																																																																		}
																																																																		y[e + 328 >> 2] = k;
																																																																		y[e + 332 >> 2] = 0;
																																																																		g = oc(e + 328 | 0, b);
																																																																		wd(e + 212 | 0, y[g >> 2], y[g + 4 >> 2], j, c);
																																																																		h = (c & 1 ? j : 0) + h | 0;
																																																																		c = c ^ 1;
																																																																		b = d;
																																																																		continue;
																																																																	}
																																																																	break;
																																																																}
																																																																b = 0;
																																																																if (B[l + 12 >> 2] < h >>> 0) {
																																																																	break da;
																																																																}
																																																																b = nc();
																																																																i = y[$ >> 2];
																																																																c = 0;
																																																																I = 0;
																																																																while (1) {
																																																																	d = y[l + 4 >> 2];
																																																																	if (d + y[l + 8 >> 2] >>> 0 <= c >>> 0) {
																																																																		break da;
																																																																	}
																																																																	if (!(!(y[k + (c >>> 3 & 536870908) >> 2] >>> c & 1) | B[l + 12 >> 2] <= I >>> 0)) {
																																																																		Pb: {
																																																																			if (c >>> 0 < d >>> 0) {
																																																																				d = y[y[ga >> 2] + (c << 2) >> 2];
																																																																				if (!d) {
																																																																					d = 0;
																																																																					break Pb;
																																																																				}
																																																																				d = mc(d);
																																																																				break Pb;
																																																																			}
																																																																			g = i + (c - d << 2) | 0;
																																																																			d = y[g >> 2];
																																																																			y[g >> 2] = 0;
																																																																		}
																																																																		ud(b, d);
																																																																		I = I + 1 | 0;
																																																																	}
																																																																	c = c + 1 | 0;
																																																																	continue;
																																																																}
																																																															}
																																																															la(e + 328 | 0);
																																																															break ba;
																																																														}
																																																														o();
																																																													}
																																																													y[e + 392 >> 2] = k;
																																																													o();
																																																												}
																																																												lc(e + 232 | 0);
																																																												pa(e + 392 | 0);
																																																												break aa;
																																																											}
																																																											y[e + 392 >> 2] = k;
																																																										}
																																																										b = 0;
																																																									}
																																																									la(e + 396 | 0);
																																																									va(e + 404 | 0);
																																																									Za($);
																																																									Ua(e + 428 | 0);
																																																									y[e + 232 >> 2] = 0;
																																																									Ib(n + 56 | 0, b);
																																																									Va(e + 232 | 0);
																																																									if (!y[n + 56 >> 2]) {
																																																										break Z;
																																																									}
																																																									sa(y[a + 4 >> 2]);
																																																								}
																																																								if (z[a + 48 | 0] != 1) {
																																																									break _;
																																																								}
																																																								tb = e, ub = Dd(y[n + 56 >> 2]), y[tb + 232 >> 2] = ub;
																																																								b = y[a + 108 >> 2];
																																																								c = y[b + 8 >> 2];
																																																								while (1) {
																																																									if (c >>> 0 >= 2) {
																																																										i = y[b >> 2];
																																																										g = y[i >> 2];
																																																										d = y[i + 4 >> 2];
																																																										y[g + 4 >> 2] = d;
																																																										y[d >> 2] = g;
																																																										y[b + 8 >> 2] = y[b + 8 >> 2] - 1;
																																																										pc(i);
																																																										c = c - 1 | 0;
																																																										b = y[a + 108 >> 2];
																																																										continue;
																																																									}
																																																									break;
																																																								}
																																																								c = b;
																																																								b = e + 232 | 0;
																																																								Cd(c, e + 152 | 0, b);
																																																								Va(b);
																																																							}
																																																							c = 0;
																																																							if (!(z[e + 211 | 0] & 2)) {
																																																								break Y;
																																																							}
																																																							if (!(hb & 1)) {
																																																								g = y[n + 56 >> 2];
																																																								y[e + 140 >> 2] = y[e + 184 >> 2];
																																																								d = y[e + 188 >> 2];
																																																								b = y[e + 192 >> 2];
																																																								y[e + 188 >> 2] = 0;
																																																								y[e + 192 >> 2] = 0;
																																																								y[e + 144 >> 2] = d;
																																																								y[e + 148 >> 2] = b;
																																																								y[e + 184 >> 2] = 0;
																																																								b = e + 140 | 0;
																																																								_a(g, b);
																																																								Ha(b);
																																																							}
																																																							if (!(O & 1)) {
																																																								break Y;
																																																							}
																																																							g = y[n + 56 >> 2];
																																																							y[e + 128 >> 2] = y[e + 172 >> 2];
																																																							d = y[e + 176 >> 2];
																																																							b = y[e + 180 >> 2];
																																																							y[e + 176 >> 2] = 0;
																																																							y[e + 180 >> 2] = 0;
																																																							y[e + 132 >> 2] = d;
																																																							y[e + 136 >> 2] = b;
																																																							y[e + 172 >> 2] = 0;
																																																							b = e + 128 | 0;
																																																							_a(g + 12 | 0, b);
																																																							Ha(b);
																																																							break Y;
																																																						}
																																																						c = 1;
																																																					}
																																																					Ha(e + 172 | 0);
																																																					Ha(e + 184 | 0);
																																																				}
																																																				va(gb);
																																																				break U;
																																																			} else {
																																																				c = Ka(a, y[y[n + 12 >> 2] + (b << 2) >> 2]);
																																																				if (!(z[c + 4 | 0] & 63)) {
																																																					j = 0;
																																																					i = 0;
																																																					if (I & 1) {
																																																						d = y[c + 56 >> 2];
																																																						g = y[d + 28 >> 2] - y[d + 24 >> 2] >> 2;
																																																						d = g + h | 0;
																																																						i = d;
																																																						d = d >>> 0 >= g >>> 0;
																																																						i = d ? i : 0;
																																																					} else {
																																																						d = j;
																																																					}
																																																					I = d;
																																																					q = c;
																																																					h = i;
																																																				}
																																																				b = b + 1 | 0;
																																																				continue;
																																																			}
																																																		}
																																																		d = b << 2;
																																																		b = b + 1 | 0;
																																																		if (Ka(a, y[d + y[n + 12 >> 2] >> 2])) {
																																																			continue;
																																																		}
																																																		break;
																																																	}
																																																}
																																																va(ga);
																																																ma(l);
																																															}
																																															Y = e + 432 | 0;
																																															b = c;
																																															break u;
																																														case 1:
																																														case 2:
																																														case 3:
																																														case 5: break B;
																																														case 4:
																																														case 6:
																																														case 7: break T;
																																														default: break G;
																																													}
																																												}
																																												b = 1;
																																												if (z[a + 49 | 0] != 1) {
																																													break u;
																																												}
																																												if (ob(a, f + 120 | 0)) {
																																													break u;
																																												}
																																												i = f + 142 | 0;
																																												if (Sa(y[a + 4 >> 2], i)) {
																																													break u;
																																												}
																																												c = y[f + 120 >> 2];
																																												if (c - 1 >>> 0 > 65534) {
																																													break u;
																																												}
																																												u = y[f + 124 >> 2];
																																												if (u - 1 >>> 0 > 65534) {
																																													break u;
																																												}
																																												h = Qb();
																																												y[f + 116 >> 2] = h;
																																												y[h + 12 >> 2] = u;
																																												y[h + 8 >> 2] = c;
																																												k = A[f + 142 >> 1];
																																												g = k & 1;
																																												w[h | 0] = g;
																																												w[h + 2 | 0] = k >>> 15;
																																												y[h + 140 >> 2] = k >>> 4 & 3;
																																												y[h + 136 >> 2] = k >>> 7 & 3;
																																												w[h + 3 | 0] = k >>> 6 & 1;
																																												w[h + 4 | 0] = k >>> 9 & 1;
																																												y[h + 20 >> 2] = 1 << (k >>> 2 & 3);
																																												d = (k & 254) >>> 1 & 1;
																																												w[h + 1 | 0] = d;
																																												c = k >>> 10 & 31;
																																												w[h + 5 | 0] = (c >>> 0 > 15 ? -32 : 0) | c;
																																												Qb: {
																																													if (g) {
																																														if (Sa(y[a + 4 >> 2], i)) {
																																															break v;
																																														}
																																														if (z[h + 1 | 0] != 1) {
																																															break w;
																																														}
																																														if (!z[h + 2 | 0]) {
																																															break Qb;
																																														}
																																														break w;
																																													}
																																													if (!d | k << 16 >> 16 < 0) {
																																														break w;
																																													}
																																												}
																																												g = h + 176 | 0;
																																												c = 0;
																																												while (1) {
																																													if ((c | 0) == 4) {
																																														break w;
																																													}
																																													d = c + g | 0;
																																													c = c + 1 | 0;
																																													if (!wa(y[a + 4 >> 2], d)) {
																																														continue;
																																													}
																																													break;
																																												}
																																												break v;
																																											}
																																											h = na(12);
																																											y[h + 8 >> 2] = 0;
																																											y[h >> 2] = 0;
																																											y[h + 4 >> 2] = 0;
																																											if (wa(y[a + 4 >> 2], f + 292 | 0)) {
																																												break y;
																																											}
																																											b = 1;
																																											if (wa(y[a + 4 >> 2], h + 1 | 0)) {
																																												break x;
																																											}
																																											if (wa(y[a + 4 >> 2], h + 2 | 0)) {
																																												break x;
																																											}
																																											if (qa(y[a + 4 >> 2], h + 4 | 0)) {
																																												break x;
																																											}
																																											j = y[h + 4 >> 2];
																																											if (j >>> 0 > 65535) {
																																												break x;
																																											}
																																											c = z[f + 292 | 0];
																																											b = c & 1;
																																											w[h | 0] = b;
																																											k = c >>> 1 & 3;
																																											w[h + 8 | 0] = k;
																																											y[n + 52 >> 2] = 3;
																																											if (b) {
																																												b = y[a + 4 >> 2];
																																												c = xc(h);
																																												y[f + 160 >> 2] = c;
																																												if (c) {
																																													y[f + 8 >> 2] = 0;
																																													db(c, f + 8 | 0, b);
																																													Rb: {
																																														i = y[f + 8 >> 2];
																																														if (!i) {
																																															break Rb;
																																														}
																																														g = wc(j + 1 | 0);
																																														b = 0;
																																														while (1) {
																																															if (b >>> 0 > j >>> 0) {
																																																break Rb;
																																															}
																																															c = z[h + 1 | 0];
																																															d = nb(i, E(c, b), 0, c, z[h + 2 | 0]);
																																															c = y[g + 4 >> 2];
																																															y[f + 256 >> 2] = 0;
																																															oa((b << 2) + c | 0, d);
																																															b = b + 1 | 0;
																																															la(f + 256 | 0);
																																															continue;
																																														}
																																													}
																																													la(f + 8 | 0);
																																												}
																																												ta(f + 160 | 0);
																																												y[f + 8 >> 2] = 0;
																																												Pb(n + 60 | 0, g);
																																												Sb(f + 8 | 0);
																																												if (!y[n + 60 >> 2]) {
																																													break y;
																																												}
																																												sa(y[a + 4 >> 2]);
																																												b = 0;
																																												break x;
																																											}
																																											mb(f + 8 | 0, k ? (k | 0) == 1 ? 8192 : 1024 : 65536);
																																											d = Na(y[a + 4 >> 2]);
																																											y[f + 104 >> 2] = d;
																																											b = y[f + 8 >> 2];
																																											c = y[f + 12 >> 2];
																																											m = xc(h);
																																											y[f + 256 >> 2] = m;
																																											if (!m) {
																																												break z;
																																											}
																																											w[m + 1 | 0] = 0;
																																											w[m + 2 | 0] = 0;
																																											w[m + 3 | 0] = k;
																																											i = z[h + 1 | 0];
																																											w[m + 17 | 0] = 0;
																																											w[m + 16 | 0] = 0 - i;
																																											if (!k) {
																																												x[m + 22 >> 1] = 65278;
																																												x[m + 18 >> 1] = 65533;
																																												x[m + 20 >> 1] = 65026;
																																											}
																																											y[f + 120 >> 2] = 0;
																																											y[f + 176 >> 2] = 0;
																																											y[f + 168 >> 2] = b;
																																											y[f + 172 >> 2] = c;
																																											y[f + 164 >> 2] = d;
																																											y[f + 160 >> 2] = f + 120;
																																											b = Ob(m, f + 160 | 0);
																																											y[f + 176 >> 2] = 0;
																																											while (1) {
																																												if ((b | 0) == 3) {
																																													b = Nb(m, f + 160 | 0);
																																													continue;
																																												}
																																												break;
																																											}
																																											y[m + 44 >> 2] = 0;
																																											y[m + 48 >> 2] = 0;
																																											y[m + 36 >> 2] = 0;
																																											y[m + 40 >> 2] = 0;
																																											y[m + 28 >> 2] = 0;
																																											y[m + 32 >> 2] = 0;
																																											if (!y[f + 120 >> 2]) {
																																												break A;
																																											}
																																											g = wc(j + 1 | 0);
																																											b = 0;
																																											while (1) {
																																												if (b >>> 0 > j >>> 0) {
																																													break A;
																																												}
																																												d = nb(y[f + 120 >> 2], E(b, i), 0, i, z[h + 2 | 0]);
																																												c = y[g + 4 >> 2];
																																												y[f + 148 >> 2] = 0;
																																												oa((b << 2) + c | 0, d);
																																												b = b + 1 | 0;
																																												la(f + 148 | 0);
																																												continue;
																																											}
																																										}
																																										b = 1;
																																										if (z[a + 49 | 0] != 1) {
																																											break u;
																																										}
																																										O = na(56);
																																										y[O + 16 >> 2] = 0;
																																										Sb: {
																																											if (ob(a, f + 256 | 0)) {
																																												break Sb;
																																											}
																																											if (wa(y[a + 4 >> 2], f + 144 | 0)) {
																																												break Sb;
																																											}
																																											q = O + 32 | 0;
																																											if (qa(y[a + 4 >> 2], q)) {
																																												break Sb;
																																											}
																																											h = O + 36 | 0;
																																											if (qa(y[a + 4 >> 2], h)) {
																																												break Sb;
																																											}
																																											if (qa(y[a + 4 >> 2], O + 40 | 0)) {
																																												break Sb;
																																											}
																																											if (qa(y[a + 4 >> 2], O + 44 | 0)) {
																																												break Sb;
																																											}
																																											if (Sa(y[a + 4 >> 2], O + 48 | 0)) {
																																												break Sb;
																																											}
																																											if (Sa(y[a + 4 >> 2], O + 50 | 0)) {
																																												break Sb;
																																											}
																																											H = y[q >> 2];
																																											if (H - 1 >>> 0 > 65534) {
																																												break Sb;
																																											}
																																											K = y[h >> 2];
																																											if (K - 1 >>> 0 > 65534) {
																																												break Sb;
																																											}
																																											k = y[f + 256 >> 2];
																																											if (k - 1 >>> 0 > 65534) {
																																												break Sb;
																																											}
																																											X = y[f + 260 >> 2];
																																											if (X - 1 >>> 0 > 65534) {
																																												break Sb;
																																											}
																																											y[O + 4 >> 2] = X;
																																											y[O >> 2] = k;
																																											g = z[f + 144 | 0];
																																											ha = g & 1;
																																											w[O + 8 | 0] = ha;
																																											w[O + 20 | 0] = g >>> 7;
																																											j = g >>> 3 | 0;
																																											Xa = j & 1;
																																											w[O + 28 | 0] = Xa;
																																											aa = g >>> 1 & 3;
																																											w[O + 9 | 0] = aa;
																																											d = g >>> 4 | 0;
																																											y[O + 24 >> 2] = (d & 7) == 4 ? 4 : d & 3;
																																											if (y[n + 8 >> 2] != 1) {
																																												break Sb;
																																											}
																																											d = Ka(a, y[y[n + 12 >> 2] >> 2]);
																																											if (!d | (z[d + 4 | 0] & 63) != 16) {
																																												break Sb;
																																											}
																																											d = y[d + 60 >> 2];
																																											if (!d) {
																																												break Sb;
																																											}
																																											da = y[d >> 2];
																																											if (!da) {
																																												break Sb;
																																											}
																																											y[O + 12 >> 2] = da;
																																											y[O + 16 >> 2] = d + 4;
																																											b = y[y[d + 4 >> 2] >> 2];
																																											i = y[b + 20 >> 2];
																																											w[O + 52 | 0] = i;
																																											d = y[b + 24 >> 2];
																																											w[O + 53 | 0] = d;
																																											y[n + 52 >> 2] = 1;
																																											Tb: {
																																												Ub: {
																																													Vb: {
																																														if (g & 1) {
																																															j = y[a + 4 >> 2];
																																															b = 1;
																																															while (1) {
																																																c = b;
																																																b = b + 1 | 0;
																																																if (da >>> 0 > 1 << c >>> 0) {
																																																	continue;
																																																}
																																																break;
																																															}
																																															x[f + 216 >> 1] = 0;
																																															y[f + 172 >> 2] = 0;
																																															y[f + 184 >> 2] = 0;
																																															y[f + 188 >> 2] = 0;
																																															y[f + 192 >> 2] = 0;
																																															y[f + 196 >> 2] = 0;
																																															y[f + 200 >> 2] = 0;
																																															y[f + 204 >> 2] = 0;
																																															y[f + 208 >> 2] = 0;
																																															y[f + 220 >> 2] = 0;
																																															y[f + 224 >> 2] = 0;
																																															y[f + 228 >> 2] = 0;
																																															y[f + 232 >> 2] = 0;
																																															y[f + 236 >> 2] = 0;
																																															y[f + 168 >> 2] = K;
																																															y[f + 164 >> 2] = H;
																																															w[f + 160 | 0] = ha;
																																															d = c & 255;
																																															i = cb(f + 8 | 0, d);
																																															g = y[i >> 2];
																																															b = (g + (d << 2) | 0) - 4 | 0;
																																															db(f + 160 | 0, b, j);
																																															c = 0;
																																															Wb: {
																																																if (!y[b >> 2]) {
																																																	break Wb;
																																																}
																																																sa(j);
																																																b = y[j + 8 >> 2];
																																																if (b >>> 0 <= 4294967292) {
																																																	c = b + 3 | 0;
																																																	b = y[j + 4 >> 2];
																																																	y[j + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																																																}
																																																b = d - 2 | 0;
																																																while (1) {
																																																	if ((b | 0) >= 0) {
																																																		k = g + (b << 2) | 0;
																																																		db(f + 160 | 0, k, j);
																																																		c = 0;
																																																		if (!y[k >> 2]) {
																																																			break Wb;
																																																		}
																																																		sa(j);
																																																		c = y[j + 8 >> 2];
																																																		if (c >>> 0 <= 4294967292) {
																																																			d = c + 3 | 0;
																																																			c = y[j + 4 >> 2];
																																																			y[j + 8 >> 2] = c >>> 0 > d >>> 0 ? d : c;
																																																		}
																																																		bb(y[k >> 2], 0, 0, 0, 0, y[k + 4 >> 2], 2);
																																																		b = b - 1 | 0;
																																																		continue;
																																																	}
																																																	break;
																																																}
																																																c = vc(O, i);
																																															}
																																															Za(i);
																																															y[f + 120 >> 2] = 0;
																																															oa(n - -64 | 0, c);
																																															la(f + 120 | 0);
																																															if (!y[n + 64 >> 2]) {
																																																break Tb;
																																															}
																																															sa(y[a + 4 >> 2]);
																																															break Vb;
																																														}
																																														mb(f + 148 | 0, aa ? (aa | 0) == 1 ? 8192 : 1024 : 65536);
																																														Ya = Na(y[a + 4 >> 2]);
																																														y[f + 300 >> 2] = Ya;
																																														s = y[f + 148 >> 2];
																																														rb = y[f + 152 >> 2];
																																														g = 0;
																																														y[f + 104 >> 2] = 0;
																																														Xb: {
																																															if (!(j & 1)) {
																																																break Xb;
																																															}
																																															b = ua(q, h);
																																															y[f + 160 >> 2] = 0;
																																															oa(f + 104 | 0, b);
																																															b = d & 255;
																																															N = 1 - b | 0;
																																															Ma = 0 - (b >>> 0 > 1) | 0;
																																															b = i & 255;
																																															W = 1 - b | 0;
																																															Pa = 0 - (b >>> 0 > 1) | 0;
																																															la(f + 160 | 0);
																																															h = X;
																																															g = y[f + 104 >> 2];
																																															Yb: while (1) {
																																																if (!c & (m | 0) == (K | 0)) {
																																																	break Xb;
																																																}
																																																ja(f + 160 | 0, g, m);
																																																b = y[O + 44 >> 2];
																																																P = A[O + 48 >> 1];
																																																d = ze(m, c, P, 0);
																																																$ = b + d | 0;
																																																b = Z + (b >> 31) | 0;
																																																ea = d >>> 0 > $ >>> 0 ? b + 1 | 0 : b;
																																																d = y[O + 40 >> 2];
																																																I = A[O + 50 >> 1];
																																																b = ze(m, c, I, 0);
																																																F = d + b | 0;
																																																d = Z + (d >> 31) | 0;
																																																l = b >>> 0 > F >>> 0 ? d + 1 | 0 : d;
																																																j = 0;
																																																i = 0;
																																																q = y[f + 164 >> 2];
																																																u = y[f + 160 >> 2];
																																																while (1) if (!i & (j | 0) == (H | 0)) {
																																																	b = c;
																																																	d = m + 1 | 0;
																																																	b = d ? b : b + 1 | 0;
																																																	m = d;
																																																	c = b;
																																																	continue Yb;
																																																} else {
																																																	qb = y[g + 20 >> 2];
																																																	b = ze(j, i, I, 0);
																																																	d = $ - b | 0;
																																																	M = ea - (Z + (b >>> 0 > $ >>> 0) | 0) | 0;
																																																	b = M >> 8;
																																																	ca = (M & 255) << 24 | d >>> 8;
																																																	d = ca;
																																																	L = (b | 0) >= 0 & d >>> 0 >= h >>> 0 | (b | 0) > 0;
																																																	M = ze(j, i, P, 0);
																																																	Ta = M + F | 0;
																																																	d = Z + l | 0;
																																																	d = M >>> 0 > Ta >>> 0 ? d + 1 | 0 : d;
																																																	M = d >> 8;
																																																	d = (d & 255) << 24 | Ta >>> 8;
																																																	ca = (M | 0) <= (Pa | 0) & W >>> 0 > d >>> 0 | (M | 0) < (Pa | 0) | ((b | 0) <= (Ma | 0) & N >>> 0 > ca >>> 0 | (b | 0) < (Ma | 0));
																																																	b = M;
																																																	if ((b | 0) > 0) {
																																																		b = 1;
																																																	} else {
																																																		b = (b | 0) >= 0 & d >>> 0 >= k >>> 0;
																																																	}
																																																	Ea(qb, j, u, q, ca | b | L);
																																																	j = j + 1 | 0;
																																																	i = j ? i : i + 1 | 0;
																																																	continue;
																																																}
																																															}
																																														}
																																														b = 1;
																																														while (1) {
																																															c = b;
																																															b = b + 1 | 0;
																																															if (da >>> 0 > 1 << c >>> 0) {
																																																continue;
																																															}
																																															break;
																																														}
																																														y[f + 184 >> 2] = 0;
																																														y[f + 188 >> 2] = 0;
																																														x[f + 216 >> 1] = 0;
																																														y[f + 192 >> 2] = 0;
																																														y[f + 196 >> 2] = 0;
																																														y[f + 200 >> 2] = 0;
																																														y[f + 204 >> 2] = 0;
																																														y[f + 208 >> 2] = 0;
																																														y[f + 220 >> 2] = 0;
																																														y[f + 224 >> 2] = 0;
																																														y[f + 228 >> 2] = 0;
																																														y[f + 232 >> 2] = 0;
																																														y[f + 236 >> 2] = 0;
																																														y[f + 168 >> 2] = K;
																																														y[f + 164 >> 2] = H;
																																														w[f + 160 | 0] = ha;
																																														y[f + 172 >> 2] = g;
																																														w[f + 162 | 0] = Xa;
																																														w[f + 161 | 0] = 0;
																																														w[f + 163 | 0] = aa;
																																														Zb: {
																																															if (aa >>> 0 >= 2) {
																																																x[f + 176 >> 1] = 65282;
																																																break Zb;
																																															}
																																															x[f + 176 >> 1] = 65283;
																																															if (aa) {
																																																break Zb;
																																															}
																																															x[f + 182 >> 1] = 65278;
																																															x[f + 178 >> 1] = 65533;
																																															x[f + 180 >> 1] = 65026;
																																														}
																																														b = c & 255;
																																														k = cb(f + 120 | 0, b);
																																														g = y[k >> 2];
																																														c = b - 1 | 0;
																																														d = c;
																																														_b: {
																																															$b: {
																																																while (1) {
																																																	if ((d | 0) >= 0) {
																																																		y[f + 292 >> 2] = 0;
																																																		y[f + 24 >> 2] = 0;
																																																		y[f + 16 >> 2] = s;
																																																		y[f + 20 >> 2] = rb;
																																																		y[f + 12 >> 2] = Ya;
																																																		y[f + 8 >> 2] = f + 292;
																																																		b = Ob(f + 160 | 0, f + 8 | 0);
																																																		y[f + 24 >> 2] = 0;
																																																		while (1) {
																																																			if ((b | 0) == 3) {
																																																				b = Nb(f + 160 | 0, f + 8 | 0);
																																																				continue;
																																																			}
																																																			break;
																																																		}
																																																		y[f + 204 >> 2] = 0;
																																																		y[f + 208 >> 2] = 0;
																																																		y[f + 196 >> 2] = 0;
																																																		y[f + 200 >> 2] = 0;
																																																		y[f + 188 >> 2] = 0;
																																																		y[f + 192 >> 2] = 0;
																																																		b = y[f + 292 >> 2];
																																																		if (!b) {
																																																			break $b;
																																																		}
																																																		y[f + 292 >> 2] = 0;
																																																		i = g + (d << 2) | 0;
																																																		oa(i, b);
																																																		if ((c | 0) > (d | 0)) {
																																																			bb(y[i >> 2], 0, 0, 0, 0, y[i + 4 >> 2], 2);
																																																		}
																																																		d = d - 1 | 0;
																																																		la(f + 292 | 0);
																																																		continue;
																																																	}
																																																	break;
																																																}
																																																b = vc(O, k);
																																																break _b;
																																															}
																																															la(f + 292 | 0);
																																															b = 0;
																																														}
																																														Za(k);
																																														la(f + 104 | 0);
																																														y[f + 160 >> 2] = 0;
																																														oa(n - -64 | 0, b);
																																														la(f + 160 | 0);
																																														if (!y[n + 64 >> 2]) {
																																															break Ub;
																																														}
																																														sa(y[a + 4 >> 2]);
																																														d = y[a + 4 >> 2];
																																														b = y[d + 8 >> 2];
																																														if (b >>> 0 <= 4294967293) {
																																															c = b + 2 | 0;
																																															b = y[d + 4 >> 2];
																																															y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																																														}
																																														ta(f + 300 | 0);
																																														Ja(f + 148 | 0);
																																													}
																																													if ((z[n + 4 | 0] & 63) == 20) {
																																														b = 0;
																																														break Sb;
																																													}
																																													ac: {
																																														if (z[a + 50 | 0]) {
																																															break ac;
																																														}
																																														d = y[y[a + 24 >> 2] - 4 >> 2];
																																														if (z[d + 17 | 0] != 1) {
																																															break ac;
																																														}
																																														b = X + y[f + 268 >> 2] | 0;
																																														c = y[a + 32 >> 2];
																																														if ((b | 0) <= y[c + 24 >> 2]) {
																																															break ac;
																																														}
																																														ab(c, b, z[d + 16 | 0]);
																																													}
																																													b = y[f + 264 >> 2];
																																													c = b;
																																													g = b >> 31;
																																													b = y[f + 268 >> 2];
																																													d = b;
																																													i = b >> 31;
																																													b = z[f + 272 | 0];
																																													bb(y[a + 32 >> 2], c, g, d, i, y[n + 64 >> 2], (b & 7) == 4 ? 4 : b & 3);
																																													b = 0;
																																													oa(n - -64 | 0, 0);
																																													break Sb;
																																												}
																																												ta(f + 300 | 0);
																																												Ja(f + 148 | 0);
																																											}
																																											b = 1;
																																										}
																																										ma(O);
																																										break u;
																																									}
																																									b = 1;
																																									if (z[a + 49 | 0] != 1) {
																																										break u;
																																									}
																																									k = a + 76 | 0;
																																									c = y[a + 76 >> 2];
																																									if (!c) {
																																										i = lb();
																																										y[f + 160 >> 2] = i;
																																										bc: {
																																											cc: {
																																												if (ob(a, a + 88 | 0)) {
																																													break cc;
																																												}
																																												if (wa(y[a + 4 >> 2], f + 8 | 0)) {
																																													break cc;
																																												}
																																												d = y[a + 92 >> 2];
																																												if ((d | 0) < 0) {
																																													break cc;
																																												}
																																												c = y[a + 88 >> 2];
																																												if ((c | 0) < 0) {
																																													break cc;
																																												}
																																												y[i + 8 >> 2] = d;
																																												y[i + 4 >> 2] = c;
																																												g = z[f + 8 | 0];
																																												c = g & 1;
																																												w[i | 0] = c;
																																												d = g >>> 1 & 3;
																																												w[i + 3 | 0] = d;
																																												w[i + 1 | 0] = g >>> 3 & 1;
																																												if (c) {
																																													break bc;
																																												}
																																												g = i + 16 | 0;
																																												c = 0;
																																												if (!d) {
																																													while (1) {
																																														if ((c | 0) == 8) {
																																															break bc;
																																														}
																																														d = c + g | 0;
																																														c = c + 1 | 0;
																																														if (!wa(y[a + 4 >> 2], d)) {
																																															continue;
																																														}
																																														break cc;
																																													}
																																												}
																																												while (1) {
																																													if ((c | 0) == 2) {
																																														break bc;
																																													}
																																													d = c + g | 0;
																																													c = c + 1 | 0;
																																													if (!wa(y[a + 4 >> 2], d)) {
																																														continue;
																																													}
																																													break;
																																												}
																																											}
																																											ta(f + 160 | 0);
																																											break u;
																																										}
																																										w[i + 2 | 0] = 0;
																																										y[f + 160 >> 2] = 0;
																																										Ra(k, i);
																																										ta(f + 160 | 0);
																																										c = y[k >> 2];
																																									}
																																									y[n + 52 >> 2] = 1;
																																									dc: {
																																										if (z[c | 0] == 1) {
																																											db(c, n - -64 | 0, y[a + 4 >> 2]);
																																											if (!y[n + 64 >> 2]) {
																																												Ra(k, 0);
																																												break M;
																																											}
																																											sa(y[a + 4 >> 2]);
																																											break dc;
																																										}
																																										if (y[a + 60 >> 2] == y[a + 64 >> 2]) {
																																											b = z[c + 3 | 0];
																																											fb(a + 60 | 0, b ? (b | 0) == 1 ? 8192 : 1024 : 65536);
																																										}
																																										i = a + 72 | 0;
																																										d = y[a + 72 >> 2];
																																										if (d) {
																																											b = d;
																																										} else {
																																											c = Na(y[a + 4 >> 2]);
																																											y[f + 160 >> 2] = 0;
																																											Ra(i, c);
																																											ta(f + 160 | 0);
																																											b = y[a + 72 >> 2];
																																										}
																																										y[f + 164 >> 2] = b;
																																										g = n - -64 | 0;
																																										y[f + 160 >> 2] = g;
																																										b = y[a + 64 >> 2];
																																										c = y[a + 60 >> 2];
																																										y[f + 176 >> 2] = 0;
																																										y[f + 168 >> 2] = c;
																																										y[f + 172 >> 2] = b - c >> 1;
																																										b = y[a + 76 >> 2];
																																										ec: {
																																											if (!d) {
																																												b = Ob(b, f + 160 | 0);
																																												break ec;
																																											}
																																											b = Nb(b, f + 160 | 0);
																																										}
																																										y[a + 56 >> 2] = b;
																																										if ((b | 0) == 3) {
																																											if ((z[n + 4 | 0] & 63) == 36) {
																																												break B;
																																											}
																																											fc: {
																																												if (z[a + 50 | 0]) {
																																													break fc;
																																												}
																																												d = y[y[a + 24 >> 2] - 4 >> 2];
																																												if (z[d + 17 | 0] != 1) {
																																													break fc;
																																												}
																																												b = y[a + 92 >> 2] + y[a + 100 >> 2] | 0;
																																												c = y[a + 32 >> 2];
																																												if ((b | 0) <= y[c + 24 >> 2]) {
																																													break fc;
																																												}
																																												ab(c, b, z[d + 16 | 0]);
																																											}
																																											c = y[a + 76 >> 2];
																																											b = y[c + 64 >> 2] + y[a + 96 >> 2] | 0;
																																											d = b;
																																											j = b >> 31;
																																											b = y[c + 68 >> 2] + y[a + 100 >> 2] | 0;
																																											i = b;
																																											h = b >> 31;
																																											b = z[a + 104 | 0];
																																											uc(y[a + 32 >> 2], d, j, i, h, y[g >> 2], c - -64 | 0, (b & 7) == 4 ? 4 : b & 3);
																																											break B;
																																										}
																																										b = y[a + 76 >> 2];
																																										y[b + 44 >> 2] = 0;
																																										y[b + 48 >> 2] = 0;
																																										y[b + 36 >> 2] = 0;
																																										y[b + 40 >> 2] = 0;
																																										y[b + 28 >> 2] = 0;
																																										y[b + 32 >> 2] = 0;
																																										Ra(i, 0);
																																										y[a + 64 >> 2] = y[a + 60 >> 2];
																																										if (!y[g >> 2]) {
																																											y[a + 56 >> 2] = -1;
																																											Ra(k, 0);
																																											break M;
																																										}
																																										sa(y[a + 4 >> 2]);
																																										d = y[a + 4 >> 2];
																																										b = y[d + 8 >> 2];
																																										if (b >>> 0 > 4294967293) {
																																											break dc;
																																										}
																																										c = b + 2 | 0;
																																										b = y[d + 4 >> 2];
																																										y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																																									}
																																									if ((z[n + 4 | 0] & 63) != 36) {
																																										gc: {
																																											if (z[a + 50 | 0]) {
																																												break gc;
																																											}
																																											d = y[y[a + 24 >> 2] - 4 >> 2];
																																											if (z[d + 17 | 0] != 1) {
																																												break gc;
																																											}
																																											b = y[a + 92 >> 2] + y[a + 100 >> 2] | 0;
																																											c = y[a + 32 >> 2];
																																											if ((b | 0) <= y[c + 24 >> 2]) {
																																												break gc;
																																											}
																																											ab(c, b, z[d + 16 | 0]);
																																										}
																																										c = y[a + 76 >> 2];
																																										b = y[c + 64 >> 2] + y[a + 96 >> 2] | 0;
																																										d = b;
																																										i = b >> 31;
																																										b = y[c + 68 >> 2] + y[a + 100 >> 2] | 0;
																																										g = b;
																																										j = b >> 31;
																																										b = z[a + 104 | 0];
																																										uc(y[a + 32 >> 2], d, i, g, j, y[n + 64 >> 2], c - -64 | 0, (b & 7) == 4 ? 4 : b & 3);
																																										oa(n - -64 | 0, 0);
																																									}
																																									b = 0;
																																									Ra(k, 0);
																																									break u;
																																								}
																																								b = 1;
																																								if (z[a + 49 | 0] != 1) {
																																									break u;
																																								}
																																								if (ob(a, f + 160 | 0)) {
																																									break u;
																																								}
																																								if (wa(y[a + 4 >> 2], f + 292 | 0)) {
																																									break u;
																																								}
																																								i = y[f + 160 >> 2];
																																								if (i - 1 >>> 0 > 65534) {
																																									break u;
																																								}
																																								k = y[f + 164 >> 2];
																																								if (k - 1 >>> 0 > 65534) {
																																									break u;
																																								}
																																								y[f + 256 >> 2] = 0;
																																								j = kb();
																																								y[f + 120 >> 2] = j;
																																								y[j + 8 >> 2] = k;
																																								y[j + 4 >> 2] = i;
																																								d = z[f + 292 | 0];
																																								b = d & 1;
																																								w[j | 0] = b;
																																								w[j + 1 | 0] = d >>> 1 & 1;
																																								hc: {
																																									ic: {
																																										if (b) {
																																											break ic;
																																										}
																																										g = j + 24 | 0;
																																										while (1) {
																																											if ((c | 0) == 4) {
																																												break ic;
																																											}
																																											b = 1;
																																											d = c + g | 0;
																																											c = c + 1 | 0;
																																											if (!wa(y[a + 4 >> 2], d)) {
																																												continue;
																																											}
																																											break;
																																										}
																																										break hc;
																																									}
																																									g = y[n + 8 >> 2];
																																									jc: {
																																										if ((g | 0) > 0) {
																																											c = 0;
																																											b = 1;
																																											while (1) {
																																												if ((c | 0) == (g | 0)) {
																																													break hc;
																																												}
																																												i = Ka(a, y[y[n + 12 >> 2] >> 2]);
																																												if (!i) {
																																													break hc;
																																												}
																																												d = z[i + 4 | 0];
																																												d = (d << 6 | d >>> 2) & 207;
																																												if (!(1 << d & 1570 ? d >>> 0 <= 10 : 0)) {
																																													c = c + 1 | 0;
																																													continue;
																																												}
																																												break;
																																											}
																																											b = i - -64 | 0;
																																											break jc;
																																										}
																																										c = nb(y[a + 32 >> 2], y[f + 168 >> 2], y[f + 172 >> 2], i, k);
																																										y[f + 8 >> 2] = 0;
																																										b = f + 256 | 0;
																																										oa(b, c);
																																										la(f + 8 | 0);
																																									}
																																									b = y[b >> 2];
																																									y[j + 12 >> 2] = 0;
																																									y[j + 16 >> 2] = 0;
																																									y[j + 20 >> 2] = b;
																																									mb(f + 8 | 0, z[j | 0] ? 1024 : 8192);
																																									c = Na(y[a + 4 >> 2]);
																																									y[f + 148 >> 2] = c;
																																									y[n + 52 >> 2] = 1;
																																									b = jb(j, c, y[f + 8 >> 2], y[f + 12 >> 2]);
																																									y[f + 104 >> 2] = 0;
																																									g = n - -64 | 0;
																																									oa(g, b);
																																									la(f + 104 | 0);
																																									b = 1;
																																									kc: {
																																										if (!y[n + 64 >> 2]) {
																																											break kc;
																																										}
																																										sa(y[a + 4 >> 2]);
																																										d = y[a + 4 >> 2];
																																										b = y[d + 8 >> 2];
																																										if (b >>> 0 <= 4294967293) {
																																											c = b + 2 | 0;
																																											b = y[d + 4 >> 2];
																																											y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																																										}
																																										b = 0;
																																										if ((z[n + 4 | 0] & 63) == 40) {
																																											break kc;
																																										}
																																										lc: {
																																											if (z[a + 50 | 0]) {
																																												break lc;
																																											}
																																											d = y[y[a + 24 >> 2] - 4 >> 2];
																																											if (z[d + 17 | 0] != 1) {
																																												break lc;
																																											}
																																											b = k + y[f + 172 >> 2] | 0;
																																											c = y[a + 32 >> 2];
																																											if ((b | 0) <= y[c + 24 >> 2]) {
																																												break lc;
																																											}
																																											ab(c, b, z[d + 16 | 0]);
																																										}
																																										b = y[f + 168 >> 2];
																																										c = b;
																																										i = b >> 31;
																																										b = y[f + 172 >> 2];
																																										d = b;
																																										j = b >> 31;
																																										b = z[f + 176 | 0];
																																										bb(y[a + 32 >> 2], c, i, d, j, y[g >> 2], (b & 7) == 4 ? 4 : b & 3);
																																										oa(g, 0);
																																										b = 0;
																																									}
																																									ta(f + 148 | 0);
																																									Ja(f + 8 | 0);
																																								}
																																								Ua(f + 120 | 0);
																																								la(f + 256 | 0);
																																								break u;
																																							}
																																							j = na(20);
																																							y[j + 16 >> 2] = 0;
																																							y[j + 8 >> 2] = 0;
																																							y[j + 12 >> 2] = 0;
																																							y[j >> 2] = 0;
																																							y[j + 4 >> 2] = 0;
																																							y[f + 160 >> 2] = j;
																																							mc: {
																																								if (qa(y[a + 4 >> 2], j)) {
																																									break mc;
																																								}
																																								if (qa(y[a + 4 >> 2], j + 4 | 0)) {
																																									break mc;
																																								}
																																								if (qa(y[a + 4 >> 2], j + 8 | 0)) {
																																									break mc;
																																								}
																																								if (qa(y[a + 4 >> 2], j + 12 | 0)) {
																																									break mc;
																																								}
																																								if (wa(y[a + 4 >> 2], f + 148 | 0)) {
																																									break mc;
																																								}
																																								if (Sa(y[a + 4 >> 2], f + 120 | 0)) {
																																									break mc;
																																								}
																																								w[j + 16 | 0] = z[f + 148 | 0] >>> 2 & 1;
																																								d = A[f + 120 >> 1];
																																								b = d & 32767;
																																								x[j + 18 >> 1] = b;
																																								w[j + 17 | 0] = d >>> 15;
																																								c = y[j + 4 >> 2];
																																								nc: {
																																									oc: {
																																										if ((c | 0) == -1) {
																																											if (d << 16 >> 16 >= 0) {
																																												w[j + 17 | 0] = 1;
																																											}
																																											if (z[a + 50 | 0]) {
																																												break nc;
																																											}
																																											c = b;
																																											break oc;
																																										}
																																										if (z[a + 50 | 0]) {
																																											break nc;
																																										}
																																									}
																																									y[f + 8 >> 2] = c;
																																									b = ua(j, f + 8 | 0);
																																									y[f + 256 >> 2] = 0;
																																									oa(a + 32 | 0, b);
																																									la(f + 256 | 0);
																																								}
																																								c = y[a + 32 >> 2];
																																								b = y[c + 16 >> 2];
																																								if (b) {
																																									break L;
																																								}
																																								y[a + 56 >> 2] = -1;
																																							}
																																							Ub(f + 160 | 0);
																																						}
																																						b = 1;
																																						break u;
																																					}
																																					Mb(y[c + 12 >> 2], b, z[j + 16 | 0]);
																																					b = y[a + 24 >> 2];
																																					c = y[a + 28 >> 2];
																																					pc: {
																																						if (b >>> 0 < c >>> 0) {
																																							y[f + 160 >> 2] = 0;
																																							y[b >> 2] = j;
																																							b = b + 4 | 0;
																																							break pc;
																																						}
																																						d = y[a + 20 >> 2];
																																						b = b - d | 0;
																																						k = b >> 2;
																																						i = k + 1 | 0;
																																						if (i >>> 0 >= 1073741824) {
																																							break F;
																																						}
																																						g = c - d | 0;
																																						c = g >> 1;
																																						i = g >>> 0 >= 2147483644 ? 1073741823 : c >>> 0 > i >>> 0 ? c : i;
																																						qc: {
																																							if (!i) {
																																								g = b;
																																								h = 0;
																																								break qc;
																																							}
																																							if (i >>> 0 >= 1073741824) {
																																								break E;
																																							}
																																							h = na(i << 2);
																																							d = y[a + 20 >> 2];
																																							g = y[a + 24 >> 2] - d | 0;
																																							k = g >> 2;
																																						}
																																						y[f + 160 >> 2] = 0;
																																						b = b + h | 0;
																																						y[b >> 2] = j;
																																						c = b - (k << 2) | 0;
																																						if (g) {
																																							p(c, d, g);
																																						}
																																						y[a + 28 >> 2] = (i << 2) + h;
																																						b = b + 4 | 0;
																																						y[a + 24 >> 2] = b;
																																						y[a + 20 >> 2] = c;
																																						if (!d) {
																																							break pc;
																																						}
																																						ma(d);
																																					}
																																					w[a + 49 | 0] = 1;
																																					y[a + 24 >> 2] = b;
																																					Ub(f + 160 | 0);
																																					break B;
																																				}
																																				w[a + 49 | 0] = 0;
																																				break u;
																																			}
																																			c = y[a + 4 >> 2];
																																			b = y[c + 8 >> 2];
																																			d = b + y[n + 28 >> 2] | 0;
																																			if (b >>> 0 > d >>> 0) {
																																				break B;
																																			}
																																			b = y[c + 4 >> 2];
																																			y[c + 8 >> 2] = b >>> 0 > d >>> 0 ? d : b;
																																			break B;
																																		}
																																		c = y[a + 4 >> 2];
																																		b = y[c + 8 >> 2];
																																		d = b + y[n + 28 >> 2] | 0;
																																		if (b >>> 0 > d >>> 0) {
																																			break B;
																																		}
																																		b = y[c + 4 >> 2];
																																		y[c + 8 >> 2] = b >>> 0 > d >>> 0 ? d : b;
																																		break B;
																																	}
																																	y[n + 52 >> 2] = 4;
																																	k = n + 68 | 0;
																																	pb(k, 0);
																																	m = y[a + 4 >> 2];
																																	q = na(96);
																																	x[q >> 1] = 0;
																																	t(q + 4 | 0, 0, 92);
																																	if ((wa(m, f + 120 | 0) | 0) == -1) {
																																		break D;
																																	}
																																	b = 1;
																																	d = z[f + 120 | 0];
																																	w[q + 1 | 0] = d & 1;
																																	rc: {
																																		sc: {
																																			if ((qa(m, f + 8 | 0) | 0) == -1) {
																																				break sc;
																																			}
																																			if ((qa(m, f + 256 | 0) | 0) == -1) {
																																				break sc;
																																			}
																																			c = y[f + 8 >> 2];
																																			j = y[f + 256 >> 2];
																																			if ((c | 0) > (j | 0)) {
																																				break sc;
																																			}
																																			i = (d >>> 4 & 7) + 1 | 0;
																																			h = (d >>> 1 & 7) + 1 | 0;
																																			Lb(q, 0);
																																			y[f + 164 >> 2] = c;
																																			w[f + 160 | 0] = 1;
																																			b = c;
																																			while (1) {
																																				if ((Fa(m, h, y[q + 8 >> 2] + (y[q + 4 >> 2] << 3) | 0) | 0) == -1) {
																																					break rc;
																																				}
																																				if ((Fa(m, i, y[q + 20 >> 2] + (y[q + 4 >> 2] << 2) | 0) | 0) == -1) {
																																					break rc;
																																				}
																																				g = y[q + 20 >> 2];
																																				d = y[q + 4 >> 2] << 2;
																																				if (B[g + d >> 2] > 63) {
																																					break rc;
																																				}
																																				y[d + y[q + 32 >> 2] >> 2] = b;
																																				b = y[g + (y[q + 4 >> 2] << 2) >> 2];
																																				if ((b | 0) > 31) {
																																					break rc;
																																				}
																																				if (z[La(f + 160 | 0, 1 << b) | 0] != 1) {
																																					break rc;
																																				}
																																				Lb(q, 1);
																																				b = y[f + 164 >> 2];
																																				if ((j | 0) > (b | 0)) {
																																					continue;
																																				}
																																				break;
																																			}
																																			if ((Fa(m, h, y[q + 8 >> 2] + (y[q + 4 >> 2] << 3) | 0) | 0) == -1) {
																																				break rc;
																																			}
																																			y[y[q + 20 >> 2] + (y[q + 4 >> 2] << 2) >> 2] = 32;
																																			if ((c | 0) == -2147483648) {
																																				break rc;
																																			}
																																			y[y[q + 32 >> 2] + (y[q + 4 >> 2] << 2) >> 2] = c - 1;
																																			Lb(q, 1);
																																			if ((Fa(m, h, y[q + 8 >> 2] + (y[q + 4 >> 2] << 3) | 0) | 0) == -1) {
																																				break rc;
																																			}
																																			y[y[q + 20 >> 2] + (y[q + 4 >> 2] << 2) >> 2] = 32;
																																			y[y[q + 32 >> 2] + (y[q + 4 >> 2] << 2) >> 2] = j;
																																			Lb(q, 1);
																																			if (z[q + 1 | 0] == 1) {
																																				if ((Fa(m, h, y[q + 8 >> 2] + (y[q + 4 >> 2] << 3) | 0) | 0) == -1) {
																																					break rc;
																																				}
																																				y[q + 4 >> 2] = y[q + 4 >> 2] + 1;
																																			}
																																			c = Ld(q);
																																			w[q | 0] = c;
																																			y[f + 160 >> 2] = q;
																																			b = 1;
																																			if (!c) {
																																				break C;
																																			}
																																			b = 0;
																																			y[f + 160 >> 2] = 0;
																																			pb(k, q);
																																			sa(y[a + 4 >> 2]);
																																			break C;
																																		}
																																		w[q | 0] = 0;
																																		y[f + 160 >> 2] = q;
																																		break C;
																																	}
																																	break D;
																																}
																																if ((d | 0) != 62) {
																																	break B;
																																}
																																c = y[a + 4 >> 2];
																																b = y[c + 8 >> 2];
																																d = b + y[n + 28 >> 2] | 0;
																																if (b >>> 0 > d >>> 0) {
																																	break B;
																																}
																																b = y[c + 4 >> 2];
																																y[c + 8 >> 2] = b >>> 0 > d >>> 0 ? d : b;
																																break B;
																															}
																															za();
																															o();
																														}
																														Wa();
																														o();
																													}
																													w[q | 0] = 0;
																													y[f + 160 >> 2] = q;
																													b = 1;
																												}
																												pa(f + 160 | 0);
																												break u;
																											}
																											b = 0;
																											break u;
																										}
																										la(f + 120 | 0);
																									}
																									ta(f + 256 | 0);
																									y[f + 160 >> 2] = 0;
																									Pb(n + 60 | 0, g);
																									Sb(f + 160 | 0);
																									if (y[n + 60 >> 2]) {
																										sa(y[a + 4 >> 2]);
																										d = y[a + 4 >> 2];
																										b = y[d + 8 >> 2];
																										if (b >>> 0 <= 4294967293) {
																											c = b + 2 | 0;
																											b = y[d + 4 >> 2];
																											y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																										}
																										ta(f + 104 | 0);
																										Ja(f + 8 | 0);
																										b = 0;
																										break x;
																									}
																									ta(f + 104 | 0);
																									Ja(f + 8 | 0);
																								}
																								b = 1;
																							}
																							ma(h);
																							break u;
																						}
																						if (qa(y[a + 4 >> 2], h + 16 | 0)) {
																							break v;
																						}
																						c = y[a + 4 >> 2];
																						d = y[c >> 2];
																						c = y[c + 4 >> 2];
																						if ((c | 0) < 0) {
																							break t;
																						}
																						d = ((c & 134217727) << 5 | d >>> 27) & -32;
																						c = c >>> 27 & 15;
																						if (!c & d >>> 0 >= 2147483648 | c) {
																							break t;
																						}
																						if (!c & B[h + 16 >> 2] > d >>> 0) {
																							break v;
																						}
																						k = 0;
																						b = y[n + 8 >> 2];
																						g = (b | 0) > 0 ? b : 0;
																						c = 0;
																						while (1) {
																							if ((c | 0) == (g | 0)) {
																								d = 1;
																								b = 0;
																								while (1) if ((b | 0) == (g | 0)) {
																									if (!(d & 1)) {
																										break t;
																									}
																									y[h + 24 >> 2] = k;
																									F = Kb(f + 104 | 0, k);
																									q = y[F >> 2];
																									tc: {
																										if ((q | 0) == y[F + 4 >> 2]) {
																											break tc;
																										}
																										b = y[n + 8 >> 2];
																										m = (b | 0) > 0 ? b : 0;
																										d = 1;
																										k = 0;
																										g = 0;
																										while (1) {
																											if ((g | 0) == (m | 0)) {
																												break tc;
																											}
																											uc: {
																												b = Ka(a, y[y[n + 12 >> 2] + (g << 2) >> 2]);
																												if (z[b + 4 | 0] & 63) {
																													break uc;
																												}
																												b = y[b + 56 >> 2];
																												i = y[b + 24 >> 2];
																												l = y[b + 28 >> 2] - i >> 2;
																												b = 0;
																												while (1) {
																													if ((b | 0) == (l | 0)) {
																														j = 0;
																														i = 0;
																														if (d & 1) {
																															b = k + l | 0;
																															c = b >>> 0 >= l >>> 0;
																															j = c;
																															i = c ? b : 0;
																														}
																														k = i;
																														d = j;
																														break uc;
																													}
																													c = b + k | 0;
																													if (!(c >>> 0 >= b >>> 0 & d)) {
																														break t;
																													}
																													y[q + (c << 2) >> 2] = y[i + (b << 2) >> 2];
																													b = b + 1 | 0;
																													continue;
																												}
																											}
																											g = g + 1 | 0;
																											continue;
																										}
																									}
																									$a(h + 124 | 0, F);
																									vc: {
																										wc: {
																											if (z[h | 0] == 1) {
																												q = y[h + 24 >> 2];
																												b = 0;
																												xc: {
																													yc: {
																														while (1) {
																															if ((b | 0) == 35) {
																																break yc;
																															}
																															if (!Fa(y[a + 4 >> 2], 4, f + 160 | 0)) {
																																w[(f + 256 | 0) + b | 0] = y[f + 160 >> 2];
																																b = b + 1 | 0;
																																continue;
																															}
																															break;
																														}
																														x[f + 8 >> 1] = 0;
																														t(f + 12 | 0, 0, 92);
																														break xc;
																													}
																													m = tc(f + 160 | 0, f + 256 | 0, 35);
																													if (!z[m | 0]) {
																														x[f + 8 >> 1] = 0;
																														t(f + 12 | 0, 0, 92);
																														Oa(m);
																														break xc;
																													}
																													y[f + 300 >> 2] = y[a + 4 >> 2];
																													d = 0;
																													y[f + 156 >> 2] = 0;
																													y[f + 148 >> 2] = 0;
																													y[f + 152 >> 2] = 0;
																													b = f + 148 | 0;
																													y[f + 292 >> 2] = b;
																													if (q) {
																														Kd(b, q);
																														b = y[f + 152 >> 2];
																														c = q + b | 0;
																														while (1) {
																															if ((b | 0) != (c | 0)) {
																																w[b | 0] = 0;
																																b = b + 1 | 0;
																																continue;
																															}
																															break;
																														}
																														y[f + 152 >> 2] = c;
																													}
																													w[f + 296 | 0] = 1;
																													gc(f + 292 | 0);
																													k = 0;
																													zc: while (1) {
																														Ac: {
																															Bc: {
																																if ((d | 0) < (q | 0)) {
																																	if (ya(f + 300 | 0, m, f + 292 | 0)) {
																																		break Bc;
																																	}
																																	g = y[f + 292 >> 2];
																																	if ((g | 0) <= 31) {
																																		w[y[f + 148 >> 2] + d | 0] = g;
																																		k = 0;
																																		break Ac;
																																	}
																																	Cc: {
																																		Dc: {
																																			switch (g - 32 | 0) {
																																				case 0:
																																					if (Fa(y[a + 4 >> 2], 2, f + 144 | 0)) {
																																						break Bc;
																																					}
																																					k = y[f + 144 >> 2] + 3 | 0;
																																					break Cc;
																																				case 1:
																																					if (Fa(y[a + 4 >> 2], 3, f + 144 | 0)) {
																																						break Bc;
																																					}
																																					k = y[f + 144 >> 2] + 3 | 0;
																																					break Cc;
																																				case 2: break Dc;
																																				default: break Cc;
																																			}
																																		}
																																		if (Fa(y[a + 4 >> 2], 7, f + 144 | 0)) {
																																			break Bc;
																																		}
																																		k = y[f + 144 >> 2] + 11 | 0;
																																	}
																																	if ((k | 0) <= 0) {
																																		break Ac;
																																	}
																																	c = d + k | 0;
																																	if ((c | 0) > (q | 0)) {
																																		break Bc;
																																	}
																																	b = 0;
																																	j = (g | 0) == 32 & (d | 0) > 0;
																																	while (1) if ((b | 0) == (k | 0)) {
																																		d = c;
																																		continue zc;
																																	} else {
																																		i = y[f + 148 >> 2] + d | 0;
																																		w[i + b | 0] = j ? z[i - 1 | 0] : 0;
																																		b = b + 1 | 0;
																																		continue;
																																	}
																																}
																																b = y[f + 148 >> 2];
																																c = tc(f + 8 | 0, b, y[f + 152 >> 2] - b | 0);
																																b = z[c | 0];
																																va(f + 148 | 0);
																																Oa(m);
																																if (!b) {
																																	break xc;
																																}
																																sa(y[a + 4 >> 2]);
																																Id(h + 28 | 0, c);
																																Oa(c);
																																b = 1;
																																c = 0;
																																if (z[h | 0] != 1) {
																																	break wc;
																																}
																																q = A[f + 142 >> 1];
																																m = q >>> 12 & 3;
																																if ((m | 0) == 2) {
																																	break vc;
																																}
																																j = q >>> 10 & 3;
																																if ((j | 0) == 2) {
																																	break vc;
																																}
																																k = q >>> 8 & 3;
																																if ((k | 0) == 2) {
																																	break vc;
																																}
																																d = q & 3;
																																if ((d | 0) == 2) {
																																	break vc;
																																}
																																i = q >>> 6 & 3;
																																if ((i | 0) == 2) {
																																	break vc;
																																}
																																Ec: {
																																	Fc: {
																																		switch (d | 0) {
																																			case 0:
																																				g = ra(a, 6);
																																				d = 0;
																																				break Ec;
																																			case 1:
																																				g = ra(a, 7);
																																				d = 0;
																																				break Ec;
																																			default: break Fc;
																																		}
																																	}
																																	d = Ga(a, n, 0);
																																	if (!d) {
																																		break vc;
																																	}
																																	g = y[d + 68 >> 2];
																																	d = 1;
																																}
																																y[h + 144 >> 2] = g;
																																Gc: {
																																	Hc: {
																																		switch ((q >>> 2 & 3) - 1 | 0) {
																																			default:
																																				g = ra(a, 8);
																																				break Gc;
																																			case 0:
																																				g = ra(a, 9);
																																				break Gc;
																																			case 1:
																																				g = ra(a, 10);
																																				break Gc;
																																			case 2: break Hc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 148 >> 2] = g;
																																Ic: {
																																	Jc: {
																																		switch ((q >>> 4 & 3) - 1 | 0) {
																																			default:
																																				g = ra(a, 11);
																																				break Ic;
																																			case 0:
																																				g = ra(a, 12);
																																				break Ic;
																																			case 1:
																																				g = ra(a, 13);
																																				break Ic;
																																			case 2: break Jc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 152 >> 2] = g;
																																Kc: {
																																	Lc: {
																																		switch (i | 0) {
																																			case 0:
																																				g = ra(a, 14);
																																				break Kc;
																																			case 1:
																																				g = ra(a, 15);
																																				break Kc;
																																			default: break Lc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 156 >> 2] = g;
																																Mc: {
																																	Nc: {
																																		switch (k | 0) {
																																			case 0:
																																				g = ra(a, 14);
																																				break Mc;
																																			case 1:
																																				g = ra(a, 15);
																																				break Mc;
																																			default: break Nc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 160 >> 2] = g;
																																Oc: {
																																	Pc: {
																																		switch (j | 0) {
																																			case 0:
																																				g = ra(a, 14);
																																				break Oc;
																																			case 1:
																																				g = ra(a, 15);
																																				break Oc;
																																			default: break Pc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 164 >> 2] = g;
																																Qc: {
																																	Rc: {
																																		switch (m | 0) {
																																			case 0:
																																				g = ra(a, 14);
																																				break Qc;
																																			case 1:
																																				g = ra(a, 15);
																																				break Qc;
																																			default: break Rc;
																																		}
																																	}
																																	g = Ga(a, n, d);
																																	if (!g) {
																																		break vc;
																																	}
																																	d = d + 1 | 0;
																																	g = y[g + 68 >> 2];
																																}
																																y[h + 168 >> 2] = g;
																																Sc: {
																																	if (!(q & 16384)) {
																																		b = ra(a, 1);
																																		break Sc;
																																	}
																																	d = Ga(a, n, d);
																																	if (!d) {
																																		break vc;
																																	}
																																	b = y[d + 68 >> 2];
																																}
																																y[h + 172 >> 2] = b;
																																break wc;
																															}
																															x[f + 8 >> 1] = 0;
																															t(f + 12 | 0, 0, 92);
																															va(f + 148 | 0);
																															Oa(m);
																															break xc;
																														}
																														d = d + 1 | 0;
																														continue;
																													}
																												}
																												Oa(f + 8 | 0);
																												b = 1;
																												break vc;
																											}
																											c = ib(y[h + 24 >> 2]);
																										}
																										j = 0;
																										i = 0;
																										y[f + 8 >> 2] = 0;
																										y[f + 12 >> 2] = 0;
																										if (z[h + 1 | 0] == 1) {
																											g = f + 160 | 0;
																											mb(g, z[h + 2 | 0] ? 1024 : 8192);
																											b = y[f + 160 >> 2];
																											y[f + 160 >> 2] = 0;
																											Hd(f + 8 | 0, b);
																											d = y[f + 164 >> 2];
																											y[f + 12 >> 2] = d;
																											y[f + 164 >> 2] = 0;
																											Ja(g);
																											i = d;
																										}
																										y[n + 52 >> 2] = 1;
																										Tc: {
																											Uc: {
																												Vc: {
																													Wc: {
																														if (z[h | 0] == 1) {
																															b = Gd(h, y[a + 4 >> 2], y[f + 8 >> 2] | j, i);
																															y[f + 160 >> 2] = 0;
																															oa(n - -64 | 0, b);
																															la(f + 160 | 0);
																															if (!y[n + 64 >> 2]) {
																																break Uc;
																															}
																															sa(y[a + 4 >> 2]);
																															break Wc;
																														}
																														b = Na(y[a + 4 >> 2]);
																														y[f + 256 >> 2] = b;
																														g = Fd(f + 160 | 0, c);
																														b = Ed(h, b, y[f + 8 >> 2] | j, i, g);
																														y[f + 148 >> 2] = 0;
																														oa(n - -64 | 0, b);
																														la(f + 148 | 0);
																														if (!y[n + 64 >> 2]) {
																															break Vc;
																														}
																														sa(y[a + 4 >> 2]);
																														d = y[a + 4 >> 2];
																														b = y[d + 8 >> 2];
																														if (b >>> 0 <= 4294967293) {
																															c = b + 2 | 0;
																															b = y[d + 4 >> 2];
																															y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
																														}
																														rc(g);
																														ta(f + 256 | 0);
																													}
																													b = 0;
																													if ((z[n + 4 | 0] & 63) == 4) {
																														break Tc;
																													}
																													Xc: {
																														if (z[a + 50 | 0]) {
																															break Xc;
																														}
																														d = y[y[a + 24 >> 2] - 4 >> 2];
																														if (z[d + 17 | 0] != 1) {
																															break Xc;
																														}
																														b = u + y[f + 132 >> 2] | 0;
																														c = y[a + 32 >> 2];
																														if ((b | 0) <= y[c + 24 >> 2]) {
																															break Xc;
																														}
																														ab(c, b, z[d + 16 | 0]);
																													}
																													b = y[f + 128 >> 2];
																													c = b;
																													g = b >> 31;
																													b = y[f + 132 >> 2];
																													d = b;
																													i = b >> 31;
																													b = z[f + 136 | 0];
																													bb(y[a + 32 >> 2], c, g, d, i, y[n + 64 >> 2], (b & 7) == 4 ? 4 : b & 3);
																													oa(n - -64 | 0, 0);
																													b = 0;
																													break Tc;
																												}
																												rc(g);
																												ta(f + 256 | 0);
																											}
																											b = 1;
																										}
																										Ja(f + 8 | 0);
																									}
																									va(F);
																									break v;
																								} else {
																									c = Ka(a, y[y[n + 12 >> 2] + (b << 2) >> 2]);
																									if (!(z[c + 4 | 0] & 63)) {
																										j = 0;
																										i = 0;
																										if (d & 1) {
																											c = y[c + 56 >> 2];
																											d = y[c + 28 >> 2] - y[c + 24 >> 2] >> 2;
																											c = d + k | 0;
																											i = c;
																											c = c >>> 0 >= d >>> 0;
																											d = c ? i : 0;
																											j = c;
																										} else {
																											d = i;
																										}
																										k = d;
																										d = j;
																									}
																									b = b + 1 | 0;
																									continue;
																								}
																							}
																							b = 1;
																							d = c << 2;
																							c = c + 1 | 0;
																							if (Ka(a, y[d + y[n + 12 >> 2] >> 2])) {
																								continue;
																							}
																							break;
																						}
																					}
																					qc(f + 116 | 0);
																				}
																				Y = f + 304 | 0;
																				break s;
																			}
																			o();
																		}
																		if (y[a + 56 >> 2] != 3) {
																			break r;
																		}
																		b = y[a + 4 >> 2];
																		c = y[b + 8 >> 2];
																		b = y[b + 4 >> 2];
																		if (c >>> 0 > b >>> 0) {
																			break e;
																		}
																		if ((b | 0) != (c | 0)) {
																			continue;
																		}
																		break;
																	}
																	y[a + 52 >> 2] = 2;
																	break c;
																}
																Yc: {
																	switch (b | 0) {
																		default:
																			eb(ba, 0);
																			break i;
																		case 0: break Yc;
																		case 2: break d;
																	}
																}
																n = y[ba >> 2];
																b = y[n + 28 >> 2];
																if ((b | 0) == -1) {
																	break g;
																}
																c = b;
																b = y[a + 84 >> 2];
																c = c + b | 0;
																if (b >>> 0 <= c >>> 0) {
																	break h;
																}
															}
															sb = 1;
															break c;
														}
														y[a + 84 >> 2] = c;
														d = y[a + 4 >> 2];
														b = y[d + 4 >> 2];
														y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
														break f;
													}
													d = y[a + 4 >> 2];
													b = y[d + 8 >> 2];
													if (b >>> 0 > 4294967291) {
														break f;
													}
													c = b + 4 | 0;
													b = y[d + 4 >> 2];
													y[d + 8 >> 2] = b >>> 0 > c >>> 0 ? c : b;
												}
												b = y[a + 12 >> 2];
												c = y[a + 16 >> 2];
												Zc: {
													if (b >>> 0 < c >>> 0) {
														y[ba >> 2] = 0;
														y[b >> 2] = n;
														c = b + 4 | 0;
														break Zc;
													}
													d = y[a + 8 >> 2];
													b = b - d | 0;
													h = b >> 2;
													i = h + 1 | 0;
													if (i >>> 0 >= 1073741824) {
														break b;
													}
													g = c - d | 0;
													c = g >> 1;
													k = g >>> 0 >= 2147483644 ? 1073741823 : c >>> 0 > i >>> 0 ? c : i;
													_c: {
														if (!k) {
															g = 0;
															c = b;
															break _c;
														}
														if (k >>> 0 >= 1073741824) {
															break a;
														}
														g = na(k << 2);
														d = y[a + 8 >> 2];
														c = y[a + 12 >> 2] - d | 0;
														h = c >> 2;
														n = y[a + 80 >> 2];
													}
													y[a + 80 >> 2] = 0;
													i = b + g | 0;
													y[i >> 2] = n;
													b = i - (h << 2) | 0;
													if (c) {
														p(b, d, c);
													}
													y[a + 16 >> 2] = (k << 2) + g;
													c = i + 4 | 0;
													y[a + 12 >> 2] = c;
													y[a + 8 >> 2] = b;
													if (d) {
														ma(d);
													}
													d = y[a + 4 >> 2];
												}
												y[a + 12 >> 2] = c;
												b = y[d + 4 >> 2];
												i = b;
												c = y[d + 8 >> 2];
												if (b >>> 0 >= c >>> 0) {
													continue;
												}
												break;
											}
										}
										o();
									}
									eb(ba, 0);
								}
								Y = T + 16 | 0;
								return sb;
							}
							za();
							o();
						}
						Wa();
						o();
					}
					function jb(a, b, c, d) {
						var e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, I = 0, J = 0, K = 0, L = 0, M = 0, N = 0, O = 0, P = 0, Q = 0, R = 0;
						e = Y - 96 | 0;
						Y = e;
						D = a + 8 | 0;
						p = a + 4 | 0;
						a: {
							b: {
								m = y[a + 4 >> 2];
								if (m - 1 >>> 0 <= 65534) {
									s = y[a + 8 >> 2];
									if (s - 1 >>> 0 < 65535) {
										break b;
									}
								}
								l = ua(p, D);
								break a;
							}
							c: {
								d: {
									e: {
										f: {
											g: {
												h: {
													i: {
														j: {
															k: {
																l: {
																	if (!z[a | 0]) {
																		m: {
																			if (z[a + 24 | 0] != 255 | z[a + 25 | 0] != 255 | (z[a + 26 | 0] != 255 | z[a + 27 | 0] != 255)) {
																				break m;
																			}
																			if (y[a + 12 >> 2]) {
																				break m;
																			}
																			j = y[a + 20 >> 2];
																			if ((m | 0) != y[j + 20 >> 2]) {
																				break m;
																			}
																			if (!y[j + 16 >> 2]) {
																				break c;
																			}
																			l = hc(m, s);
																			y[e + 44 >> 2] = l;
																			if (!y[l + 16 >> 2]) {
																				break e;
																			}
																			u = d;
																			E = c;
																			c = y[a + 20 >> 2];
																			F = y[c + 20 >> 2];
																			q = y[c + 24 >> 2];
																			c = y[a + 16 >> 2];
																			if (!((1 - q | 0) <= (c | 0) & (c | 0) < (q | 0))) {
																				y[a + 16 >> 2] = 0;
																			}
																			L = q + 1 | 0;
																			I = q - 1 | 0;
																			J = E + 32 | 0;
																			p = 0;
																			while (1) {
																				if ((p | 0) != (s | 0)) {
																					if (z[a + 1 | 0] == 1) {
																						if (z[b | 0]) {
																							break e;
																						}
																						if ((d | 0) == 16 | d >>> 0 < 16) {
																							break l;
																						}
																						v = ka(b, J) ^ v;
																					}
																					ja(e + 32 | 0, l, p);
																					i = 0;
																					n: {
																						if (!p) {
																							D = 0;
																							t = 0;
																							j = 0;
																							break n;
																						}
																						ja(e + 72 | 0, l, p - 1 | 0);
																						t = y[e + 76 >> 2];
																						if (!t) {
																							break l;
																						}
																						D = y[e + 72 >> 2];
																						j = z[D | 0] << 4;
																					}
																					c = y[a + 16 >> 2];
																					y[e + 88 >> 2] = 0;
																					y[e + 92 >> 2] = 0;
																					y[e + 80 >> 2] = 0;
																					y[e + 84 >> 2] = 0;
																					y[e + 72 >> 2] = 0;
																					y[e + 76 >> 2] = 0;
																					y[e + 16 >> 2] = 0;
																					y[e + 8 >> 2] = 0;
																					y[e + 12 >> 2] = 0;
																					h = p - c | 0;
																					if (!((h | 0) <= 0 | (h | 0) > (q | 0))) {
																						ja(e + 48 | 0, y[a + 20 >> 2], h - 1 | 0);
																						c = y[e + 52 >> 2];
																						y[e + 76 >> 2] = c;
																						f = y[e + 48 >> 2];
																						y[e + 72 >> 2] = f;
																						if (!c) {
																							break l;
																						}
																						c = z[f | 0];
																						y[e + 8 >> 2] = c;
																						i = c & 192;
																					}
																					k = 0;
																					c = 0;
																					o: {
																						if ((h | 0) < 0) {
																							break o;
																						}
																						c = 0;
																						if ((h | 0) >= (q | 0)) {
																							break o;
																						}
																						ja(e + 48 | 0, y[a + 20 >> 2], h);
																						c = y[e + 52 >> 2];
																						y[e + 84 >> 2] = c;
																						f = y[e + 48 >> 2];
																						y[e + 80 >> 2] = f;
																						if (!c) {
																							break l;
																						}
																						c = z[f | 0];
																						y[e + 12 >> 2] = c;
																						c = c >>> 3 & 24;
																					}
																					if (!((h | 0) < -1 | (h | 0) >= (I | 0))) {
																						ja(e + 48 | 0, y[a + 20 >> 2], h + 1 | 0);
																						h = y[e + 52 >> 2];
																						y[e + 92 >> 2] = h;
																						f = y[e + 48 >> 2];
																						y[e + 88 >> 2] = f;
																						if (!h) {
																							break l;
																						}
																						h = z[f | 0];
																						y[e + 16 >> 2] = h;
																						k = h >>> 6 | 0;
																					}
																					p: {
																						if (!v) {
																							g = c | (j & 3072 | i) | k;
																							n = 0;
																							x = y[e + 32 >> 2];
																							A = y[e + 36 >> 2];
																							k = 0;
																							q: while (1) {
																								if ((k | 0) >= (m | 0)) {
																									break p;
																								}
																								r: {
																									if (!p) {
																										break r;
																									}
																									j = j << 8;
																									if ((m | 0) <= (k + 8 | 0)) {
																										break r;
																									}
																									c = (k >>> 3 | 0) + 1 | 0;
																									if (c >>> 0 >= t >>> 0) {
																										break l;
																									}
																									j = z[c + D | 0] << 4 | j;
																								}
																								s: {
																									if ((L + y[a + 16 >> 2] | 0) < (p | 0)) {
																										h = 0;
																										y[e + 16 >> 2] = 0;
																										y[e + 8 >> 2] = 0;
																										y[e + 12 >> 2] = 0;
																										r = 0;
																										c = 0;
																										break s;
																									}
																									c = (k >>> 3 | 0) + 1 | 0;
																									f = 0;
																									i = e + 8 | 0;
																									h = (F | 0) <= (k + 8 | 0);
																									while (1) {
																										if ((f | 0) != 24) {
																											r = (e + 72 | 0) + f | 0;
																											G = y[r + 4 >> 2];
																											t: {
																												if (!G) {
																													break t;
																												}
																												C = y[i >> 2] << 8;
																												y[i >> 2] = C;
																												if (h) {
																													break t;
																												}
																												if (c >>> 0 >= G >>> 0) {
																													break l;
																												}
																												y[i >> 2] = C | z[c + y[r >> 2] | 0];
																											}
																											i = i + 4 | 0;
																											f = f + 8 | 0;
																											continue;
																										}
																										break;
																									}
																									h = y[e + 16 >> 2];
																									r = y[e + 8 >> 2];
																									c = y[e + 12 >> 2];
																								}
																								f = 0;
																								i = n + m | 0;
																								i = (i | 0) > 0 ? i : 0;
																								G = (i | 0) >= 8 ? 8 : i;
																								i = 0;
																								while (1) {
																									if ((f | 0) == (G | 0)) {
																										c = k >>> 3 | 0;
																										if (c >>> 0 >= A >>> 0) {
																											break l;
																										}
																										w[c + x | 0] = i;
																										n = n - 8 | 0;
																										k = k + 8 | 0;
																										continue q;
																									}
																									if (g >>> 0 >= u >>> 0) {
																										break l;
																									}
																									C = g << 1;
																									H = ka(b, C + E | 0);
																									g = f ^ 7;
																									i = H << g | i;
																									g = h >>> 13 - f & 1 | (c >>> 10 - f & 8 | (r >>> g & 64 | (j >>> g & 1024 | C & 6582 | H << 9)));
																									f = f + 1 | 0;
																									continue;
																								}
																							}
																						}
																						Cb(e + 48 | 0, y[a + 20 >> 2], p);
																						i = c | (j & 3072 | i) | k;
																						h = 0;
																						A = y[e + 32 >> 2];
																						G = y[e + 36 >> 2];
																						C = y[e + 60 >> 2];
																						H = y[e + 56 >> 2];
																						k = 0;
																						while (1) {
																							if ((h | 0) >= (m | 0)) {
																								break p;
																							}
																							u: {
																								if (!p) {
																									c = h + 8 | 0;
																									break u;
																								}
																								j = j << 8;
																								c = h + 8 | 0;
																								if ((m | 0) <= (c | 0)) {
																									break u;
																								}
																								f = (h >>> 3 | 0) + 1 | 0;
																								if (f >>> 0 >= t >>> 0) {
																									break l;
																								}
																								j = z[f + D | 0] << 4 | j;
																							}
																							r = h >>> 3 | 0;
																							n = r + 1 | 0;
																							f = 0;
																							g = e + 8 | 0;
																							while (1) {
																								v: {
																									if ((f | 0) == 24) {
																										f = 0;
																										g = k + m | 0;
																										g = (g | 0) > 0 ? g : 0;
																										K = (g | 0) >= 8 ? 8 : g;
																										N = y[e + 16 >> 2];
																										M = y[e + 12 >> 2];
																										O = y[e + 8 >> 2];
																										n = 0;
																										while (1) {
																											if ((f | 0) == (K | 0)) {
																												break v;
																											}
																											x = y[y[a + 20 >> 2] + 20 >> 2];
																											P = f + h | 0;
																											g = ia(x, P, H, C);
																											w: {
																												if (z[a + 1 | 0] == 1) {
																													if (Bb(x, P, g, e + 48 | 0)) {
																														break w;
																													}
																												}
																												if (z[b | 0]) {
																													break e;
																												}
																												if (i >>> 0 >= u >>> 0) {
																													break l;
																												}
																												g = ka(b, E + (i << 1) | 0);
																											}
																											x = f ^ 7;
																											i = N >>> 13 - f & 1 | (M >>> 10 - f & 8 | (j >>> x & 1024 | i << 1 & 6582 | g << 9 | O >>> x & 64));
																											f = f + 1 | 0;
																											n = g << x | n;
																											continue;
																										}
																									}
																									x = (e + 72 | 0) + f | 0;
																									K = y[x + 4 >> 2];
																									x: {
																										if (!K) {
																											break x;
																										}
																										N = y[g >> 2] << 8;
																										y[g >> 2] = N;
																										if ((c | 0) >= (F | 0)) {
																											break x;
																										}
																										if (n >>> 0 >= K >>> 0) {
																											break l;
																										}
																										y[g >> 2] = N | z[n + y[x >> 2] | 0];
																									}
																									g = g + 4 | 0;
																									f = f + 8 | 0;
																									continue;
																								}
																								break;
																							}
																							if (r >>> 0 >= G >>> 0) {
																								break l;
																							}
																							w[r + A | 0] = n;
																							k = k - 8 | 0;
																							h = c;
																							continue;
																						}
																					}
																					p = p + 1 | 0;
																					continue;
																				}
																				break;
																			}
																			y[e + 44 >> 2] = 0;
																			break d;
																		}
																		l = ua(p, D);
																		y[e + 44 >> 2] = l;
																		f = y[l + 16 >> 2];
																		if (!f) {
																			break g;
																		}
																		E = c;
																		g = y[l + 12 >> 2];
																		while (1) {
																			if ((f | 0) > 0) {
																				w[g | 0] = 0;
																				f = f - 1 | 0;
																				g = g + 1 | 0;
																				continue;
																			}
																			break;
																		}
																		t = E + 32 | 0;
																		while (1) {
																			if (B[D >> 2] > h >>> 0) {
																				if (z[a + 1 | 0] == 1) {
																					if (z[b | 0]) {
																						break g;
																					}
																					if ((d | 0) == 16 | d >>> 0 < 16) {
																						break l;
																					}
																					k = ka(b, t) ^ k;
																				}
																				ja(e + 32 | 0, l, h);
																				c = e + 72 | 0;
																				ja(c, l, h - 1 | 0);
																				j = y[e + 76 >> 2];
																				u = y[e + 72 >> 2];
																				v = y[a + 16 >> 2];
																				i = y[a + 20 >> 2];
																				jd(c, v, i, h);
																				f = 0;
																				c = y[l + 20 >> 2];
																				f = !j | (c | 0) < 2 ? f : z[u | 0] >>> 6 & 1;
																				if (!(!j | (c | 0) <= 0)) {
																					f = z[u | 0] >>> 6 & 2 | f;
																				}
																				y[e + 8 >> 2] = f;
																				y[e + 12 >> 2] = 0;
																				c = y[i + 20 >> 2];
																				f = y[a + 12 >> 2];
																				g = 1 - f | 0;
																				m = y[e + 72 >> 2];
																				q = y[e + 76 >> 2];
																				n = 0 - f | 0;
																				Q = e, R = ia(c, g, m, q) | ia(c, n, m, q) << 1, y[Q + 16 >> 2] = R;
																				m = y[e + 80 >> 2];
																				q = y[e + 84 >> 2];
																				s = ia(c, g, m, q);
																				r = s | ia(c, n, m, q) << 1;
																				s = f ^ -1;
																				Q = e, R = r | ia(c, s, m, q) << 2, y[Q + 20 >> 2] = R;
																				m = g;
																				f = y[e + 88 >> 2];
																				g = y[e + 92 >> 2];
																				m = ia(c, m, f, g);
																				Q = e, R = m | ia(c, n, f, g) << 1 | ia(c, s, f, g) << 2, y[Q + 24 >> 2] = R;
																				c = e + 48 | 0;
																				ja(c, i, w[a + 27 | 0] + (h - v | 0) | 0);
																				f = y[e + 52 >> 2];
																				g = y[e + 48 >> 2];
																				ja(c, l, w[a + 25 | 0] + h | 0);
																				c = y[e + 52 >> 2];
																				n = y[e + 48 >> 2];
																				y: {
																					if (!k) {
																						m = u;
																						u = j;
																						j = c;
																						c = f;
																						q = g;
																						f = 0;
																						i = y[e + 32 >> 2];
																						v = y[e + 36 >> 2];
																						while (1) {
																							if (B[p >> 2] <= f >>> 0) {
																								break y;
																							}
																							s = e + 8 | 0;
																							g = id(a, y[l + 20 >> 2], s, f, q, c, n, j);
																							if (z[b | 0]) {
																								break g;
																							}
																							if (d >>> 0 <= g >>> 0) {
																								break l;
																							}
																							hd(a, l, s, f, ka(b, E + (g << 1) | 0), e + 72 | 0, m, u, i, v);
																							f = f + 1 | 0;
																							continue;
																						}
																					}
																					Cb(e + 48 | 0, i, h);
																					m = u;
																					u = j;
																					j = c;
																					c = f;
																					q = g;
																					f = 0;
																					i = y[e + 32 >> 2];
																					v = y[e + 36 >> 2];
																					s = y[e + 60 >> 2];
																					F = y[e + 56 >> 2];
																					while (1) {
																						if (B[p >> 2] <= f >>> 0) {
																							break y;
																						}
																						r = y[y[a + 20 >> 2] + 20 >> 2];
																						g = ia(r, f, F, s);
																						z: {
																							if (z[a + 1 | 0] == 1) {
																								if (Bb(r, f, g, e + 48 | 0)) {
																									break z;
																								}
																							}
																							g = id(a, y[l + 20 >> 2], e + 8 | 0, f, q, c, n, j);
																							if (z[b | 0] == 1) {
																								break g;
																							}
																							if (d >>> 0 <= g >>> 0) {
																								break l;
																							}
																							g = ka(b, E + (g << 1) | 0);
																						}
																						hd(a, l, e + 8 | 0, f, g, e + 72 | 0, m, u, i, v);
																						f = f + 1 | 0;
																						continue;
																					}
																				}
																				h = h + 1 | 0;
																				continue;
																			}
																			break;
																		}
																		y[e + 44 >> 2] = 0;
																		break f;
																	}
																	A: {
																		if (y[a + 12 >> 2]) {
																			break A;
																		}
																		j = y[a + 20 >> 2];
																		if ((m | 0) != y[j + 20 >> 2]) {
																			break A;
																		}
																		if (!y[j + 16 >> 2]) {
																			break c;
																		}
																		l = hc(m, s);
																		y[e + 44 >> 2] = l;
																		if (!y[l + 16 >> 2]) {
																			break i;
																		}
																		u = d;
																		E = c;
																		c = y[a + 20 >> 2];
																		r = y[c + 20 >> 2];
																		v = y[c + 24 >> 2];
																		c = y[a + 16 >> 2];
																		if (!((1 - v | 0) <= (c | 0) & (c | 0) < (v | 0))) {
																			y[a + 16 >> 2] = 0;
																		}
																		x = v - 1 | 0;
																		L = E + 16 | 0;
																		p = 0;
																		while (1) {
																			B: {
																				C: {
																					if ((p | 0) != (s | 0)) {
																						if (z[a + 1 | 0] == 1) {
																							if (z[b | 0]) {
																								break i;
																							}
																							if ((d | 0) == 8 | d >>> 0 < 8) {
																								break l;
																							}
																							q = ka(b, L) ^ q;
																						}
																						ja(e + 32 | 0, l, p);
																						i = 0;
																						D: {
																							if (!p) {
																								t = 0;
																								F = 0;
																								j = 0;
																								break D;
																							}
																							ja(e + 72 | 0, l, p - 1 | 0);
																							F = y[e + 76 >> 2];
																							if (!F) {
																								break l;
																							}
																							t = y[e + 72 >> 2];
																							j = z[t | 0] << 1;
																						}
																						c = y[a + 16 >> 2];
																						y[e + 88 >> 2] = 0;
																						y[e + 92 >> 2] = 0;
																						y[e + 80 >> 2] = 0;
																						y[e + 84 >> 2] = 0;
																						y[e + 72 >> 2] = 0;
																						y[e + 76 >> 2] = 0;
																						y[e + 16 >> 2] = 0;
																						y[e + 8 >> 2] = 0;
																						y[e + 12 >> 2] = 0;
																						h = p - c | 0;
																						if (!((h | 0) <= 0 | (h | 0) > (v | 0))) {
																							ja(e + 48 | 0, y[a + 20 >> 2], h - 1 | 0);
																							c = y[e + 52 >> 2];
																							y[e + 76 >> 2] = c;
																							f = y[e + 48 >> 2];
																							y[e + 72 >> 2] = f;
																							if (!c) {
																								break l;
																							}
																							c = z[f | 0];
																							y[e + 8 >> 2] = c;
																							i = c >>> 2 & 32;
																						}
																						k = 0;
																						c = 0;
																						E: {
																							if ((h | 0) < 0) {
																								break E;
																							}
																							c = 0;
																							if ((h | 0) >= (v | 0)) {
																								break E;
																							}
																							ja(e + 48 | 0, y[a + 20 >> 2], h);
																							c = y[e + 52 >> 2];
																							y[e + 84 >> 2] = c;
																							f = y[e + 48 >> 2];
																							y[e + 80 >> 2] = f;
																							if (!c) {
																								break l;
																							}
																							c = z[f | 0];
																							y[e + 12 >> 2] = c;
																							c = c >>> 4 & 12;
																						}
																						if (!((h | 0) < -1 | (h | 0) >= (x | 0))) {
																							ja(e + 48 | 0, y[a + 20 >> 2], h + 1 | 0);
																							h = y[e + 52 >> 2];
																							y[e + 92 >> 2] = h;
																							f = y[e + 48 >> 2];
																							y[e + 88 >> 2] = f;
																							if (!h) {
																								break l;
																							}
																							h = z[f | 0];
																							y[e + 16 >> 2] = h;
																							k = h >>> 6 | 0;
																						}
																						if (q) {
																							break C;
																						}
																						i = c | (j & 384 | i) | k;
																						f = 0;
																						D = y[e + 32 >> 2];
																						I = y[e + 36 >> 2];
																						n = 0;
																						F: while (1) {
																							if ((f | 0) >= (m | 0)) {
																								break B;
																							}
																							G: {
																								if (!p) {
																									c = f + 8 | 0;
																									break G;
																								}
																								j = j << 8;
																								c = f + 8 | 0;
																								if ((m | 0) <= (c | 0)) {
																									break G;
																								}
																								h = (f >>> 3 | 0) + 1 | 0;
																								if (h >>> 0 >= F >>> 0) {
																									break l;
																								}
																								j = z[h + t | 0] << 1 | j;
																							}
																							h = f >>> 3 | 0;
																							k = h + 1 | 0;
																							f = 0;
																							g = e + 8 | 0;
																							while (1) {
																								if ((f | 0) == 24) {
																									f = 0;
																									g = n + m | 0;
																									g = (g | 0) > 0 ? g : 0;
																									k = (g | 0) >= 8 ? 8 : g;
																									J = y[e + 16 >> 2];
																									A = y[e + 12 >> 2];
																									G = y[e + 8 >> 2];
																									g = 0;
																									while (1) {
																										if ((f | 0) == (k | 0)) {
																											if (h >>> 0 >= I >>> 0) {
																												break l;
																											}
																											w[h + D | 0] = g;
																											n = n - 8 | 0;
																											f = c;
																											continue F;
																										}
																										if (i >>> 0 >= u >>> 0) {
																											break l;
																										}
																										i = i << 1;
																										C = ka(b, i + E | 0);
																										H = f ^ 7;
																										g = C << H | g;
																										i = J >>> 13 - f & 1 | (A >>> 11 - f & 4 | (G >>> 9 - f & 32 | (j >>> H & 128 | i & 794 | C << 6)));
																										f = f + 1 | 0;
																										continue;
																									}
																								}
																								J = (e + 72 | 0) + f | 0;
																								A = y[J + 4 >> 2];
																								H: {
																									if (!A) {
																										break H;
																									}
																									G = y[g >> 2] << 8;
																									y[g >> 2] = G;
																									if ((c | 0) >= (r | 0)) {
																										break H;
																									}
																									if (k >>> 0 >= A >>> 0) {
																										break l;
																									}
																									y[g >> 2] = G | z[k + y[J >> 2] | 0];
																								}
																								g = g + 4 | 0;
																								f = f + 8 | 0;
																								continue;
																							}
																						}
																					}
																					y[e + 44 >> 2] = 0;
																					break h;
																				}
																				Cb(e + 48 | 0, y[a + 20 >> 2], p);
																				i = c | (j & 384 | i) | k;
																				h = 0;
																				I = y[e + 32 >> 2];
																				J = y[e + 36 >> 2];
																				A = y[e + 60 >> 2];
																				G = y[e + 56 >> 2];
																				D = 0;
																				while (1) {
																					if ((h | 0) >= (m | 0)) {
																						break B;
																					}
																					I: {
																						if (!p) {
																							c = h + 8 | 0;
																							break I;
																						}
																						j = j << 8;
																						c = h + 8 | 0;
																						if ((m | 0) <= (c | 0)) {
																							break I;
																						}
																						f = (h >>> 3 | 0) + 1 | 0;
																						if (f >>> 0 >= F >>> 0) {
																							break l;
																						}
																						j = z[f + t | 0] << 1 | j;
																					}
																					n = h >>> 3 | 0;
																					k = n + 1 | 0;
																					f = 0;
																					g = e + 8 | 0;
																					while (1) {
																						J: {
																							if ((f | 0) == 24) {
																								f = 0;
																								g = m + D | 0;
																								g = (g | 0) > 0 ? g : 0;
																								C = (g | 0) >= 8 ? 8 : g;
																								H = y[e + 16 >> 2];
																								K = y[e + 12 >> 2];
																								N = y[e + 8 >> 2];
																								k = 0;
																								while (1) {
																									if ((f | 0) == (C | 0)) {
																										break J;
																									}
																									M = y[y[a + 20 >> 2] + 20 >> 2];
																									O = f + h | 0;
																									g = ia(M, O, G, A);
																									K: {
																										if (z[a + 1 | 0] == 1) {
																											if (Bb(M, O, g, e + 48 | 0)) {
																												break K;
																											}
																										}
																										if (z[b | 0]) {
																											break i;
																										}
																										if (i >>> 0 >= u >>> 0) {
																											break l;
																										}
																										g = ka(b, E + (i << 1) | 0);
																									}
																									M = f ^ 7;
																									i = H >>> 13 - f & 1 | (K >>> 11 - f & 4 | (N >>> 9 - f & 32 | (j >>> M & 128 | i << 1 & 794 | g << 6)));
																									f = f + 1 | 0;
																									k = g << M | k;
																									continue;
																								}
																							}
																							C = (e + 72 | 0) + f | 0;
																							H = y[C + 4 >> 2];
																							L: {
																								if (!H) {
																									break L;
																								}
																								K = y[g >> 2] << 8;
																								y[g >> 2] = K;
																								if ((c | 0) >= (r | 0)) {
																									break L;
																								}
																								if (k >>> 0 >= H >>> 0) {
																									break l;
																								}
																								y[g >> 2] = K | z[k + y[C >> 2] | 0];
																							}
																							g = g + 4 | 0;
																							f = f + 8 | 0;
																							continue;
																						}
																						break;
																					}
																					if (n >>> 0 >= J >>> 0) {
																						break l;
																					}
																					w[n + I | 0] = k;
																					D = D - 8 | 0;
																					h = c;
																					continue;
																				}
																			}
																			p = p + 1 | 0;
																			continue;
																		}
																	}
																	l = ua(p, D);
																	y[e + 32 >> 2] = l;
																	f = y[l + 16 >> 2];
																	if (!f) {
																		break k;
																	}
																	E = c;
																	g = y[l + 12 >> 2];
																	while (1) {
																		if ((f | 0) > 0) {
																			w[g | 0] = 0;
																			f = f - 1 | 0;
																			g = g + 1 | 0;
																			continue;
																		}
																		break;
																	}
																	J = E + 16 | 0;
																	while (1) {
																		if (B[D >> 2] > q >>> 0) {
																			if (z[a + 1 | 0] == 1) {
																				if (z[b | 0]) {
																					break k;
																				}
																				if ((d | 0) == 8 | d >>> 0 < 8) {
																					break l;
																				}
																				v = ka(b, J) ^ v;
																			}
																			ja(e + 8 | 0, l, q);
																			c = e + 72 | 0;
																			ja(c, l, q - 1 | 0);
																			u = y[e + 76 >> 2];
																			m = y[e + 72 >> 2];
																			j = y[a + 20 >> 2];
																			jd(c, y[a + 16 >> 2], j, q);
																			i = 0;
																			t = y[l + 20 >> 2];
																			i = !u | (t | 0) < 2 ? i : z[m | 0] >>> 6 & 1;
																			i = !u | (t | 0) <= 0 ? i : z[m | 0] >>> 6 & 2 | i;
																			g = y[j + 20 >> 2];
																			f = y[a + 12 >> 2];
																			c = 0 - f | 0;
																			r = y[e + 72 >> 2];
																			x = y[e + 76 >> 2];
																			ia(g, c, r, x);
																			h = ia(g, c, r, x);
																			n = 1 - f | 0;
																			s = y[e + 80 >> 2];
																			F = y[e + 84 >> 2];
																			k = ia(g, n, s, F) | ia(g, c, s, F) << 1 | ia(g, f ^ -1, s, F) << 2;
																			L = y[e + 88 >> 2];
																			I = y[e + 92 >> 2];
																			n = ia(g, n, L, I) | ia(g, c, L, I) << 1;
																			M: {
																				if (!v) {
																					g = 0;
																					j = y[e + 12 >> 2];
																					t = y[e + 8 >> 2];
																					f = 0;
																					while (1) {
																						if (B[p >> 2] <= f >>> 0) {
																							break M;
																						}
																						if (z[b | 0]) {
																							break k;
																						}
																						c = k << 2 | h << 5 | g << 6 | i << 7 | n;
																						if (c >>> 0 >= d >>> 0) {
																							break l;
																						}
																						g = ka(b, E + (c << 1) | 0);
																						Ea(y[l + 20 >> 2], f, t, j, g);
																						h = y[a + 12 >> 2];
																						i = ia(y[l + 20 >> 2], f + 2 | 0, m, u) | i << 1 & 6;
																						c = y[y[a + 20 >> 2] + 20 >> 2];
																						A = f - h | 0;
																						h = ia(c, A + 1 | 0, r, x);
																						A = A + 2 | 0;
																						k = ia(c, A, s, F) | k << 1 & 6;
																						n = ia(c, A, L, I) | n << 1 & 2;
																						f = f + 1 | 0;
																						continue;
																					}
																				}
																				Cb(e + 48 | 0, j, q);
																				c = 0;
																				A = y[e + 12 >> 2];
																				G = y[e + 8 >> 2];
																				C = y[e + 60 >> 2];
																				H = y[e + 56 >> 2];
																				f = 0;
																				while (1) {
																					if (B[p >> 2] <= f >>> 0) {
																						break M;
																					}
																					j = ia(g, f, H, C);
																					N: {
																						if (z[a + 1 | 0] == 1) {
																							if (Bb(g, f, j, e + 48 | 0)) {
																								break N;
																							}
																						}
																						if (z[b | 0] == 1) {
																							break k;
																						}
																						c = k << 2 | h << 5 | c << 6 | i << 7 | n;
																						if (c >>> 0 >= d >>> 0) {
																							break l;
																						}
																						j = ka(b, E + (c << 1) | 0);
																						t = y[l + 20 >> 2];
																					}
																					Ea(t, f, G, A, j);
																					c = y[a + 12 >> 2];
																					t = y[l + 20 >> 2];
																					i = ia(t, f + 2 | 0, m, u) | i << 1 & 6;
																					g = y[y[a + 20 >> 2] + 20 >> 2];
																					c = f - c | 0;
																					h = ia(g, c + 1 | 0, r, x);
																					c = c + 2 | 0;
																					k = ia(g, c, s, F) | k << 1 & 6;
																					n = ia(g, c, L, I) | n << 1 & 2;
																					f = f + 1 | 0;
																					c = j;
																					continue;
																				}
																			}
																			q = q + 1 | 0;
																			continue;
																		}
																		break;
																	}
																	y[e + 32 >> 2] = 0;
																	break j;
																}
																o();
															}
															l = 0;
														}
														la(e + 32 | 0);
														break a;
													}
													l = 0;
												}
												la(e + 44 | 0);
												break a;
											}
											l = 0;
										}
										la(e + 44 | 0);
										break a;
									}
									l = 0;
								}
								la(e + 44 | 0);
							}
						}
						Y = e + 96 | 0;
						return l;
					}
					function cd(a, b, c, d, e, f, g, h) {
						var i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, I = 0, J = 0, K = 0, L = 0;
						i = Y - 32 | 0;
						Y = i;
						a: {
							b: {
								d = d - (c >>> 0 < 1048577) | 0;
								k = (d | 0) == -1 & c - 1048577 >>> 0 < 4292870143 | (d | 0) != -1;
								d = f - (e >>> 0 < 1048577) | 0;
								if (k | ((d | 0) == -1 & e - 1048577 >>> 0 < 4292870143 | (d | 0) != -1)) {
									break b;
								}
								k = y[h + 4 >> 2];
								l = y[h + 12 >> 2];
								j = y[h >> 2];
								p = y[h + 8 >> 2];
								y[i + 28 >> 2] = y[b + 20 >> 2];
								w[i + 24 | 0] = 1;
								d = c;
								f = bd(i + 24 | 0, c);
								q = z[f | 0];
								h = y[i + 28 >> 2];
								m = y[b + 24 >> 2];
								y[f >> 2] = 1;
								y[f + 4 >> 2] = m;
								m = bd(f, e);
								f = l - k | 0;
								l = y[i + 28 >> 2];
								m = z[m | 0] ? (f | 0) < (l | 0) ? f : l : f;
								l = e & e >> 31;
								f = p - j | 0;
								A = q ? (f | 0) < (h | 0) ? f : h : f;
								c = c & c >> 31;
								r = 0 - c | 0;
								if (!((m | 0) > (0 - l | 0) & (A | 0) > (r | 0))) {
									break b;
								}
								f = j - c | 0;
								if ((f | 0) < 0) {
									break a;
								}
								c = y[a + 28 >> 2];
								x = (c | 0) / 4 | 0;
								p = f >>> 5 | 0;
								if (x >>> 0 <= p >>> 0) {
									break a;
								}
								h = y[b + 28 >> 2];
								s = (h | 0) / 4 | 0;
								f = (d | 0) > 0 ? d : 0;
								q = f >>> 5 | 0;
								if (s >>> 0 <= q >>> 0) {
									break a;
								}
								j = i + 16 | 0;
								n = k - l | 0;
								k = l + m | 0;
								cc(j, a, n, k);
								l = y[i + 20 >> 2];
								m = y[i + 16 >> 2];
								cc(j, b, (e | 0) > 0 ? e : 0, k);
								j = y[i + 20 >> 2];
								if (!j) {
									break a;
								}
								F = -1 >>> f | 0;
								k = d + A | 0;
								G = -1 << 0 - k;
								e = r & 31;
								n = f & 31;
								t = x - p | 0;
								if ((f ^ k - 1) >>> 0 <= 31) {
									d = F & G;
									if ((r ^ A - 1) >>> 0 >= 32) {
										k = e - n | 0;
										n = 32 - k | 0;
										r = p << 2;
										while (1) {
											if (!j) {
												break b;
											}
											if (l >>> 0 < p >>> 0 | t >>> 0 > l - p >>> 0) {
												break a;
											}
											y[i + 12 >> 2] = t;
											y[i + 8 >> 2] = m + r;
											e = (h | 0) / 4 | 0;
											if (e >>> 0 > j >>> 0) {
												break a;
											}
											f = y[i + 16 >> 2];
											c = Ya(i + 8 | 0);
											if (!y[i + 12 >> 2] | e >>> 0 < q >>> 0 | (e | 0) == (q | 0)) {
												break a;
											}
											e = (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) << k;
											c = y[y[i + 8 >> 2] >> 2];
											h = e | (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) >>> n;
											e = f + (q << 2) | 0;
											c = y[e >> 2];
											c = Ma(g, h, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), d);
											h = ((Ae(c, 16) ^ c) & -16711936) >>> 8 | 0;
											K = e, L = Ae(c, 8) ^ h, y[K >> 2] = L;
											c = y[a + 28 >> 2] / 4 | 0;
											if (c >>> 0 > l >>> 0) {
												break a;
											}
											h = y[b + 28 >> 2];
											e = (h | 0) / 4 | 0;
											if (e >>> 0 > j >>> 0) {
												break a;
											}
											y[i + 16 >> 2] = f + (e << 2);
											j = j - e | 0;
											l = l - c | 0;
											m = (c << 2) + m | 0;
											continue;
										}
									}
									if (e >>> 0 > n >>> 0) {
										k = e - n | 0;
										n = p << 2;
										while (1) {
											if (!j) {
												break b;
											}
											c = (c | 0) / 4 | 0;
											if (c >>> 0 > l >>> 0) {
												break a;
											}
											e = (h | 0) / 4 | 0;
											if (c >>> 0 < p >>> 0 | e >>> 0 > j >>> 0 | ((c | 0) == (p | 0) | e >>> 0 < q >>> 0) | (e | 0) == (q | 0)) {
												break a;
											}
											t = y[i + 16 >> 2];
											e = t + (q << 2) | 0;
											c = y[m + n >> 2];
											f = (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) << k;
											c = y[e >> 2];
											c = Ma(g, f, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), d);
											K = e, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
											c = y[a + 28 >> 2];
											e = (c | 0) / 4 | 0;
											if (e >>> 0 > l >>> 0) {
												break a;
											}
											h = y[b + 28 >> 2];
											f = (h | 0) / 4 | 0;
											if (f >>> 0 > j >>> 0) {
												break a;
											}
											y[i + 16 >> 2] = t + (f << 2);
											j = j - f | 0;
											l = l - e | 0;
											m = (e << 2) + m | 0;
											continue;
										}
									}
									k = n - e | 0;
									n = p << 2;
									while (1) {
										if (!j) {
											break b;
										}
										c = (c | 0) / 4 | 0;
										if (c >>> 0 > l >>> 0) {
											break a;
										}
										e = (h | 0) / 4 | 0;
										if (c >>> 0 < p >>> 0 | e >>> 0 > j >>> 0 | ((c | 0) == (p | 0) | e >>> 0 < q >>> 0) | (e | 0) == (q | 0)) {
											break a;
										}
										t = y[i + 16 >> 2];
										e = t + (q << 2) | 0;
										c = y[m + n >> 2];
										f = (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) >>> k | 0;
										c = y[e >> 2];
										c = Ma(g, f, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), d);
										K = e, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
										c = y[a + 28 >> 2];
										e = (c | 0) / 4 | 0;
										if (e >>> 0 > l >>> 0) {
											break a;
										}
										h = y[b + 28 >> 2];
										f = (h | 0) / 4 | 0;
										if (f >>> 0 > j >>> 0) {
											break a;
										}
										y[i + 16 >> 2] = t + (f << 2);
										j = j - f | 0;
										l = l - e | 0;
										m = (e << 2) + m | 0;
										continue;
									}
								}
								A = k & 31;
								d = s - q | 0;
								x = x - (r >>> 5 | 0) | 0;
								if (e >>> 0 <= n >>> 0) {
									if ((e | 0) == (n | 0)) {
										k = ((k | 0) / 32 | 0) - (f + 31 >>> 5 | 0) | 0;
										if ((k | 0) < 0) {
											break a;
										}
										C = p << 2;
										c: while (1) {
											if (!j) {
												break b;
											}
											if (l >>> 0 < p >>> 0 | t >>> 0 > l - p >>> 0) {
												break a;
											}
											y[i + 12 >> 2] = t;
											y[i + 8 >> 2] = m + C;
											if (j >>> 0 < q >>> 0 | d >>> 0 > j - q >>> 0) {
												break a;
											}
											y[i + 4 >> 2] = d;
											u = y[i + 16 >> 2];
											y[i >> 2] = u + (q << 2);
											f = d;
											if (n) {
												c = Ya(i + 8 | 0);
												e = bc(i);
												f = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8);
												c = y[e >> 2];
												c = Ma(g, f, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), F);
												K = e, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
												f = y[i + 4 >> 2];
											}
											if (f >>> 0 < k >>> 0) {
												break a;
											}
											c = y[i + 8 >> 2];
											if (B[i + 12 >> 2] < k >>> 0) {
												break a;
											}
											h = y[i >> 2];
											D = k << 2;
											r = h + D | 0;
											x = y[i + 12 >> 2];
											e = c;
											while (1) if ((h | 0) == (r | 0)) {
												if (A) {
													if ((k | 0) == (x | 0) | k >>> 0 > x >>> 0 | (f | 0) == (k | 0)) {
														break a;
													}
													c = y[e + D >> 2];
													e = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8);
													c = y[r >> 2];
													c = Ma(g, e, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), G);
													K = r, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
												}
												c = y[a + 28 >> 2] / 4 | 0;
												if (c >>> 0 > l >>> 0) {
													break a;
												}
												e = y[b + 28 >> 2] / 4 | 0;
												if (e >>> 0 > j >>> 0) {
													break a;
												}
												y[i + 16 >> 2] = u + (e << 2);
												j = j - e | 0;
												l = l - c | 0;
												m = (c << 2) + m | 0;
												continue c;
											} else {
												s = y[c >> 2];
												v = ((Ae(s, 16) ^ s) & -16711936) >>> 8 ^ Ae(s, 8);
												s = y[h >> 2];
												s = yb(g, v, ((Ae(s, 16) ^ s) & -16711936) >>> 8 ^ Ae(s, 8));
												K = h, L = ((Ae(s, 16) ^ s) & -16711936) >>> 8 ^ Ae(s, 8), y[K >> 2] = L;
												c = c + 4 | 0;
												h = h + 4 | 0;
												continue;
											}
										}
									}
									k = ((k | 0) / 32 | 0) - (f + 31 >>> 5 | 0) | 0;
									if ((k | 0) < 0) {
										break a;
									}
									n = n - e | 0;
									s = 32 - n | 0;
									D = p << 2;
									d: while (1) {
										if (!j) {
											break b;
										}
										if (l >>> 0 < p >>> 0 | t >>> 0 > l - p >>> 0) {
											break a;
										}
										y[i + 12 >> 2] = t;
										c = m + D | 0;
										y[i + 8 >> 2] = c;
										if (j >>> 0 < q >>> 0 | d >>> 0 > j - q >>> 0) {
											break a;
										}
										y[i + 4 >> 2] = d;
										v = y[i + 16 >> 2];
										y[i >> 2] = v + (q << 2);
										if (A) {
											if (t >>> 0 < x >>> 0) {
												break a;
											}
											y[i + 12 >> 2] = x;
											y[i + 8 >> 2] = c;
										}
										c = Ya(i + 8 | 0);
										e = bc(i);
										f = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8);
										c = y[e >> 2];
										c = Ma(g, f >>> n | 0, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), F);
										K = e, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
										H = y[i + 4 >> 2];
										if (H >>> 0 < k >>> 0) {
											break a;
										}
										c = y[i + 8 >> 2];
										if (B[i + 12 >> 2] < k >>> 0) {
											break a;
										}
										h = y[i >> 2];
										E = k << 2;
										r = h + E | 0;
										C = y[i + 12 >> 2];
										e = c;
										while (1) if ((h | 0) == (r | 0)) {
											if (A) {
												if (k >>> 0 > C >>> 0) {
													break a;
												}
												h = f << s;
												if ((k | 0) != (C | 0)) {
													c = y[e + E >> 2];
													h = (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) >>> n | h;
												}
												if ((k | 0) == (H | 0)) {
													break a;
												}
												c = y[r >> 2];
												c = Ma(g, h, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), G);
												K = r, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
											}
											c = y[a + 28 >> 2] / 4 | 0;
											if (c >>> 0 > l >>> 0) {
												break a;
											}
											e = y[b + 28 >> 2] / 4 | 0;
											if (e >>> 0 > j >>> 0) {
												break a;
											}
											y[i + 16 >> 2] = v + (e << 2);
											j = j - e | 0;
											l = l - c | 0;
											m = (c << 2) + m | 0;
											continue d;
										} else {
											I = f << s;
											f = y[c >> 2];
											f = ((Ae(f, 16) ^ f) & -16711936) >>> 8 ^ Ae(f, 8);
											u = y[h >> 2];
											u = yb(g, I | f >>> n, ((Ae(u, 16) ^ u) & -16711936) >>> 8 ^ Ae(u, 8));
											K = h, L = ((Ae(u, 16) ^ u) & -16711936) >>> 8 ^ Ae(u, 8), y[K >> 2] = L;
											c = c + 4 | 0;
											h = h + 4 | 0;
											continue;
										}
									}
								}
								r = ((k | 0) / 32 | 0) - (f + 31 >>> 5 | 0) | 0;
								if ((r | 0) < 0) {
									break a;
								}
								s = e - n | 0;
								C = 32 - s | 0;
								H = p << 2;
								e: while (1) {
									if (!j) {
										break b;
									}
									if (l >>> 0 < p >>> 0 | t >>> 0 > l - p >>> 0) {
										break a;
									}
									y[i + 12 >> 2] = t;
									c = m + H | 0;
									y[i + 8 >> 2] = c;
									if (j >>> 0 < q >>> 0 | d >>> 0 > j - q >>> 0) {
										break a;
									}
									y[i + 4 >> 2] = d;
									E = y[i + 16 >> 2];
									y[i >> 2] = E + (q << 2);
									if (A) {
										if (t >>> 0 < x >>> 0) {
											break a;
										}
										y[i + 12 >> 2] = x;
										y[i + 8 >> 2] = c;
									}
									e = i + 8 | 0;
									c = Ya(e);
									f = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8);
									if (n) {
										c = Ya(e);
										e = bc(i);
										h = f << s;
										f = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8);
										c = y[e >> 2];
										c = Ma(g, h | f >>> C, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), F);
										K = e, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
										e = y[i + 4 >> 2];
									} else {
										e = d;
									}
									if (e >>> 0 < r >>> 0) {
										break a;
									}
									c = y[i + 8 >> 2];
									if (B[i + 12 >> 2] < r >>> 0) {
										break a;
									}
									h = y[i >> 2];
									I = r << 2;
									u = h + I | 0;
									D = y[i + 12 >> 2];
									k = c;
									while (1) if ((h | 0) == (u | 0)) {
										if (A) {
											if (r >>> 0 > D >>> 0) {
												break a;
											}
											h = f << s;
											if ((r | 0) != (D | 0)) {
												c = y[k + I >> 2];
												h = (((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8)) >>> C | h;
											}
											if ((e | 0) == (r | 0)) {
												break a;
											}
											c = y[u >> 2];
											c = Ma(g, h, ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), G);
											K = u, L = ((Ae(c, 16) ^ c) & -16711936) >>> 8 ^ Ae(c, 8), y[K >> 2] = L;
										}
										c = y[a + 28 >> 2] / 4 | 0;
										if (c >>> 0 > l >>> 0) {
											break a;
										}
										e = y[b + 28 >> 2] / 4 | 0;
										if (e >>> 0 > j >>> 0) {
											break a;
										}
										y[i + 16 >> 2] = E + (e << 2);
										j = j - e | 0;
										l = l - c | 0;
										m = (c << 2) + m | 0;
										continue e;
									} else {
										J = f << s;
										f = y[c >> 2];
										f = ((Ae(f, 16) ^ f) & -16711936) >>> 8 ^ Ae(f, 8);
										v = y[h >> 2];
										v = yb(g, J | f >>> C, ((Ae(v, 16) ^ v) & -16711936) >>> 8 ^ Ae(v, 8));
										K = h, L = ((Ae(v, 16) ^ v) & -16711936) >>> 8 ^ Ae(v, 8), y[K >> 2] = L;
										c = c + 4 | 0;
										h = h + 4 | 0;
										continue;
									}
								}
							}
							Y = i + 32 | 0;
							return;
						}
						o();
					}
					function Gd(a, b, c, d) {
						var e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, q = 0, r = 0, s = 0, t = 0;
						e = Y - 128 | 0;
						Y = e;
						m = ua(a + 8 | 0, a + 12 | 0);
						y[e + 124 >> 2] = m;
						f = y[m + 16 >> 2];
						a: {
							if (!f) {
								break a;
							}
							Mb(y[m + 12 >> 2], f, z[a + 4 | 0]);
							j = td(b);
							y[e + 116 >> 2] = j;
							g = 0;
							b: {
								if (ya(j, y[a + 152 >> 2], e + 120 | 0)) {
									break b;
								}
								y[e + 108 >> 2] = y[e + 120 >> 2];
								w[e + 104 | 0] = 1;
								q = xb(e + 104 | 0, y[a + 20 >> 2]);
								g = q;
								h = y[e + 108 >> 2];
								f = 0 - h | 0;
								y[g >> 2] = z[g | 0] & (h | 0) != -2147483648;
								y[g + 4 >> 2] = f;
								y[e + 100 >> 2] = 0;
								w[e + 96 | 0] = 1;
								t = a + 28 | 0;
								c: {
									d: {
										e: while (1) {
											if (B[a + 16 >> 2] > r >>> 0) {
												if (ya(j, y[a + 152 >> 2], e + 92 | 0)) {
													break c;
												}
												y[e + 84 >> 2] = y[e + 92 >> 2];
												g = 1;
												w[e + 80 | 0] = 1;
												h = xb(e + 80 | 0, y[a + 20 >> 2]);
												s = Zc(q, y[h >> 2], y[h + 4 >> 2]);
												y[e + 76 >> 2] = 0;
												w[e + 72 | 0] = 1;
												while (1) {
													f: {
														if (g & 1) {
															if (ya(j, y[a + 144 >> 2], e + 12 | 0)) {
																break c;
															}
															g = La(e + 96 | 0, y[e + 12 >> 2]);
															f = y[g + 4 >> 2];
															y[e + 72 >> 2] = y[g >> 2];
															y[e + 76 >> 2] = f;
															break f;
														}
														g: {
															switch (ya(j, y[a + 148 >> 2], e + 12 | 0) | 0) {
																case 0: break g;
																case 1: continue e;
																default: break c;
															}
														}
														La(La(e + 72 | 0, y[e + 12 >> 2]), w[a + 5 | 0]);
													}
													g = 0;
													f = y[a + 20 >> 2];
													if ((f | 0) != 1) {
														f = ib(f);
														if (Fa(b, f >>> 0 <= 1 ? 1 : f, e + 12 | 0)) {
															break c;
														}
														g = z[e + 12 | 0];
													}
													f = y[s + 4 >> 2];
													if (!(y[s >> 2] & 1)) {
														break c;
													}
													p = f + g | 0;
													if ((p & (f ^ -1)) < 0) {
														break c;
													}
													if (ya(j, t, e + 68 | 0)) {
														break c;
													}
													h: {
														i: {
															j: {
																if (!z[a + 1 | 0]) {
																	w[e + 64 | 0] = 0;
																	y[e + 60 >> 2] = 0;
																	break j;
																}
																f = y[b >> 2];
																g = y[b + 8 >> 2];
																if (g >>> 0 >= B[b + 4 >> 2]) {
																	break c;
																}
																g = z[f + g | 0];
																f = y[b + 12 >> 2];
																Tb(b);
																w[e + 64 | 0] = 0;
																y[e + 60 >> 2] = 0;
																if (g >>> 7 - f & 1) {
																	break i;
																}
															}
															Yc(e + 60 | 0, y[y[a + 124 >> 2] + (y[e + 68 >> 2] << 2) >> 2]);
															break h;
														}
														if (ya(j, y[a + 156 >> 2], e + 56 | 0)) {
															break d;
														}
														if (ya(j, y[a + 160 >> 2], e + 52 | 0)) {
															break d;
														}
														if (ya(j, y[a + 164 >> 2], e + 48 | 0)) {
															break d;
														}
														if (ya(j, y[a + 168 >> 2], e + 44 | 0)) {
															break d;
														}
														if (ya(j, y[a + 172 >> 2], e + 40 | 0)) {
															break d;
														}
														sa(b);
														k = y[y[a + 124 >> 2] + (y[e + 68 >> 2] << 2) >> 2];
														if (!k) {
															break d;
														}
														l = y[e + 56 >> 2];
														g = l >> 31;
														f = y[k + 20 >> 2] + l | 0;
														if (f >>> 0 < l >>> 0 ? g + 1 | 0 : g) {
															break d;
														}
														i = y[e + 52 >> 2];
														h = i >> 31;
														g = i + y[k + 24 >> 2] | 0;
														if (g >>> 0 < i >>> 0 ? h + 1 | 0 : h) {
															break d;
														}
														h = y[b + 8 >> 2];
														wb(e + 12 | 0, l, 2, y[e + 48 >> 2]);
														wb(e + 32 | 0, i, 2, y[e + 44 >> 2]);
														if (!(w[e + 36 | 0] & 1) | z[e + 16 | 0] != 1) {
															break d;
														}
														i = kb();
														y[e + 28 >> 2] = i;
														y[i + 8 >> 2] = g;
														y[i + 4 >> 2] = f;
														f = z[a + 2 | 0];
														y[i + 20 >> 2] = k;
														w[i | 0] = f;
														y[i + 12 >> 2] = y[e + 12 >> 2];
														f = y[e + 32 >> 2];
														g = 0;
														w[i + 1 | 0] = 0;
														y[i + 16 >> 2] = f;
														w[i + 24 | 0] = z[a + 176 | 0];
														w[i + 25 | 0] = z[a + 177 | 0];
														w[i + 26 | 0] = z[a + 178 | 0];
														w[i + 27 | 0] = z[a + 179 | 0];
														f = Na(b);
														y[e + 24 >> 2] = f;
														if (ac(Xc(e + 60 | 0, jb(i, f, c, d)))) {
															sa(b);
															g = y[b + 8 >> 2];
															if (g >>> 0 <= 4294967293) {
																g = g + 2 | 0;
																f = y[b + 4 >> 2];
																g = f >>> 0 > g >>> 0 ? g : f;
																y[b + 8 >> 2] = g;
															}
															g = y[e + 40 >> 2] == (g - h | 0);
														}
														ta(e + 24 | 0);
														Ua(e + 28 | 0);
														if (!g) {
															break d;
														}
													}
													f = e + 60 | 0;
													if (ac(f)) {
														k = y[Ta(f) + 20 >> 2];
														f = Ta(f);
														n = y[a + 140 >> 2];
														l = y[f + 24 >> 2];
														k: {
															l: {
																i = z[a + 3 | 0];
																if (!i) {
																	f = z[e + 72 | 0];
																	if ((n & -2) != 2) {
																		break l;
																	}
																	if (!(f & 1)) {
																		break d;
																	}
																	h = y[e + 76 >> 2];
																	g = h >> 31;
																	f = k - 1 | 0;
																	o = f;
																	f = f + h | 0;
																	g = o >>> 0 > f >>> 0 ? g + 1 | 0 : g;
																	h = f >>> 0 < 2147483648 & (g | 0) <= 0 | (g | 0) < 0;
																	y[e + 72 >> 2] = 0 | h;
																	y[e + 76 >> 2] = h ? f : 0;
																	if (!h) {
																		break d;
																	}
																	break k;
																}
																f = z[e + 72 | 0];
																m: {
																	switch (n | 0) {
																		default:
																			if (!(f & 1)) {
																				break d;
																			}
																			break k;
																		case 0:
																		case 2: break m;
																	}
																}
																if (!(f & 1)) {
																	break d;
																}
																h = y[e + 76 >> 2];
																g = h >> 31;
																f = l - 1 | 0;
																o = f;
																f = f + h | 0;
																g = o >>> 0 > f >>> 0 ? g + 1 | 0 : g;
																h = f >>> 0 < 2147483648 & (g | 0) <= 0 | (g | 0) < 0;
																y[e + 72 >> 2] = 0 | h;
																y[e + 76 >> 2] = h ? f : 0;
																if (h) {
																	break k;
																}
																break d;
															}
															if (!(f & 1)) {
																break d;
															}
														}
														f = y[e + 76 >> 2];
														Wc(e + 12 | 0, i, n, f, p, k, l);
														n = Ta(e + 60 | 0);
														g = y[e + 12 >> 2];
														o = g;
														p = g >> 31;
														g = y[e + 16 >> 2];
														Ab(n, m, o, p, g, g >> 31, y[a + 136 >> 2]);
														h = y[e + 20 >> 2];
														if (h) {
															g = f;
															f = f >> 31;
															g = g + h | 0;
															f = g >>> 0 < h >>> 0 ? f + 1 | 0 : f;
															h = g >>> 0 < 2147483648 & (f | 0) <= 0 | (f | 0) < 0;
															f = 0;
															y[e + 72 >> 2] = f | h;
															y[e + 76 >> 2] = h ? g : 0;
														}
														r = r + 1 | 0;
													}
													Xa(e + 60 | 0);
													g = 0;
													continue;
												}
											}
											break;
										}
										y[e + 124 >> 2] = 0;
										g = m;
										break b;
									}
									Xa(e + 60 | 0);
								}
								g = 0;
							}
							Ua(e + 116 | 0);
						}
						la(e + 124 | 0);
						Y = e + 128 | 0;
						return g;
					}
					function Ed(a, b, c, d, e) {
						var f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0, F = 0, G = 0;
						f = Y - 112 | 0;
						Y = f;
						m = ua(a + 8 | 0, a + 12 | 0);
						y[f + 108 >> 2] = m;
						a: {
							b: {
								if (!y[m + 16 >> 2]) {
									break b;
								}
								q = y[e >> 2];
								g = 0;
								if (!Aa(q, b, f + 104 | 0)) {
									break a;
								}
								t = y[e + 36 >> 2];
								u = y[e + 32 >> 2];
								v = y[e + 28 >> 2];
								x = y[e + 24 >> 2];
								A = y[e + 20 >> 2];
								C = y[e + 16 >> 2];
								D = y[e + 12 >> 2];
								E = y[e + 8 >> 2];
								F = y[e + 4 >> 2];
								Mb(y[m + 12 >> 2], y[m + 16 >> 2], z[a + 4 | 0]);
								y[f + 100 >> 2] = y[f + 104 >> 2];
								w[f + 96 | 0] = 1;
								r = xb(f + 96 | 0, y[a + 20 >> 2]);
								g = r;
								h = y[f + 100 >> 2];
								e = 0 - h | 0;
								y[g >> 2] = z[g | 0] & (h | 0) != -2147483648;
								y[g + 4 >> 2] = e;
								y[f + 92 >> 2] = 0;
								w[f + 88 | 0] = 1;
								c: {
									d: while (1) {
										if (B[a + 16 >> 2] > n >>> 0) {
											y[f + 84 >> 2] = 0;
											w[f + 80 | 0] = 1;
											if (!Aa(q, b, f + 76 | 0)) {
												break b;
											}
											y[f + 68 >> 2] = y[f + 76 >> 2];
											e = 1;
											w[f + 64 | 0] = 1;
											h = xb(f - -64 | 0, y[a + 20 >> 2]);
											g = Zc(r, y[h >> 2], y[h + 4 >> 2]);
											h = y[g >> 2];
											s = y[g + 4 >> 2];
											G = h & 1;
											while (1) {
												e: {
													if (e & 1) {
														Aa(F, b, f + 4 | 0);
														g = La(f + 88 | 0, y[f + 4 >> 2]);
														e = y[g + 4 >> 2];
														y[f + 80 >> 2] = y[g >> 2];
														y[f + 84 >> 2] = e;
														break e;
													}
													if (!Aa(E, b, f + 4 | 0)) {
														continue d;
													}
													La(La(f + 80 | 0, y[f + 4 >> 2]), w[a + 5 | 0]);
												}
												if (B[a + 16 >> 2] <= n >>> 0) {
													continue d;
												}
												y[f + 60 >> 2] = 0;
												if (y[a + 20 >> 2] != 1) {
													Aa(D, b, f + 60 | 0);
												}
												if (!G) {
													break b;
												}
												e = y[f + 60 >> 2];
												o = e + s | 0;
												if (((o ^ s) & (e ^ o)) < 0) {
													break b;
												}
												Ac(t, b, f + 56 | 0);
												g = y[f + 56 >> 2];
												if (g >>> 0 >= B[a + 24 >> 2]) {
													break b;
												}
												f: {
													g: {
														h: {
															if (!z[a + 1 | 0]) {
																y[f + 52 >> 2] = 0;
																w[f + 48 | 0] = 0;
																y[f + 44 >> 2] = 0;
																break h;
															}
															Aa(C, b, f + 52 | 0);
															e = y[f + 52 >> 2];
															w[f + 48 | 0] = 0;
															y[f + 44 >> 2] = 0;
															if (e) {
																break g;
															}
														}
														Yc(f + 44 | 0, y[y[a + 124 >> 2] + (g << 2) >> 2]);
														break f;
													}
													Aa(A, b, f + 40 | 0);
													Aa(x, b, f + 36 | 0);
													Aa(v, b, f + 32 | 0);
													Aa(u, b, f + 28 | 0);
													i = y[y[a + 124 >> 2] + (g << 2) >> 2];
													if (!i) {
														break c;
													}
													j = y[f + 40 >> 2];
													g = j >> 31;
													e = y[i + 20 >> 2] + j | 0;
													if (e >>> 0 < j >>> 0 ? g + 1 | 0 : g) {
														break c;
													}
													k = y[f + 36 >> 2];
													h = k >> 31;
													g = k + y[i + 24 >> 2] | 0;
													if (g >>> 0 < k >>> 0 ? h + 1 | 0 : h) {
														break c;
													}
													wb(f + 4 | 0, j, 1, y[f + 32 >> 2]);
													wb(f + 20 | 0, k, 1, y[f + 28 >> 2]);
													if (!(w[f + 24 | 0] & 1) | z[f + 8 | 0] != 1) {
														break c;
													}
													h = kb();
													y[f + 16 >> 2] = h;
													y[h + 8 >> 2] = g;
													y[h + 4 >> 2] = e;
													e = z[a + 2 | 0];
													y[h + 20 >> 2] = i;
													w[h | 0] = e;
													y[h + 12 >> 2] = y[f + 4 >> 2];
													e = y[f + 20 >> 2];
													w[h + 1 | 0] = 0;
													y[h + 16 >> 2] = e;
													w[h + 24 | 0] = z[a + 176 | 0];
													w[h + 25 | 0] = z[a + 177 | 0];
													w[h + 26 | 0] = z[a + 178 | 0];
													w[h + 27 | 0] = z[a + 179 | 0];
													Xc(f + 44 | 0, jb(h, b, c, d));
													Ua(f + 16 | 0);
												}
												e = f + 44 | 0;
												if (!ac(e)) {
													break c;
												}
												j = y[Ta(e) + 20 >> 2];
												e = Ta(e);
												p = y[a + 140 >> 2];
												i = y[e + 24 >> 2];
												i: {
													j: {
														k = z[a + 3 | 0];
														if (!k) {
															e = z[f + 80 | 0];
															if ((p & -2) != 2) {
																break j;
															}
															if (!(e & 1)) {
																break c;
															}
															h = y[f + 84 >> 2];
															e = h >> 31;
															g = j - 1 | 0;
															l = g;
															g = h + g | 0;
															e = l >>> 0 > g >>> 0 ? e + 1 | 0 : e;
															h = g >>> 0 < 2147483648 & (e | 0) <= 0 | (e | 0) < 0;
															y[f + 80 >> 2] = 0 | h;
															y[f + 84 >> 2] = h ? g : 0;
															if (!h) {
																break c;
															}
															break i;
														}
														e = z[f + 80 | 0];
														k: {
															switch (p | 0) {
																default:
																	if (!(e & 1)) {
																		break c;
																	}
																	break i;
																case 0:
																case 2: break k;
															}
														}
														if (!(e & 1)) {
															break c;
														}
														h = y[f + 84 >> 2];
														g = h >> 31;
														e = i - 1 | 0;
														l = e;
														e = e + h | 0;
														g = l >>> 0 > e >>> 0 ? g + 1 | 0 : g;
														h = e >>> 0 < 2147483648 & (g | 0) <= 0 | (g | 0) < 0;
														y[f + 80 >> 2] = 0 | h;
														y[f + 84 >> 2] = h ? e : 0;
														if (h) {
															break i;
														}
														break c;
													}
													if (!(e & 1)) {
														break c;
													}
												}
												h = y[f + 84 >> 2];
												Wc(f + 4 | 0, k, p, h, o, j, i);
												l = Ta(f + 44 | 0);
												e = y[f + 4 >> 2];
												g = e;
												i = e >> 31;
												e = y[f + 8 >> 2];
												Ab(l, m, g, i, e, e >> 31, y[a + 136 >> 2]);
												e = y[f + 12 >> 2];
												if (e) {
													g = h >> 31;
													l = e;
													e = e + h | 0;
													g = l >>> 0 > e >>> 0 ? g + 1 | 0 : g;
													h = e >>> 0 < 2147483648 & (g | 0) <= 0 | (g | 0) < 0;
													g = 0;
													y[f + 80 >> 2] = h | g;
													y[f + 84 >> 2] = h ? e : 0;
												}
												n = n + 1 | 0;
												Xa(f + 44 | 0);
												e = 0;
												continue;
											}
										}
										break;
									}
									y[f + 108 >> 2] = 0;
									g = m;
									break a;
								}
								Xa(f + 44 | 0);
							}
							g = 0;
						}
						la(f + 108 | 0);
						Y = f + 112 | 0;
						return g;
					}
					function he(a, b, c, d, e, f) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						f = f | 0;
						var g = 0, h = 0, i = 0, j = 0, k = 0, l = 0;
						g = Y - 96 | 0;
						Y = g;
						w[g + 72 | 0] = 0;
						y[g + 68 >> 2] = 0;
						i = c + 31 >>> 3 & 536870908;
						k = E(i, d);
						j = vd(k, 1);
						y[g + 76 >> 2] = 0;
						y[g >> 2] = j;
						h = g + 68 | 0;
						Uc(h);
						w[g + 72 | 0] = 1;
						y[g + 68 >> 2] = j;
						y[g >> 2] = 0;
						Ja(g);
						Ja(g + 76 | 0);
						a: {
							b: {
								if (!$b(h)) {
									break b;
								}
								j = $b(h);
								h = g + 56 | 0;
								y[g + 60 >> 2] = h;
								y[g + 56 >> 2] = h;
								y[g + 64 >> 2] = 0;
								y[g + 48 >> 2] = 0;
								y[g + 52 >> 2] = 0;
								h = a;
								a = 0;
								h = h | a;
								y[g + 32 >> 2] = h;
								y[g + 36 >> 2] = b;
								y[g >> 2] = c;
								l = a | e;
								y[g + 24 >> 2] = l;
								y[g + 28 >> 2] = f;
								y[g + 16 >> 2] = 0;
								y[g + 20 >> 2] = 0;
								y[g + 40 >> 2] = a | j;
								y[g + 44 >> 2] = k;
								y[g + 8 >> 2] = 0;
								y[g + 12 >> 2] = 0;
								y[g + 4 >> 2] = d;
								y[g + 48 >> 2] = i;
								a = ze(i, 0, d, 0);
								if (Z | a >>> 0 > k >>> 0) {
									break a;
								}
								e = j;
								while (1) {
									if ((a | 0) > 0) {
										w[e | 0] = 0;
										a = a - 1 | 0;
										e = e + 1 | 0;
										continue;
									}
									break;
								}
								a = b;
								b = g + 56 | 0;
								a = zc(na(116), h, a, b, 0);
								if (f) {
									b = zc(na(116), l, f, b, 1);
									y[g + 76 >> 2] = 0;
									rb(a, b);
									sb(g + 76 | 0);
								}
								f = c + 7 >>> 3 | 0;
								y[g + 76 >> 2] = 0;
								h = g + 52 | 0;
								rb(h, a);
								sb(g + 76 | 0);
								c: {
									d: {
										b = y[g + 52 >> 2];
										a = y[b >> 2];
										if (!a) {
											break d;
										}
										if (!yc(a)) {
											break d;
										}
										y[b + 56 >> 2] = -1;
										a = 0;
										break c;
									}
									y[b + 52 >> 2] = 0;
									e = na(32);
									a = e;
									y[a + 24 >> 2] = 0;
									y[a + 28 >> 2] = 0;
									y[a + 16 >> 2] = 0;
									y[a + 20 >> 2] = 0;
									y[a + 8 >> 2] = 0;
									y[a + 12 >> 2] = 0;
									y[a >> 2] = 0;
									y[a + 4 >> 2] = 0;
									e: {
										if ((c | d) < 0 | i >>> 0 > 268435452) {
											break e;
										}
										l = i << 3;
										if ((l | 0) < (c | 0) | (!(!i | (d | 0) <= 0 | k) | (2147483616 / (l >>> 0) | 0) < (d | 0))) {
											break e;
										}
										y[a + 28 >> 2] = i;
										y[a + 24 >> 2] = d;
										y[a + 20 >> 2] = c;
										a = ze(i, 0, d, d >> 31);
										c = Z;
										if ((c | 0) == 1 | c >>> 0 > 1 | a >>> 0 > k >>> 0) {
											break a;
										}
										y[g + 92 >> 2] = a;
										y[g + 88 >> 2] = j;
										y[g + 84 >> 2] = 0;
										y[g + 76 >> 2] = 0;
										y[g + 80 >> 2] = 0;
										a = g + 76 | 0;
										ec(e, a);
										va(a);
									}
									y[g + 76 >> 2] = 0;
									oa(b + 32 | 0, e);
									la(g + 76 | 0);
									w[b + 50 | 0] = 1;
									a = od(b);
								}
								f: {
									while (1) {
										g: {
											a = a & 1;
											h: {
												i: {
													b = y[y[g + 52 >> 2] + 56 >> 2];
													if ((b | 0) != 4) {
														break h;
													}
													rb(g + 52 | 0, 0);
													b = -1;
													if (!a) {
														break h;
													}
													b = E(y[g + 48 >> 2], y[g + 4 >> 2]);
													if (b >>> 0 > B[g + 44 >> 2]) {
														break i;
													}
													a = y[g + 40 >> 2];
													if (a & 3) {
														break i;
													}
													c = (b & -4) + a | 0;
													b = 4;
													while (1) {
														if ((a | 0) == (c | 0)) {
															break h;
														}
														y[a >> 2] = y[a >> 2] ^ -1;
														a = a + 4 | 0;
														continue;
													}
												}
												o();
											}
											j: {
												switch (b - 3 | 0) {
													case 0: break j;
													case 1: break g;
													default: break f;
												}
											}
											a = od(y[g + 52 >> 2]);
											continue;
										}
										break;
									}
									X($b(g + 68 | 0) | 0, f | 0, i | 0, d | 0);
								}
								sb(h);
								if (!y[g + 64 >> 2]) {
									break b;
								}
								a = y[g + 60 >> 2];
								b = y[a >> 2];
								c = y[y[g + 56 >> 2] + 4 >> 2];
								y[b + 4 >> 2] = c;
								y[c >> 2] = b;
								y[g + 64 >> 2] = 0;
								while (1) {
									if ((g + 56 | 0) == (a | 0)) {
										break b;
									}
									b = y[a + 4 >> 2];
									pc(a);
									a = b;
									continue;
								}
							}
							Uc(g + 68 | 0);
							Y = g + 96 | 0;
							return;
						}
						o();
					}
					function jc(a, b, c, d, e) {
						var f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0;
						a: {
							b: {
								c: {
									d: {
										if (!z[a + 1 | 0]) {
											g = y[a + 60 >> 2];
											break d;
										}
										f = y[b + 4 >> 2];
										if (z[f | 0]) {
											break a;
										}
										h = y[c >> 2];
										if (h >>> 0 >= B[b + 12 >> 2]) {
											break c;
										}
										g = y[a + 60 >> 2] ^ ka(f, y[b + 8 >> 2] + (h << 1) | 0);
										y[a + 60 >> 2] = g;
									}
									if (g) {
										ld(a, y[y[b >> 2] >> 2]);
										break b;
									}
									f = y[a + 24 >> 2];
									if (f >>> 0 <= 1) {
										if ((f | 0) == 1) {
											if (!y[a + 40 >> 2]) {
												break c;
											}
											j = z[y[a + 36 >> 2]];
										}
										i = y[c + 12 >> 2] & j >>> y[c + 8 >> 2];
										h = (f | 0) != 1;
										while (1) {
											if ((d | 0) != (k | 0)) {
												if (!h) {
													f = k + 1 | 0;
													if (f >>> 0 >= B[a + 40 >> 2]) {
														break c;
													}
													j = z[f + y[a + 36 >> 2] | 0] | j << 8;
												}
												g = 7;
												l = 0;
												while (1) {
													if ((g | 0) >= 0) {
														f = y[b + 4 >> 2];
														if (z[f | 0]) {
															break a;
														}
														if (B[b + 12 >> 2] <= i >>> 0) {
															break c;
														}
														f = ka(f, y[b + 8 >> 2] + (i << 1) | 0);
														i = f | (y[c + 16 >> 2] & j >>> y[c + 8 >> 2] + g | (y[c + 4 >> 2] & i) << 1);
														l = f << g | l;
														g = g - 1 | 0;
														continue;
													}
													break;
												}
												if (B[a + 48 >> 2] <= k >>> 0) {
													break c;
												}
												w[y[a + 44 >> 2] + k | 0] = l;
												k = k + 1 | 0;
												continue;
											}
											break;
										}
										f = j << 8;
										g = 0;
										l = 0;
										while (1) {
											if ((e | 0) != (g | 0)) {
												h = y[b + 4 >> 2];
												if (z[h | 0]) {
													break a;
												}
												if (B[b + 12 >> 2] <= i >>> 0) {
													break c;
												}
												h = ka(h, y[b + 8 >> 2] + (i << 1) | 0);
												j = 7 - g | 0;
												l = h << j | l;
												i = h | (y[c + 16 >> 2] & f >>> j + y[c + 8 >> 2] | (y[c + 4 >> 2] & i) << 1);
												g = g + 1 | 0;
												continue;
											}
											break;
										}
										if (B[a + 48 >> 2] <= d >>> 0) {
											break c;
										}
										w[y[a + 44 >> 2] + d | 0] = l;
										break b;
									}
									if (!y[a + 32 >> 2] | !y[a + 40 >> 2]) {
										break c;
									}
									j = z[y[a + 36 >> 2]];
									k = z[y[a + 28 >> 2]] << y[c + 20 >> 2];
									i = y[c + 12 >> 2] & j >>> y[c + 8 >> 2] | k & y[c + 24 >> 2];
									f = 0;
									while (1) {
										e: {
											if ((d | 0) != (f | 0)) {
												h = f + 1 | 0;
												if (h >>> 0 >= B[a + 32 >> 2] | h >>> 0 >= B[a + 40 >> 2]) {
													break c;
												}
												k = z[h + y[a + 28 >> 2] | 0] << y[c + 20 >> 2] | k << 8;
												j = z[h + y[a + 36 >> 2] | 0] | j << 8;
												g = 7;
												l = 0;
												while (1) {
													if ((g | 0) < 0) {
														break e;
													}
													m = y[b + 4 >> 2];
													if (z[m | 0]) {
														break a;
													}
													if (B[b + 12 >> 2] <= i >>> 0) {
														break c;
													}
													m = ka(m, y[b + 8 >> 2] + (i << 1) | 0);
													i = m | (y[c + 16 >> 2] & j >>> y[c + 8 >> 2] + g | (y[c + 28 >> 2] & k >>> g | (y[c + 4 >> 2] & i) << 1));
													l = m << g | l;
													g = g - 1 | 0;
													continue;
												}
											}
											l = j << 8;
											j = k << 8;
											g = 0;
											f = 0;
											while (1) {
												if ((e | 0) != (g | 0)) {
													h = y[b + 4 >> 2];
													if (z[h | 0]) {
														break a;
													}
													if (B[b + 12 >> 2] <= i >>> 0) {
														break c;
													}
													k = ka(h, y[b + 8 >> 2] + (i << 1) | 0);
													h = 7 - g | 0;
													f = k << h | f;
													i = k | (y[c + 16 >> 2] & l >>> h + y[c + 8 >> 2] | (y[c + 28 >> 2] & j >>> h | (y[c + 4 >> 2] & i) << 1));
													g = g + 1 | 0;
													continue;
												}
												break;
											}
											if (B[a + 48 >> 2] <= d >>> 0) {
												break c;
											}
											w[y[a + 44 >> 2] + d | 0] = f;
											break b;
										}
										if (B[a + 48 >> 2] <= f >>> 0) {
											break c;
										}
										w[y[a + 44 >> 2] + f | 0] = l;
										f = h;
										continue;
									}
								}
								o();
							}
							return 1;
						}
						return 0;
					}
					function we(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, I = 0, J = 0, K = 0, L = 0, M = 0;
						c = Y - 48 | 0;
						Y = c;
						m = y[b + 4 >> 2];
						t = y[b + 12 >> 2];
						u = y[b + 8 >> 2];
						h = y[y[b >> 2] >> 2];
						d = y[a + 24 >> 2];
						ja(c + 40 | 0, h, d - 1 | 0);
						ja(c + 32 | 0, h, d - 2 | 0);
						A = u + 79434 | 0;
						n = y[c + 36 >> 2];
						p = y[c + 32 >> 2];
						C = t >>> 0 > 39717;
						q = 4;
						a: {
							while (1) {
								b: {
									c: {
										if (B[a + 8 >> 2] > d >>> 0) {
											j = y[c + 44 >> 2];
											k = y[c + 40 >> 2];
											ja(c + 32 | 0, h, d);
											f = y[c + 36 >> 2];
											r = y[c + 32 >> 2];
											y[c + 40 >> 2] = r;
											y[c + 44 >> 2] = f;
											d: {
												e: {
													f: {
														if (!z[a + 1 | 0]) {
															d = y[a + 60 >> 2];
															break f;
														}
														if (z[m | 0]) {
															break b;
														}
														if (!C) {
															break e;
														}
														d = y[a + 60 >> 2] ^ ka(m, A);
														y[a + 60 >> 2] = d;
													}
													if (d) {
														y[c + 20 >> 2] = j;
														y[c + 16 >> 2] = k;
														y[c + 24 >> 2] = r;
														y[c + 28 >> 2] = f;
														y[c + 8 >> 2] = r;
														y[c + 12 >> 2] = f;
														f = y[c + 20 >> 2];
														y[c >> 2] = y[c + 16 >> 2];
														y[c + 4 >> 2] = f;
														Ca(c + 8 | 0, c);
														break d;
													}
													d = y[a + 24 >> 2];
													i = 0;
													v = 0;
													x = 0;
													if (z[a + 2 | 0] == 1) {
														ja(c + 32 | 0, y[a + 12 >> 2], d);
														x = y[c + 32 >> 2];
														v = y[c + 36 >> 2];
													}
													e = c + 32 | 0;
													ja(e, h, d + w[a + 17 | 0] | 0);
													D = y[c + 36 >> 2];
													E = y[c + 32 >> 2];
													ja(e, h, d + w[a + 19 | 0] | 0);
													F = y[c + 36 >> 2];
													G = y[c + 32 >> 2];
													ja(e, h, d + w[a + 21 | 0] | 0);
													H = y[c + 36 >> 2];
													I = y[c + 32 >> 2];
													ja(e, h, d + w[a + 23 | 0] | 0);
													J = y[c + 36 >> 2];
													K = y[c + 32 >> 2];
													e = y[h + 20 >> 2];
													i = !n | (e | 0) < 2 ? i : z[p | 0] >>> 6 & 1;
													i = !n | (e | 0) <= 0 ? i : z[p | 0] >>> 6 & 2 | i;
													g = 0;
													g = !j | (e | 0) < 3 ? g : z[k | 0] >>> 5 & 1;
													g = !j | (e | 0) < 2 ? g : z[k | 0] >>> 5 & 2 | g;
													g = !j | (e | 0) <= 0 ? g : z[k | 0] >>> 5 & 4 | g;
													s = 0;
													d = 0;
													while (1) {
														if (B[a + 4 >> 2] <= d >>> 0) {
															break d;
														}
														g: {
															h: {
																if (z[a + 2 | 0] == 1) {
																	if (ia(y[y[a + 12 >> 2] + 20 >> 2], d, x, v)) {
																		break h;
																	}
																}
																l = ia(e, w[a + 16 | 0] + d | 0, E, D);
																L = ia(e, w[a + 18 | 0] + d | 0, G, F);
																M = ia(e, w[a + 20 | 0] + d | 0, I, H);
																e = ia(e, w[a + 22 | 0] + d | 0, K, J);
																if (z[m | 0]) {
																	break b;
																}
																e = g << 5 | i << 12 | l << 4 | L << 10 | M << 11 | e << 15 | s;
																if (e >>> 0 >= t >>> 0) {
																	break e;
																}
																l = ka(m, (e << 1) + u | 0);
																e = y[h + 20 >> 2];
																if (!l) {
																	break h;
																}
																Ea(e, d, r, f, 1);
																e = y[h + 20 >> 2];
																l = 1;
																break g;
															}
															l = 0;
														}
														i = ia(e, d + 2 | 0, p, n) | i << 1 & 6;
														g = ia(e, d + 3 | 0, k, j) | g << 1 & 30;
														d = d + 1 | 0;
														s = s << 1 & 14 | l;
														continue;
													}
												}
												o();
											}
											f = y[b + 16 >> 2];
											if (!f) {
												d = y[a + 24 >> 2];
												break c;
											}
											f = _[y[y[f >> 2] + 8 >> 2]](f) | 0;
											d = y[a + 24 >> 2];
											if (!f) {
												break c;
											}
											y[a + 24 >> 2] = d + 1;
											q = 3;
										}
										y[a + 52 >> 2] = q;
										break a;
									}
									d = d + 1 | 0;
									y[a + 24 >> 2] = d;
									p = k;
									n = j;
									continue;
								}
								break;
							}
							q = -1;
						}
						Y = c + 48 | 0;
						return q | 0;
					}
					function re(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0;
						i = y[b + 4 >> 2];
						k = y[b + 12 >> 2];
						l = y[b + 8 >> 2];
						m = y[y[b >> 2] >> 2];
						if (!y[a + 48 >> 2]) {
							c = y[m + 16 >> 2];
							y[a + 44 >> 2] = y[m + 12 >> 2];
							y[a + 48 >> 2] = c;
						}
						a: {
							b: {
								c = y[a + 4 >> 2];
								if (!c) {
									break b;
								}
								q = l + 810 | 0;
								c = c - 1 | 0;
								j = c >>> 3 | 0;
								n = (c & 7) + 1 | 0;
								d = y[a + 24 >> 2];
								r = k >>> 0 > 405;
								while (1) {
									c: {
										if (B[a + 8 >> 2] <= d >>> 0) {
											b = 4;
										} else {
											d: {
												if (!z[a + 1 | 0]) {
													d = y[a + 60 >> 2];
													break d;
												}
												if (z[i | 0]) {
													break a;
												}
												if (!r) {
													break b;
												}
												d = y[a + 60 >> 2] ^ ka(i, q);
												y[a + 60 >> 2] = d;
											}
											e: {
												if (d) {
													ld(a, m);
													break e;
												}
												d = 0;
												g = 0;
												f: {
													if (!y[a + 24 >> 2]) {
														g: {
															while (1) {
																e = 7;
																f = 0;
																if ((g | 0) == (j | 0)) {
																	break g;
																}
																h: {
																	while (1) {
																		if ((e | 0) >= 0) {
																			if (z[i | 0]) {
																				break h;
																			}
																			if (d >>> 0 >= k >>> 0) {
																				break b;
																			}
																			h = d << 1;
																			c = ka(i, h + l | 0);
																			d = c | h & 1006;
																			f = c << e | f;
																			e = e - 1 | 0;
																			continue;
																		}
																		break;
																	}
																	if (B[a + 48 >> 2] <= g >>> 0) {
																		break b;
																	}
																	w[y[a + 44 >> 2] + g | 0] = f;
																	g = g + 1 | 0;
																	continue;
																}
																break;
															}
															if (g >>> 0 < j >>> 0) {
																break a;
															}
														}
														e = 0;
														f = 0;
														while (1) {
															if ((e | 0) == (n | 0)) {
																break f;
															}
															if (z[i | 0]) {
																break a;
															}
															if (d >>> 0 >= k >>> 0) {
																break b;
															}
															h = d << 1;
															c = ka(i, h + l | 0);
															d = c | h & 1006;
															f = c << 7 - e | f;
															e = e + 1 | 0;
															continue;
														}
													}
													if (!y[a + 40 >> 2]) {
														break b;
													}
													g = z[y[a + 36 >> 2]];
													e = g >>> 1 & 112;
													c = 0;
													while (1) {
														i: {
															if ((c | 0) != (j | 0)) {
																h = c + 1 | 0;
																if (h >>> 0 >= B[a + 40 >> 2]) {
																	break b;
																}
																g = z[h + y[a + 36 >> 2] | 0] | g << 8;
																d = 7;
																f = 0;
																while (1) {
																	if ((d | 0) < 0) {
																		break i;
																	}
																	if (z[i | 0]) {
																		break a;
																	}
																	if (e >>> 0 >= k >>> 0) {
																		break b;
																	}
																	e = e << 1;
																	p = ka(i, e + l | 0);
																	e = p | (g >>> d + 1 & 16 | e & 1006);
																	f = p << d | f;
																	d = d - 1 | 0;
																	continue;
																}
															}
															h = g << 8;
															d = 0;
															f = 0;
															while (1) {
																if ((d | 0) != (n | 0)) {
																	if (z[i | 0]) {
																		break a;
																	}
																	if (e >>> 0 >= k >>> 0) {
																		break b;
																	}
																	e = e << 1;
																	c = ka(i, e + l | 0);
																	e = c | (h >>> 8 - d & 16 | e & 1006);
																	f = c << 7 - d | f;
																	d = d + 1 | 0;
																	continue;
																}
																break;
															}
															if (B[a + 48 >> 2] <= j >>> 0) {
																break b;
															}
															w[y[a + 44 >> 2] + j | 0] = f;
															break e;
														}
														if (B[a + 48 >> 2] <= c >>> 0) {
															break b;
														}
														w[y[a + 44 >> 2] + c | 0] = f;
														c = h;
														continue;
													}
												}
												if (B[a + 48 >> 2] <= j >>> 0) {
													break b;
												}
												w[y[a + 44 >> 2] + j | 0] = f;
											}
											Db(a, m);
											c = y[b + 16 >> 2];
											if (!c) {
												break c;
											}
											if (!(_[y[y[c >> 2] + 8 >> 2]](c) | 0)) {
												break c;
											}
											y[a + 24 >> 2] = y[a + 24 >> 2] + 1;
											b = 3;
										}
										y[a + 52 >> 2] = b;
										return b | 0;
									}
									d = y[a + 24 >> 2] + 1 | 0;
									y[a + 24 >> 2] = d;
									continue;
								}
							}
							o();
						}
						return -1;
					}
					function hb(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0;
						a: {
							b: {
								while (1) {
									if (a >>> 0 > 4294967239) {
										break b;
									}
									b = y[1691];
									c = b;
									f = y[1690];
									a = a >>> 0 <= 8 ? 8 : a + 3 & -4;
									c: {
										if (a >>> 0 <= 127) {
											d = (a >>> 3 | 0) - 1 | 0;
											break c;
										}
										e = H(a);
										d = ((a >>> 29 - e ^ 4) - (e << 2) | 0) + 110 | 0;
										if (a >>> 0 <= 4095) {
											break c;
										}
										e = ((a >>> 30 - e ^ 2) - (e << 1) | 0) + 71 | 0;
										d = e >>> 0 >= 63 ? 63 : e;
									}
									g = d;
									d = g & 31;
									if ((g & 63) >>> 0 >= 32) {
										e = 0;
										b = b >>> d | 0;
									} else {
										e = b >>> d | 0;
										b = ((1 << d) - 1 & b) << 32 - d | f >>> d;
									}
									if (b | e) {
										while (1) {
											d = e;
											d: {
												if (d | b) {
													c = d - 1 | 0;
													e = c + 1 | 0;
													f = c;
													c = b - 1 | 0;
													f = (c | 0) != -1 ? e : f;
													e = H(d ^ f);
													e = (e | 0) == 32 ? H(b ^ c) + 32 | 0 : e;
													c = 63 - e | 0;
													Z = 0 - (e >>> 0 > 63) | 0;
													break d;
												}
												Z = 0;
												c = 64;
											}
											f = c;
											c = f & 31;
											if ((f & 63) >>> 0 >= 32) {
												e = 0;
												h = d >>> c | 0;
											} else {
												e = d >>> c | 0;
												h = ((1 << c) - 1 & d) << 32 - c | b >>> c;
											}
											g = f + g | 0;
											b = g << 4;
											d = y[b + 5736 >> 2];
											c = b + 5728 | 0;
											e: {
												if ((d | 0) != (c | 0)) {
													b = _b(d, a);
													if (b) {
														break a;
													}
													b = y[d + 4 >> 2];
													f = y[d + 8 >> 2];
													y[b + 8 >> 2] = f;
													y[f + 4 >> 2] = b;
													y[d + 8 >> 2] = c;
													y[d + 4 >> 2] = y[c + 4 >> 2];
													y[c + 4 >> 2] = d;
													y[y[d + 4 >> 2] + 8 >> 2] = d;
													g = g + 1 | 0;
													b = (e & 1) << 31 | h >>> 1;
													e = e >>> 1 | 0;
													break e;
												}
												j = y[1691];
												f = g & 63;
												b = f;
												d = b & 31;
												if (b >>> 0 >= 32) {
													b = 0;
													c = -1 >>> d | 0;
												} else {
													b = -1 >>> d | 0;
													c = b | (1 << d) - 1 << 32 - d;
												}
												c = c & -2;
												d = f & 31;
												if (f >>> 0 >= 32) {
													b = c << d;
													i = 0;
												} else {
													b = (1 << d) - 1 & c >>> 32 - d | b << d;
													i = c << d;
												}
												d = b;
												f = 0 - g & 63;
												c = f;
												b = c & 31;
												if (c >>> 0 >= 32) {
													b = -1 << b;
													c = 0;
												} else {
													c = -1 << b;
													b = c | (1 << b) - 1 & -1 >>> 32 - b;
												}
												k = c & -2;
												c = f & 31;
												if (f >>> 0 >= 32) {
													f = 0;
													c = b >>> c | 0;
												} else {
													f = b >>> c | 0;
													c = ((1 << c) - 1 & b) << 32 - c | k >>> c;
												}
												b = c | i;
												Z = d | f;
												y[1690] = y[1690] & b;
												y[1691] = Z & j;
												b = h ^ 1;
											}
											if (b | e) {
												continue;
											}
											break;
										}
										f = y[1690];
										c = y[1691];
									}
									e = H(c);
									d = 63 - ((e | 0) == 32 ? H(f) + 32 | 0 : e) | 0;
									f: {
										if (!(c | f)) {
											g = 0;
											break f;
										}
										b = d << 4;
										g = y[b + 5736 >> 2];
										if (!c & f >>> 0 < 1073741824) {
											break f;
										}
										e = 98;
										c = b + 5728 | 0;
										if ((c | 0) == (g | 0)) {
											break f;
										}
										while (1) {
											b = _b(g, a);
											if (b) {
												break a;
											}
											g = y[g + 8 >> 2];
											if ((c | 0) == (g | 0)) {
												break f;
											}
											b = e;
											e = b - 1 | 0;
											if (b) {
												continue;
											}
											break;
										}
									}
									if (Md(a + 48 | 0)) {
										continue;
									}
									break;
								}
								if (!g) {
									break b;
								}
								e = (d << 4) + 5728 | 0;
								if ((e | 0) == (g | 0)) {
									break b;
								}
								while (1) {
									b = _b(g, a);
									if (b) {
										break a;
									}
									g = y[g + 8 >> 2];
									if ((e | 0) != (g | 0)) {
										continue;
									}
									break;
								}
							}
							b = 0;
						}
						return b;
					}
					function nb(a, b, c, d, e) {
						var f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, w = 0, x = 0;
						g = Y - 32 | 0;
						Y = g;
						a: {
							i = hc(d, e);
							if (!y[i + 16 >> 2] | (b | 0) < 0 | (!y[a + 16 >> 2] | (c | 0) < 0) | y[a + 20 >> 2] <= (b | 0)) {
								break a;
							}
							f = y[a + 24 >> 2];
							if ((f | 0) <= (c | 0)) {
								break a;
							}
							b: {
								if (!(b & 7)) {
									e = y[a + 28 >> 2];
									d = b >>> 3 | 0;
									if (e >>> 0 <= d >>> 0) {
										break b;
									}
									b = e - d | 0;
									e = y[i + 28 >> 2];
									h = b >>> 0 < e >>> 0 ? b : e;
									if (!h) {
										break b;
									}
									e = 0;
									b = f - c | 0;
									f = y[i + 24 >> 2];
									b = (b | 0) < (f | 0) ? b : f;
									k = (b | 0) > 0 ? b : 0;
									while (1) {
										if ((e | 0) == (k | 0)) {
											break a;
										}
										dc(g + 24 | 0, a, c + e | 0);
										f = 0;
										b = 0;
										if (z[g + 28 | 0] == 1) {
											j = y[a + 16 >> 2];
											b = y[g + 24 >> 2];
											if (j >>> 0 < b >>> 0) {
												break b;
											}
											f = y[a + 28 >> 2];
											if (f >>> 0 > j - b >>> 0) {
												break b;
											}
											b = b + y[a + 12 >> 2] | 0;
										}
										if (d >>> 0 > f >>> 0 | h >>> 0 > f - d >>> 0) {
											break b;
										}
										ja(g + 16 | 0, i, e);
										if (h >>> 0 > B[g + 20 >> 2]) {
											break b;
										}
										if (h) {
											p(y[g + 16 >> 2], b + d | 0, h);
										}
										e = e + 1 | 0;
										continue;
									}
								}
								d = y[a + 28 >> 2] / 4 | 0;
								j = b >>> 5 | 0;
								if (d >>> 0 <= j >>> 0) {
									break b;
								}
								n = d - j | 0;
								d = y[i + 28 >> 2] / 4 | 0;
								l = d >>> 0 > n >>> 0 ? n : d;
								if (!l) {
									break b;
								}
								e = c;
								c = f - c | 0;
								d = y[i + 24 >> 2];
								c = (c | 0) < (d | 0) ? c : d;
								ad(g + 24 | 0, a, e, c);
								cc(g + 16 | 0, i, 0, c);
								h = y[g + 20 >> 2];
								if (!h) {
									break b;
								}
								t = b & 31;
								k = y[g + 28 >> 2];
								u = j << 2;
								v = b ^ -1;
								c: while (1) {
									if (!h) {
										break a;
									}
									if (k >>> 0 < j >>> 0 | k - j >>> 0 < n >>> 0) {
										break b;
									}
									y[g + 12 >> 2] = n;
									r = y[g + 24 >> 2];
									y[g + 8 >> 2] = r + u;
									if (h >>> 0 < l >>> 0) {
										break b;
									}
									c = y[g + 16 >> 2];
									e = Ya(g + 8 | 0);
									d = y[g + 8 >> 2];
									q = y[g + 12 >> 2];
									f = l >>> 0 > q >>> 0 ? q : l;
									if (f >>> 0 > B[g + 12 >> 2]) {
										break b;
									}
									s = c + (f << 2) | 0;
									f = ((Ae(e, 16) ^ e) & -16711936) >>> 8 ^ Ae(e, 8);
									e = c;
									while (1) if ((e | 0) == (s | 0)) {
										if (l >>> 0 > q >>> 0) {
											d = f << t;
											w = s, x = ((Ae(d, 16) ^ d) & -16711936) >>> 8 ^ Ae(d, 8), y[w >> 2] = x;
										}
										d = y[a + 28 >> 2] / 4 | 0;
										if (d >>> 0 > k >>> 0) {
											break b;
										}
										y[g + 24 >> 2] = (d << 2) + r;
										e = y[i + 28 >> 2] / 4 | 0;
										if (e >>> 0 > h >>> 0) {
											break b;
										}
										y[g + 16 >> 2] = c + (e << 2);
										h = h - e | 0;
										k = k - d | 0;
										continue c;
									} else {
										m = f << b;
										f = y[d >> 2];
										f = ((Ae(f, 16) ^ f) & -16711936) >>> 8 ^ Ae(f, 8);
										m = m | f >>> 1 >>> v;
										w = e, x = ((m ^ Ae(m, 16)) & -16711936) >>> 8 ^ Ae(m, 8), y[w >> 2] = x;
										d = d + 4 | 0;
										e = e + 4 | 0;
										continue;
									}
								}
							}
							o();
						}
						Y = g + 32 | 0;
						return i;
					}
					function ue(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0, F = 0;
						c = Y - 48 | 0;
						Y = c;
						n = y[b + 4 >> 2];
						t = y[b + 12 >> 2];
						u = y[b + 8 >> 2];
						i = y[y[b >> 2] >> 2];
						d = y[a + 24 >> 2];
						ja(c + 40 | 0, i, d - 1 | 0);
						ja(c + 32 | 0, i, d - 2 | 0);
						C = u + 3882 | 0;
						l = y[c + 36 >> 2];
						m = y[c + 32 >> 2];
						D = t >>> 0 > 1941;
						p = 4;
						a: {
							while (1) {
								b: {
									c: {
										if (B[a + 8 >> 2] > d >>> 0) {
											j = y[c + 44 >> 2];
											k = y[c + 40 >> 2];
											ja(c + 32 | 0, i, d);
											f = y[c + 36 >> 2];
											q = y[c + 32 >> 2];
											y[c + 40 >> 2] = q;
											y[c + 44 >> 2] = f;
											d: {
												e: {
													f: {
														if (!z[a + 1 | 0]) {
															d = y[a + 60 >> 2];
															break f;
														}
														if (z[n | 0]) {
															break b;
														}
														if (!D) {
															break e;
														}
														d = y[a + 60 >> 2] ^ ka(n, C);
														y[a + 60 >> 2] = d;
													}
													if (d) {
														y[c + 20 >> 2] = j;
														y[c + 16 >> 2] = k;
														y[c + 24 >> 2] = q;
														y[c + 28 >> 2] = f;
														y[c + 8 >> 2] = q;
														y[c + 12 >> 2] = f;
														f = y[c + 20 >> 2];
														y[c >> 2] = y[c + 16 >> 2];
														y[c + 4 >> 2] = f;
														Ca(c + 8 | 0, c);
														break d;
													}
													d = y[a + 24 >> 2];
													g = 0;
													v = 0;
													x = 0;
													if (z[a + 2 | 0] == 1) {
														ja(c + 32 | 0, y[a + 12 >> 2], d);
														x = y[c + 32 >> 2];
														v = y[c + 36 >> 2];
													}
													ja(c + 32 | 0, i, d + w[a + 17 | 0] | 0);
													E = y[c + 36 >> 2];
													F = y[c + 32 >> 2];
													e = y[i + 20 >> 2];
													g = !l | (e | 0) < 3 ? g : z[m | 0] >>> 5 & 1;
													g = !l | (e | 0) < 2 ? g : z[m | 0] >>> 5 & 2 | g;
													g = !l | (e | 0) <= 0 ? g : z[m | 0] >>> 5 & 4 | g;
													h = 0;
													h = !j | (e | 0) < 3 ? h : z[k | 0] >>> 5 & 1;
													h = !j | (e | 0) < 2 ? h : z[k | 0] >>> 5 & 2 | h;
													h = !j | (e | 0) <= 0 ? h : z[k | 0] >>> 5 & 4 | h;
													s = 0;
													d = 0;
													while (1) {
														if (B[a + 4 >> 2] <= d >>> 0) {
															break d;
														}
														g: {
															h: {
																if (z[a + 2 | 0] == 1) {
																	if (ia(y[y[a + 12 >> 2] + 20 >> 2], d, x, v)) {
																		break h;
																	}
																}
																e = ia(e, w[a + 16 | 0] + d | 0, F, E);
																if (z[n | 0]) {
																	break b;
																}
																e = h << 4 | g << 9 | e << 3 | s;
																if (e >>> 0 >= t >>> 0) {
																	break e;
																}
																r = ka(n, (e << 1) + u | 0);
																e = y[i + 20 >> 2];
																if (!r) {
																	break h;
																}
																Ea(e, d, q, f, 1);
																e = y[i + 20 >> 2];
																r = 1;
																break g;
															}
															r = 0;
														}
														A = d + 3 | 0;
														g = ia(e, A, m, l) | g << 1 & 14;
														h = ia(e, A, k, j) | h << 1 & 30;
														d = d + 1 | 0;
														s = s << 1 & 6 | r;
														continue;
													}
												}
												o();
											}
											f = y[b + 16 >> 2];
											if (!f) {
												d = y[a + 24 >> 2];
												break c;
											}
											f = _[y[y[f >> 2] + 8 >> 2]](f) | 0;
											d = y[a + 24 >> 2];
											if (!f) {
												break c;
											}
											y[a + 24 >> 2] = d + 1;
											p = 3;
										}
										y[a + 52 >> 2] = p;
										break a;
									}
									d = d + 1 | 0;
									y[a + 24 >> 2] = d;
									m = k;
									l = j;
									continue;
								}
								break;
							}
							p = -1;
						}
						Y = c + 48 | 0;
						return p | 0;
					}
					function Sd(a, b) {
						a = a | 0;
						b = +b;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, q = 0, r = 0, s = 0;
						c = a << 3;
						o = c + 6784 | 0;
						j = D[c + 6816 >> 3];
						if (j != 0) {
							l = D[o >> 3];
							m = J(l, b);
							b = m - l;
							d = ~~b >>> 0;
							if (G(b) >= 1) {
								c = ~~(b > 0 ? I(K(b * 23283064365386963e-26), 4294967295) : L((b - +(~~b >>> 0 >>> 0)) * 23283064365386963e-26)) >>> 0;
							} else {
								c = 0;
							}
							h = ~~j >>> 0;
							if (G(j) >= 1) {
								f = ~~(j > 0 ? I(K(j * 23283064365386963e-26), 4294967295) : L((j - +(~~j >>> 0 >>> 0)) * 23283064365386963e-26)) >>> 0;
							} else {
								f = 0;
							}
							a: {
								b: {
									c: {
										d: {
											e: {
												f: {
													g: {
														h: {
															i: {
																j: {
																	k: {
																		if (c) {
																			if (!h) {
																				break k;
																			}
																			if (!f) {
																				break j;
																			}
																			e = H(f) - H(c) | 0;
																			if (e >>> 0 <= 31) {
																				break i;
																			}
																			break c;
																		}
																		if ((f | 0) == 1 | f >>> 0 > 1) {
																			break c;
																		}
																		Z = 0;
																		c = (d >>> 0) / (h >>> 0) | 0;
																		break a;
																	}
																	if (!d) {
																		break h;
																	}
																	if (!f | f - 1 & f) {
																		break g;
																	}
																	c = c >>> Be(f) | 0;
																	Z = 0;
																	break a;
																}
																if (!(h - 1 & h)) {
																	break f;
																}
																k = (H(h) + 33 | 0) - H(c) | 0;
																i = 0 - k | 0;
																break d;
															}
															k = e + 1 | 0;
															i = 63 - e | 0;
															break d;
														}
														Z = 0;
														c = (c >>> 0) / (f >>> 0) | 0;
														break a;
													}
													e = H(f) - H(c) | 0;
													if (e >>> 0 < 31) {
														break e;
													}
													break c;
												}
												if ((h | 0) == 1) {
													break b;
												}
												h = Be(h);
												f = h & 31;
												if ((h & 63) >>> 0 >= 32) {
													c = c >>> f | 0;
												} else {
													e = c >>> f | 0;
													c = ((1 << f) - 1 & c) << 32 - f | d >>> f;
												}
												Z = e;
												break a;
											}
											k = e + 1 | 0;
											i = 63 - e | 0;
										}
										e = k & 63;
										g = e & 31;
										if (e >>> 0 >= 32) {
											e = 0;
											n = c >>> g | 0;
										} else {
											e = c >>> g | 0;
											n = ((1 << g) - 1 & c) << 32 - g | d >>> g;
										}
										i = i & 63;
										g = i & 31;
										if (i >>> 0 >= 32) {
											c = d << g;
											d = 0;
										} else {
											c = (1 << g) - 1 & d >>> 32 - g | c << g;
											d = d << g;
										}
										if (k) {
											g = f - 1 | 0;
											i = h - 1 | 0;
											s = (i | 0) != -1 ? g + 1 | 0 : g;
											while (1) {
												p = e << 1 | n >>> 31;
												e = n << 1 | c >>> 31;
												g = s - (p + (e >>> 0 > i >>> 0) | 0) >> 31;
												q = g & h;
												n = e - q | 0;
												e = p - ((f & g) + (e >>> 0 < q >>> 0) | 0) | 0;
												c = c << 1 | d >>> 31;
												d = r | d << 1;
												r = g & 1;
												k = k - 1 | 0;
												if (k) {
													continue;
												}
												break;
											}
										}
										Z = c << 1 | d >>> 31;
										c = r | d << 1;
										break a;
									}
									d = 0;
									c = 0;
								}
								Z = c;
								c = d;
							}
							d = Z;
							c = c + 1 | 0;
							d = c ? d : d + 1 | 0;
							l = (+(c >>> 0) + +(d >>> 0) * 4294967296) * j + l;
							m = l - m;
						}
						D[o >> 3] = l;
						Q(a | 0, +m) | 0;
						a = (a | 0) == 2 ? 27 : (a | 0) == 1 ? 26 : 14;
						c = a - 1 | 0;
						l: {
							if (y[1692] >>> c & 1) {
								y[1694] = y[1694] | 1 << c;
								break l;
							}
							c = y[(a << 2) + 4608 >> 2];
							if (c) {
								_[c | 0](a);
							}
						}
					}
					function se(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0, C = 0, D = 0, E = 0;
						c = Y - 48 | 0;
						Y = c;
						l = y[b + 4 >> 2];
						s = y[b + 12 >> 2];
						t = y[b + 8 >> 2];
						i = y[y[b >> 2] >> 2];
						d = y[a + 24 >> 2];
						ja(c + 40 | 0, i, d - 1 | 0);
						ja(c + 32 | 0, i, d - 2 | 0);
						A = t + 458 | 0;
						m = y[c + 36 >> 2];
						n = y[c + 32 >> 2];
						C = s >>> 0 > 229;
						a: {
							while (1) {
								b: {
									c: {
										if (B[a + 8 >> 2] <= d >>> 0) {
											d = 4;
										} else {
											j = y[c + 44 >> 2];
											k = y[c + 40 >> 2];
											ja(c + 32 | 0, i, d);
											f = y[c + 36 >> 2];
											p = y[c + 32 >> 2];
											y[c + 40 >> 2] = p;
											y[c + 44 >> 2] = f;
											d: {
												e: {
													f: {
														if (!z[a + 1 | 0]) {
															d = y[a + 60 >> 2];
															break f;
														}
														if (z[l | 0]) {
															break b;
														}
														if (!C) {
															break e;
														}
														d = y[a + 60 >> 2] ^ ka(l, A);
														y[a + 60 >> 2] = d;
													}
													if (d) {
														y[c + 20 >> 2] = j;
														y[c + 16 >> 2] = k;
														y[c + 24 >> 2] = p;
														y[c + 28 >> 2] = f;
														y[c + 8 >> 2] = p;
														y[c + 12 >> 2] = f;
														f = y[c + 20 >> 2];
														y[c >> 2] = y[c + 16 >> 2];
														y[c + 4 >> 2] = f;
														Ca(c + 8 | 0, c);
														break d;
													}
													d = y[a + 24 >> 2];
													g = 0;
													u = 0;
													v = 0;
													if (z[a + 2 | 0] == 1) {
														ja(c + 32 | 0, y[a + 12 >> 2], d);
														v = y[c + 32 >> 2];
														u = y[c + 36 >> 2];
													}
													ja(c + 32 | 0, i, d + w[a + 17 | 0] | 0);
													D = y[c + 36 >> 2];
													E = y[c + 32 >> 2];
													e = y[i + 20 >> 2];
													g = !m | (e | 0) < 2 ? g : z[n | 0] >>> 6 & 1;
													g = !m | (e | 0) <= 0 ? g : z[n | 0] >>> 6 & 2 | g;
													h = 0;
													h = !j | (e | 0) < 2 ? h : z[k | 0] >>> 6 & 1;
													h = !j | (e | 0) <= 0 ? h : z[k | 0] >>> 6 & 2 | h;
													r = 0;
													d = 0;
													while (1) {
														if (B[a + 4 >> 2] <= d >>> 0) {
															break d;
														}
														g: {
															h: {
																if (z[a + 2 | 0] == 1) {
																	if (ia(y[y[a + 12 >> 2] + 20 >> 2], d, v, u)) {
																		break h;
																	}
																}
																e = ia(e, w[a + 16 | 0] + d | 0, E, D);
																if (z[l | 0]) {
																	break b;
																}
																e = h << 3 | g << 7 | e << 2 | r;
																if (e >>> 0 >= s >>> 0) {
																	break e;
																}
																q = ka(l, (e << 1) + t | 0);
																e = y[i + 20 >> 2];
																if (!q) {
																	break h;
																}
																Ea(e, d, p, f, 1);
																e = y[i + 20 >> 2];
																q = 1;
																break g;
															}
															q = 0;
														}
														x = d + 2 | 0;
														g = ia(e, x, n, m) | g << 1 & 6;
														h = ia(e, x, k, j) | h << 1 & 14;
														d = d + 1 | 0;
														r = r << 1 & 2 | q;
														continue;
													}
												}
												o();
											}
											f = y[b + 16 >> 2];
											if (!f) {
												d = y[a + 24 >> 2];
												break c;
											}
											f = _[y[y[f >> 2] + 8 >> 2]](f) | 0;
											d = y[a + 24 >> 2];
											if (!f) {
												break c;
											}
											y[a + 24 >> 2] = d + 1;
											d = 3;
										}
										y[a + 52 >> 2] = d;
										break a;
									}
									d = d + 1 | 0;
									y[a + 24 >> 2] = d;
									n = k;
									m = j;
									continue;
								}
								break;
							}
							d = -1;
						}
						Y = c + 48 | 0;
						return d | 0;
					}
					function vc(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0;
						f = Y - 32 | 0;
						Y = f;
						k = ua(a, a + 4 | 0);
						y[f + 28 >> 2] = k;
						a: {
							c = y[k + 16 >> 2];
							if (!c) {
								k = 0;
								break a;
							}
							Mb(y[k + 12 >> 2], c, z[a + 20 | 0]);
							b: {
								while (1) {
									if (!m & l >>> 0 >= B[a + 36 >> 2] | m) {
										y[f + 28 >> 2] = 0;
										break a;
									}
									e = y[b >> 2];
									c = y[b + 4 >> 2];
									d = 0;
									y[f + 24 >> 2] = 0;
									y[f + 16 >> 2] = 0;
									y[f + 20 >> 2] = 0;
									c: {
										d: {
											if ((c | 0) == (e | 0)) {
												j = 0;
												e = c;
												break d;
											}
											c = c - e | 0;
											e = c >> 2;
											if (e >>> 0 >= 536870912) {
												break c;
											}
											j = na(c << 1);
											y[f + 16 >> 2] = j;
											d = (e << 3) + j | 0;
											y[f + 24 >> 2] = d;
											c = j;
											while (1) {
												if ((c | 0) != (d | 0)) {
													y[c >> 2] = 0;
													y[c + 4 >> 2] = 0;
													c = c + 8 | 0;
													continue;
												}
												break;
											}
											y[f + 20 >> 2] = d;
											c = y[b >> 2];
											e = y[b + 4 >> 2];
										}
										e = e - c | 0;
										if (e >> 2 >>> 0 > d - j >> 3 >>> 0) {
											break b;
										}
										e = c + e | 0;
										d = j;
										while (1) {
											if ((c | 0) == (e | 0)) {
												e: {
													c = y[a + 44 >> 2];
													d = ze(l, m, A[a + 48 >> 1], 0);
													e = c + d | 0;
													c = Z + (c >> 31) | 0;
													n = e;
													r = d >>> 0 > e >>> 0 ? c + 1 | 0 : c;
													c = y[a + 40 >> 2];
													d = ze(l, m, A[a + 50 >> 1], 0);
													e = c + d | 0;
													c = Z + (c >> 31) | 0;
													s = e;
													t = d >>> 0 > e >>> 0 ? c + 1 | 0 : c;
													e = 0;
													c = 0;
													f: while (1) {
														if (!c & B[a + 32 >> 2] <= e >>> 0 | c) {
															break e;
														}
														h = y[b >> 2];
														p = y[b + 4 >> 2] - h >> 2;
														d = 0;
														g = 0;
														while (1) {
															i = d & 255;
															if (p >>> 0 <= i >>> 0) {
																d = y[a + 12 >> 2] - 1 | 0;
																d = y[y[y[a + 16 >> 2] >> 2] + ((d >>> 0 < g >>> 0 ? d : g) << 2) >> 2];
																h = ze(e, c, A[a + 48 >> 1], 0);
																i = h + s | 0;
																g = Z + t | 0;
																g = h >>> 0 > i >>> 0 ? g + 1 | 0 : g;
																h = ze(e, c, A[a + 50 >> 1], 0);
																p = n - h | 0;
																i = (g & 255) << 24 | i >>> 8;
																q = g >> 8;
																h = r - (Z + (h >>> 0 > n >>> 0) | 0) | 0;
																g = h >> 8;
																Ab(d, k, i, q, (h & 255) << 24 | p >>> 8, g, y[a + 24 >> 2]);
																e = e + 1 | 0;
																c = e ? c : c + 1 | 0;
																continue f;
															} else {
																q = g;
																g = (i << 3) + j | 0;
																g = q | ia(y[y[(i << 2) + h >> 2] + 20 >> 2], e, y[g >> 2], y[g + 4 >> 2]) << i;
																d = d + 1 | 0;
																continue;
															}
														}
													}
												}
											} else {
												ja(f + 8 | 0, y[c >> 2], l);
												n = y[f + 12 >> 2];
												y[d >> 2] = y[f + 8 >> 2];
												y[d + 4 >> 2] = n;
												d = d + 8 | 0;
												c = c + 4 | 0;
												continue;
											}
											break;
										}
										d = m;
										l = l + 1 | 0;
										m = l ? d : d + 1 | 0;
										va(f + 16 | 0);
										continue;
									}
									break;
								}
								za();
							}
							o();
						}
						la(f + 28 | 0);
						Y = f + 32 | 0;
						return k;
					}
					function Zb(a, b, c, d, e, f, g, h) {
						var i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0, p = 0, q = 0, r = 0, s = 0, t = 0;
						j = Y - 48 | 0;
						Y = j;
						m = ((b & 536870911) << 3 | a >>> 29) & -8;
						o = d;
						d = -1;
						p = 1;
						a: {
							b: while (1) {
								k = p & 1;
								q = k ? 326 : 325;
								r = k ? 1392 : 1056;
								s = k ? 325 : 326;
								t = k ? 1056 : 1392;
								c: while (1) {
									i = y[c >> 2];
									while (1) {
										if (i >>> 0 >= m >>> 0) {
											break a;
										}
										d: {
											i = 0;
											e: {
												if (Ia(a, b, c)) {
													break e;
												}
												if (B[c >> 2] >= m >>> 0) {
													break a;
												}
												l = Ia(a, b, c);
												if (B[c >> 2] >= m >>> 0) {
													break a;
												}
												n = Ia(a, b, c);
												i = n ? 1 : -1;
												if (l) {
													break e;
												}
												if (n) {
													i = 0;
													while (1) {
														Yb(j + 44 | 0, t, s, a, b, c);
														if (z[j + 46 | 0] != 1) {
															break a;
														}
														l = A[j + 44 >> 1];
														i = l + i | 0;
														if ((i | 0) > (h | 0)) {
															break a;
														}
														if (l >>> 0 >= 64) {
															continue;
														}
														break;
													}
													l = ((d >>> 31 | 0) + d | 0) + i | 0;
													if (!k) {
														gb(o, e, h, d, l);
													}
													i = 0;
													while (1) {
														Yb(j + 44 | 0, r, q, a, b, c);
														if (z[j + 46 | 0] != 1) {
															break a;
														}
														d = A[j + 44 >> 1];
														i = d + i | 0;
														if ((i | 0) > (h | 0)) {
															break a;
														}
														if (d >>> 0 >= 64) {
															continue;
														}
														break;
													}
													d = i + l | 0;
													if (k) {
														gb(o, e, h, l, d);
													}
													if ((d | 0) < (h | 0)) {
														continue c;
													}
													break a;
												}
												if (B[c >> 2] >= m >>> 0) {
													break a;
												}
												if (Ia(a, b, c)) {
													y[j + 32 >> 2] = f;
													y[j + 36 >> 2] = g;
													y[j + 16 >> 2] = f;
													y[j + 20 >> 2] = g;
													Gc(j + 16 | 0, h, d, k, j + 44 | 0, j + 40 | 0);
													i = y[j + 40 >> 2];
													if (!k) {
														gb(o, e, h, d, i);
													}
													d = i;
													if ((i | 0) < (h | 0)) {
														continue c;
													}
													break a;
												}
												if (B[c >> 2] >= m >>> 0) {
													break a;
												}
												l = Ia(a, b, c);
												if (B[c >> 2] >= m >>> 0) {
													break a;
												}
												n = Ia(a, b, c);
												i = n ? 2 : -2;
												if (l) {
													break e;
												}
												i = y[c >> 2];
												if (!n) {
													break d;
												}
												if (i >>> 0 >= m >>> 0) {
													break a;
												}
												i = Ia(a, b, c) ? 3 : -3;
											}
											y[j + 24 >> 2] = f;
											y[j + 28 >> 2] = g;
											y[j + 8 >> 2] = f;
											y[j + 12 >> 2] = g;
											Gc(j + 8 | 0, h, d, k, j + 44 | 0, j + 40 | 0);
											i = i + y[j + 44 >> 2] | 0;
											if (!k) {
												gb(o, e, h, d, i);
											}
											if ((h | 0) <= (i | 0)) {
												break a;
											}
											p = p ^ 1;
											k = (d | 0) < (i | 0);
											d = i;
											if (k) {
												continue b;
											}
											break a;
										}
										if (i >>> 0 >= m >>> 0) {
											break a;
										}
										l = Ia(a, b, c);
										i = y[c >> 2];
										if (l) {
											i = i + 3 | 0;
											y[c >> 2] = i;
											continue;
										}
										break;
									}
									break;
								}
								break;
							}
							y[c >> 2] = i + 5;
						}
						Y = j + 48 | 0;
					}
					function qe(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, p = 0, q = 0, r = 0, s = 0, t = 0, u = 0, v = 0, x = 0, A = 0;
						c = Y - 48 | 0;
						Y = c;
						i = y[b + 4 >> 2];
						q = y[b + 12 >> 2];
						r = y[b + 8 >> 2];
						h = y[y[b >> 2] >> 2];
						d = y[a + 24 >> 2];
						ja(c + 40 | 0, h, d - 1 | 0);
						u = r + 810 | 0;
						v = q >>> 0 > 405;
						j = 4;
						a: {
							while (1) {
								b: {
									c: {
										if (B[a + 8 >> 2] > d >>> 0) {
											k = y[c + 44 >> 2];
											l = y[c + 40 >> 2];
											ja(c + 32 | 0, h, d);
											e = y[c + 36 >> 2];
											m = y[c + 32 >> 2];
											y[c + 40 >> 2] = m;
											y[c + 44 >> 2] = e;
											d: {
												e: {
													f: {
														if (!z[a + 1 | 0]) {
															d = y[a + 60 >> 2];
															break f;
														}
														if (z[i | 0]) {
															break b;
														}
														if (!v) {
															break e;
														}
														d = y[a + 60 >> 2] ^ ka(i, u);
														y[a + 60 >> 2] = d;
													}
													if (d) {
														y[c + 20 >> 2] = k;
														y[c + 16 >> 2] = l;
														y[c + 24 >> 2] = m;
														y[c + 28 >> 2] = e;
														y[c + 8 >> 2] = m;
														y[c + 12 >> 2] = e;
														e = y[c + 20 >> 2];
														y[c >> 2] = y[c + 16 >> 2];
														y[c + 4 >> 2] = e;
														Ca(c + 8 | 0, c);
														break d;
													}
													d = y[a + 24 >> 2];
													g = 0;
													s = 0;
													t = 0;
													if (z[a + 2 | 0] == 1) {
														ja(c + 32 | 0, y[a + 12 >> 2], d);
														t = y[c + 32 >> 2];
														s = y[c + 36 >> 2];
													}
													ja(c + 32 | 0, h, d + w[a + 17 | 0] | 0);
													x = y[c + 36 >> 2];
													A = y[c + 32 >> 2];
													f = y[h + 20 >> 2];
													g = !k | (f | 0) < 2 ? g : z[l | 0] >>> 6 & 1;
													g = !k | (f | 0) <= 0 ? g : z[l | 0] >>> 6 & 2 | g;
													p = 0;
													d = 0;
													while (1) {
														if (B[a + 4 >> 2] <= d >>> 0) {
															break d;
														}
														g: {
															h: {
																if (z[a + 2 | 0] == 1) {
																	if (ia(y[y[a + 12 >> 2] + 20 >> 2], d, t, s)) {
																		break h;
																	}
																}
																f = ia(f, w[a + 16 | 0] + d | 0, A, x);
																if (z[i | 0]) {
																	break b;
																}
																f = g << 5 | f << 4 | p;
																if (f >>> 0 >= q >>> 0) {
																	break e;
																}
																n = ka(i, (f << 1) + r | 0);
																f = y[h + 20 >> 2];
																if (!n) {
																	break h;
																}
																Ea(f, d, m, e, 1);
																f = y[h + 20 >> 2];
																n = 1;
																break g;
															}
															n = 0;
														}
														g = ia(f, d + 2 | 0, l, k) | g << 1 & 30;
														d = d + 1 | 0;
														p = p << 1 & 14 | n;
														continue;
													}
												}
												o();
											}
											e = y[b + 16 >> 2];
											if (!e) {
												d = y[a + 24 >> 2];
												break c;
											}
											e = _[y[y[e >> 2] + 8 >> 2]](e) | 0;
											d = y[a + 24 >> 2];
											if (!e) {
												break c;
											}
											y[a + 24 >> 2] = d + 1;
											j = 3;
										}
										y[a + 52 >> 2] = j;
										break a;
									}
									d = d + 1 | 0;
									y[a + 24 >> 2] = d;
									continue;
								}
								break;
							}
							j = -1;
						}
						Y = c + 48 | 0;
						return j | 0;
					}
					function Od(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0;
						c = y[b + 60 >> 2];
						d = y[b + 64 >> 2];
						f = b + 52 | 0;
						Jc(c, d, f);
						j = ((d & 536870911) << 3 | c >>> 29) & -8;
						if (j >>> 0 <= B[b + 52 >> 2]) {
							y[a >> 2] = 0;
							y[a + 4 >> 2] = 0;
							return;
						}
						Kc(y[b + 68 >> 2], y[b + 72 >> 2]);
						h = b + 68 | 0;
						c = y[b + 48 >> 2];
						a: {
							if ((c | 0) < 0) {
								e = y[b + 68 >> 2];
								c = y[b + 72 >> 2] - e | 0;
								d = 0;
								i = c;
								g = y[b + 80 >> 2];
								c = y[b + 84 >> 2] - g | 0;
								Zb(y[b + 60 >> 2], y[b + 64 >> 2], f, e | d, i, d | g, c, y[b + 4 >> 2]);
								Ic(b + 80 | 0, h);
								break a;
							}
							if (!c) {
								d = y[b + 68 >> 2];
								c = y[b + 72 >> 2] - d | 0;
								Hc(y[b + 60 >> 2], y[b + 64 >> 2], f, d, c, y[b + 4 >> 2]);
								break a;
							}
							e = Ia(y[b + 60 >> 2], y[b + 64 >> 2], f);
							g = y[b + 68 >> 2];
							c = y[b + 72 >> 2] - g | 0;
							d = y[b + 60 >> 2];
							k = y[b + 64 >> 2];
							b: {
								if (e) {
									Hc(d, k, f, g, c, y[b + 4 >> 2]);
									break b;
								}
								i = d;
								d = 0;
								l = c;
								e = y[b + 80 >> 2];
								c = y[b + 84 >> 2] - e | 0;
								Zb(i, k, f, d | g, l, d | e, c, y[b + 4 >> 2]);
							}
							Ic(b + 80 | 0, h);
						}
						if (z[b + 57 | 0] == 1) {
							Jc(y[b + 60 >> 2], y[b + 64 >> 2], f);
						}
						c: {
							d: {
								e: {
									if (z[b + 56 | 0] != 1) {
										break e;
									}
									d = y[f >> 2];
									if (j >>> 0 <= d >>> 0) {
										break e;
									}
									e = d + 7 & -8;
									while (1) {
										h = d >>> 3 | 0;
										g = 128 >>> (d & 7) | 0;
										c = 1;
										f: {
											while (1) {
												if (!c | d >>> 0 >= e >>> 0) {
													break f;
												}
												if (h >>> 0 >= B[b + 64 >> 2]) {
													break d;
												}
												if (g & z[h + y[b + 60 >> 2] | 0]) {
													c = 0;
													w[b + 56 | 0] = 0;
													continue;
												}
												break;
											}
											d = d + 1 | 0;
											continue;
										}
										break;
									}
									if (!c) {
										break e;
									}
									y[f >> 2] = e;
								}
								c = y[b + 68 >> 2];
								if (!z[b + 58 | 0]) {
									d = y[b + 72 >> 2] - c | 0;
									break c;
								}
								if (c & 3) {
									break d;
								}
								d = y[b + 72 >> 2] - c | 0;
								e = c + (d & -4) | 0;
								b = c;
								while (1) {
									if ((b | 0) == (e | 0)) {
										break c;
									}
									y[b >> 2] = y[b >> 2] ^ -1;
									b = b + 4 | 0;
									continue;
								}
							}
							o();
						}
						y[a + 4 >> 2] = d;
						y[a >> 2] = c;
					}
					function ab(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0;
						i = Y - 32 | 0;
						Y = i;
						a: {
							b: {
								if (!y[a + 16 >> 2] | y[a + 24 >> 2] >= (b | 0)) {
									break b;
								}
								e = y[a + 28 >> 2];
								if ((268435452 / (e | 0) | 0) < (b | 0)) {
									break b;
								}
								if ((b | 0) < 0) {
									break a;
								}
								e = ze(e, e >> 31, b, 0);
								g = Z;
								if ((g | 0) == 1 | g >>> 0 > 1) {
									break a;
								}
								k = y[a + 12 >> 2];
								g = 0;
								j = y[a + 16 >> 2];
								d = y[a >> 2];
								h = y[a + 4 >> 2];
								c: {
									if ((d | 0) != (h | 0)) {
										y[a + 12 >> 2] = 0;
										y[a + 16 >> 2] = 0;
										f = h - d | 0;
										d: {
											if (f >>> 0 < e >>> 0) {
												g = y[a + 8 >> 2];
												if (e >>> 0 <= g - d >>> 0) {
													kd(a, e - f | 0);
													break d;
												}
												h = Fc(d, g, e);
												if (h) {
													l = Ad(h);
												}
												k = e + l | 0;
												g = f + l | 0;
												d = g;
												while (1) {
													if ((d | 0) != (k | 0)) {
														w[d | 0] = 0;
														d = d + 1 | 0;
														continue;
													}
													break;
												}
												d = y[a >> 2];
												e = y[a + 4 >> 2];
												g = g + (d - e | 0) | 0;
												f = g;
												while (1) {
													if ((d | 0) != (e | 0)) {
														w[f | 0] = z[d | 0];
														f = f + 1 | 0;
														d = d + 1 | 0;
														continue;
													}
													break;
												}
												y[a + 4 >> 2] = k;
												y[a + 8 >> 2] = h + l;
												e = y[a >> 2];
												y[a >> 2] = g;
												ma(e);
												break d;
											}
											if (e >>> 0 >= f >>> 0) {
												break d;
											}
											y[a + 4 >> 2] = d + e;
										}
										e = y[a >> 2];
										y[a + 12 >> 2] = e;
										d = y[a + 4 >> 2] - e | 0;
										y[a + 16 >> 2] = d;
										break c;
									}
									f = Gb(i, e);
									h = y[f >> 2];
									y[i + 12 >> 2] = h;
									e = y[f + 4 >> 2];
									y[i + 16 >> 2] = e;
									y[i + 20 >> 2] = y[f + 8 >> 2];
									y[f + 8 >> 2] = 0;
									y[f >> 2] = 0;
									y[f + 4 >> 2] = 0;
									y[i + 28 >> 2] = e - h;
									y[i + 24 >> 2] = h;
									e = i + 12 | 0;
									ec(a, e);
									va(e);
									va(f);
									d = y[a + 16 >> 2];
									if (j >>> 0 > d >>> 0) {
										break a;
									}
									if (!(g | j)) {
										break c;
									}
									if (j) {
										p(y[a + 12 >> 2], k, j);
									}
									d = y[a + 16 >> 2];
								}
								if (d >>> 0 < j >>> 0) {
									break a;
								}
								c = 0 - c | 0;
								d = d - j | 0;
								f = y[a + 12 >> 2] + j | 0;
								while (1) {
									if ((d | 0) > 0) {
										w[f | 0] = c;
										d = d - 1 | 0;
										f = f + 1 | 0;
										continue;
									}
									break;
								}
								y[a + 24 >> 2] = b;
							}
							Y = i + 32 | 0;
							return;
						}
						o();
					}
					function nd(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0;
						d = Y - 32 | 0;
						Y = d;
						h = y[a + 24 >> 2];
						y[d + 16 >> 2] = 0;
						a: {
							b: {
								switch (z[a + 3 | 0]) {
									case 0:
										c = Bd(a) ? 3 : 4;
										break a;
									case 1:
										c = yd(a) ? 5 : 6;
										break a;
									case 2:
										c = Hb(a) ? 7 : 8;
										break a;
									default: break b;
								}
							}
							c = Hb(a) ? 9 : 10;
						}
						e = Y - 48 | 0;
						Y = e;
						y[e + 24 >> 2] = 0;
						c: {
							if (c) {
								y[e + 16 >> 2] = 0;
								y[e + 12 >> 2] = c;
								y[e + 8 >> 2] = 2244;
								g = e + 8 | 0;
								y[e + 24 >> 2] = g;
								if (y[d + 16 >> 2] == (d | 0)) {
									f = e + 32 | 0;
									_[y[y[e + 8 >> 2] + 12 >> 2]](g, f);
									c = y[e + 24 >> 2];
									_[y[y[c >> 2] + 16 >> 2]](c);
									y[e + 24 >> 2] = 0;
									c = y[d + 16 >> 2];
									_[y[y[c >> 2] + 12 >> 2]](c, g);
									c = y[d + 16 >> 2];
									_[y[y[c >> 2] + 16 >> 2]](c);
									y[d + 16 >> 2] = 0;
									y[e + 24 >> 2] = g;
									_[y[y[e + 32 >> 2] + 12 >> 2]](f, d);
									_[y[y[e + 32 >> 2] + 16 >> 2]](f);
									y[d + 16 >> 2] = d;
									break c;
								}
								_[y[y[e + 8 >> 2] + 12 >> 2]](e + 8 | 0, d);
								c = y[e + 24 >> 2];
								_[y[y[c >> 2] + 16 >> 2]](c);
								y[e + 24 >> 2] = y[d + 16 >> 2];
								y[d + 16 >> 2] = d;
								break c;
							}
							c = y[d + 16 >> 2];
							if ((c | 0) == (d | 0)) {
								f = e + 8 | 0;
								_[y[y[c >> 2] + 12 >> 2]](c, f);
								c = y[d + 16 >> 2];
								_[y[y[c >> 2] + 16 >> 2]](c);
								y[d + 16 >> 2] = y[e + 24 >> 2];
								y[e + 24 >> 2] = f;
								break c;
							}
							y[e + 24 >> 2] = c;
							y[d + 16 >> 2] = 0;
						}
						md(e + 8 | 0);
						Y = e + 48 | 0;
						c = y[y[b >> 2] >> 2];
						f = y[d + 16 >> 2];
						y[d + 28 >> 2] = b;
						if (f) {
							f = _[y[y[f >> 2] + 24 >> 2]](f, a, d + 28 | 0) | 0;
							y[a + 64 >> 2] = 0;
							y[a + 52 >> 2] = f;
							b = y[c + 20 >> 2];
							y[a + 68 >> 2] = h;
							y[a + 72 >> 2] = b;
							y[a + 76 >> 2] = y[a + 24 >> 2];
							if ((f | 0) == 4) {
								y[a + 24 >> 2] = 0;
							}
							md(d);
							Y = d + 32 | 0;
							return f;
						}
						a = vb(4);
						y[a >> 2] = 4876;
						P(a | 0, 4888, 11);
						o();
					}
					function ie(a, b, c, d, e, f, g, h, i, j) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						f = f | 0;
						g = g | 0;
						h = h | 0;
						i = i | 0;
						j = j | 0;
						var k = 0, l = 0;
						k = Y - 16 | 0;
						Y = k;
						l = i ? i : c;
						a: {
							if ((l | 0) <= 0) {
								break a;
							}
							j = j ? j : d;
							if ((j | 0) <= 0 | (j | l) >>> 0 > 65535) {
								break a;
							}
							i = na(92);
							y[i + 44 >> 2] = 0;
							y[i + 36 >> 2] = -1;
							y[i + 40 >> 2] = 0;
							w[i + 32 | 0] = 0;
							y[i + 20 >> 2] = 1;
							y[i + 24 >> 2] = 1;
							y[i + 16 >> 2] = j;
							y[i + 12 >> 2] = l;
							y[i + 8 >> 2] = j;
							y[i + 4 >> 2] = l;
							y[i + 60 >> 2] = a;
							y[i + 64 >> 2] = b;
							w[i + 58 | 0] = (h | 0) != 0;
							w[i + 57 | 0] = (f | 0) != 0;
							w[i + 56 | 0] = (g | 0) != 0;
							y[i + 52 >> 2] = 0;
							y[i + 48 >> 2] = e;
							y[i >> 2] = 1728;
							a = (l >>> 3 | 0) + 3 | 0;
							a = ((l << 29) - 536870912 >>> 0 < 3758096384 ? a + 1 | 0 : a) & 16380;
							y[i + 28 >> 2] = a;
							Gb(i + 68 | 0, a);
							Gb(i + 80 | 0, y[i + 28 >> 2]);
							e = c + 7 >>> 3 | 0;
							W(E(e, d) | 0);
							c = 0;
							while (1) {
								b: {
									if ((c | 0) == (d | 0)) {
										break b;
									}
									c: {
										j = y[i + 36 >> 2];
										a = c + 1 | 0;
										if ((j | 0) == (a | 0)) {
											b = y[i + 44 >> 2];
											j = y[i + 40 >> 2];
											break c;
										}
										d: {
											if (!((j | 0) >= 0 & (c | 0) >= (j | 0))) {
												j = 0;
												if (!(_[y[y[i >> 2] + 12 >> 2]](i) | 0)) {
													break b;
												}
												b = 0;
												break d;
											}
											b = 1;
										}
										while (1) {
											if (!b) {
												y[i + 36 >> 2] = j;
												b = 1;
												continue;
											}
											e: {
												if ((c | 0) > (j | 0)) {
													_[y[y[i >> 2] + 16 >> 2]](k + 8 | 0, i);
													j = y[i + 36 >> 2] + 1 | 0;
													break e;
												}
												_[y[y[i >> 2] + 16 >> 2]](k + 8 | 0, i);
												b = y[k + 12 >> 2];
												j = y[k + 8 >> 2];
												y[i + 40 >> 2] = j;
												y[i + 44 >> 2] = b;
												y[i + 36 >> 2] = y[i + 36 >> 2] + 1;
												break c;
											}
											b = 0;
											continue;
										}
									}
									if (!b) {
										break b;
									}
									V(j | 0, e | 0, E(c, e) | 0);
									c = a;
									continue;
								}
								break;
							}
							_[y[y[i >> 2] + 4 >> 2]](i);
						}
						Y = k + 16 | 0;
					}
					function db(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, q = 0, r = 0, s = 0, t = 0, u = 0;
						d = Y - 32 | 0;
						Y = d;
						h = ua(a + 4 | 0, a + 8 | 0);
						y[d + 8 >> 2] = h;
						i = y[h + 12 >> 2];
						f = y[h + 16 >> 2];
						g = f;
						a: {
							if (!f) {
								oa(b, 0);
								y[a + 52 >> 2] = -1;
								break a;
							}
							b: {
								f = y[h + 28 >> 2];
								if ((f | 0) < 0 | !f) {
									break b;
								}
								j = y[c + 12 >> 2] + (y[c + 8 >> 2] << 3) | 0;
								l = g;
								k = y[a + 8 >> 2];
								q = y[a + 4 >> 2];
								r = y[c >> 2];
								s = y[c + 4 >> 2];
								y[d + 20 >> 2] = 0;
								y[d + 12 >> 2] = 0;
								y[d + 16 >> 2] = 0;
								g = d + 12 | 0;
								y[d + 24 >> 2] = g;
								Eb(g, f);
								e = y[d + 16 >> 2];
								g = f + e | 0;
								while (1) {
									if ((e | 0) != (g | 0)) {
										w[e | 0] = 255;
										e = e + 1 | 0;
										continue;
									}
									break;
								}
								w[d + 28 | 0] = 1;
								y[d + 16 >> 2] = g;
								gc(d + 24 | 0);
								m = y[d + 12 >> 2];
								g = y[d + 16 >> 2];
								y[d + 24 >> 2] = j;
								t = (k | 0) > 0 ? k : 0;
								e = 0;
								g = g - m | 0;
								k = e | m;
								while (1) {
									if ((n | 0) != (t | 0)) {
										j = i;
										e = f;
										if (l >>> 0 < f >>> 0) {
											break b;
										}
										while (1) {
											if ((e | 0) > 0) {
												w[j | 0] = 255;
												e = e - 1 | 0;
												j = j + 1 | 0;
												continue;
											}
											break;
										}
										Zb(r, s, d + 24 | 0, i | u, f, k, g, q);
										if (f >>> 0 > g >>> 0) {
											break b;
										}
										if (f) {
											p(m, i, f);
										}
										n = n + 1 | 0;
										l = l - f | 0;
										i = f + i | 0;
										continue;
									}
									break;
								}
								i = y[d + 24 >> 2];
								va(d + 12 | 0);
								y[c + 12 >> 2] = i & 7;
								y[c + 8 >> 2] = i >>> 3;
								e = y[h + 12 >> 2];
								c = e + y[h + 16 >> 2] | 0;
								while (1) if ((c | 0) == (e | 0)) {
									y[a + 64 >> 2] = 0;
									y[a + 52 >> 2] = 4;
									c = y[h + 20 >> 2];
									y[a + 68 >> 2] = 0;
									y[a + 72 >> 2] = c;
									y[a + 76 >> 2] = y[h + 24 >> 2];
									y[d + 8 >> 2] = 0;
									oa(b, h);
									break a;
								} else {
									w[e | 0] = z[e | 0] ^ -1;
									e = e + 1 | 0;
									continue;
								}
							}
							o();
						}
						la(d + 8 | 0);
						Y = d + 32 | 0;
					}
					function Ld(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0;
						f = Y - 16 | 0;
						Y = f;
						y[a + 44 >> 2] = 0;
						e = y[a + 12 >> 2];
						b = y[a + 8 >> 2];
						while (1) {
							if ((b | 0) == (e | 0)) {
								a: {
									y[f + 4 >> 2] = 0;
									d = c + 1 | 0;
									fc(a + 60 | 0, d, f + 4 | 0);
									e = y[a + 12 >> 2];
									b = y[a + 8 >> 2];
									while (1) if ((b | 0) == (e | 0)) {
										y[y[a + 60 >> 2] >> 2] = 0;
										y[f + 4 >> 2] = 0;
										b = f + 4 | 0;
										fc(a + 48 | 0, d, b);
										y[f + 4 >> 2] = 0;
										fc(a + 72 | 0, d, b);
										c = 0;
										e = 0;
										b = 1;
										while (1) {
											j = B[a + 44 >> 2] < b >>> 0;
											if (!j) {
												g = b << 2;
												h = g + y[a + 60 >> 2] | 0;
												i = y[h - 4 >> 2];
												c = i + c | 0;
												if ((c | 0) < 0 | c >>> 0 < i >>> 0) {
													break a;
												}
												c = c << 1;
												y[g + y[a + 48 >> 2] >> 2] = c;
												y[g + y[a + 72 >> 2] >> 2] = e;
												b = b + 1 | 0;
												e = y[h >> 2] + e | 0;
												continue;
											}
											break;
										}
										Rb(a + 84 | 0, e);
										b = 0;
										y[f + 12 >> 2] = 0;
										y[f + 4 >> 2] = 0;
										y[f + 8 >> 2] = 0;
										e = 0;
										if (d) {
											e = f + 4 | 0;
											ed(e, d);
											qd(e, d);
											e = y[f + 4 >> 2];
										}
										g = y[a + 8 >> 2];
										h = y[a + 12 >> 2] - g >> 3;
										while (1) {
											if ((b | 0) == (h | 0)) {
												va(f + 4 | 0);
												break a;
											}
											c = g + (b << 3) | 0;
											d = y[c >> 2];
											if (d) {
												i = c;
												d = d << 2;
												c = d + e | 0;
												y[i + 4 >> 2] = y[c >> 2] + y[d + y[a + 48 >> 2] >> 2];
												y[(y[a + 84 >> 2] + (y[d + y[a + 72 >> 2] >> 2] << 2) | 0) + (y[c >> 2] << 2) >> 2] = b;
												y[c >> 2] = y[c >> 2] + 1;
											}
											b = b + 1 | 0;
											continue;
										}
									} else {
										c = y[a + 60 >> 2] + (y[b >> 2] << 2) | 0;
										y[c >> 2] = y[c >> 2] + 1;
										b = b + 8 | 0;
										continue;
									}
								}
							} else {
								d = y[b >> 2];
								c = c >>> 0 < d >>> 0 ? d : c;
								y[a + 44 >> 2] = c;
								b = b + 8 | 0;
								continue;
							}
							break;
						}
						Y = f + 16 | 0;
						return j;
					}
					function Md(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0, g = 0, h = 0;
						b = y[1420];
						c = a + 7 & -8;
						a = c + 7 | 0;
						d = a >>> 0 < 7 ? 1 : d;
						e = a & -8;
						a = e + b | 0;
						a: {
							b: {
								if (!(a >>> 0 < e >>> 0 ? d + 1 | 0 : d)) {
									if (a >>> 0 <= $() << 16 >>> 0) {
										break b;
									}
									if (R(a | 0) | 0) {
										break b;
									}
								}
								y[1428] = 48;
								b = -1;
								break a;
							}
							y[1420] = a;
						}
						d = b;
						if ((d | 0) != -1) {
							a = d + c | 0;
							y[a - 4 >> 2] = 16;
							f = a - 16 | 0;
							y[f >> 2] = 16;
							b = y[1688];
							if (b) {
								e = y[b + 8 >> 2];
							} else {
								e = 0;
							}
							c: {
								d: {
									if ((e | 0) == (d | 0)) {
										e = y[d - 4 >> 2] & -2;
										g = d - e | 0;
										h = y[g - 4 >> 2];
										y[b + 8 >> 2] = a;
										b = h & -2;
										a = g - b | 0;
										if (y[(a + y[a >> 2] | 0) - 4 >> 2] & 1) {
											f = y[a + 4 >> 2];
											g = y[a + 8 >> 2];
											y[f + 8 >> 2] = g;
											y[g + 4 >> 2] = f;
											b = (b + (c + e | 0) | 0) - 16 | 0;
											y[a >> 2] = b;
											break c;
										}
										a = d - 16 | 0;
										break d;
									}
									y[d >> 2] = 16;
									y[d + 8 >> 2] = a;
									y[d + 4 >> 2] = b;
									y[d + 12 >> 2] = 16;
									y[1688] = d;
									a = d + 16 | 0;
								}
								b = f - a | 0;
								y[a >> 2] = b;
							}
							y[((b & -4) + a | 0) - 4 >> 2] = b | 1;
							c = y[a >> 2] - 8 | 0;
							e: {
								if (c >>> 0 <= 127) {
									b = (c >>> 3 | 0) - 1 | 0;
									break e;
								}
								e = H(c);
								b = ((c >>> 29 - e ^ 4) - (e << 2) | 0) + 110 | 0;
								if (c >>> 0 <= 4095) {
									break e;
								}
								b = ((c >>> 30 - e ^ 2) - (e << 1) | 0) + 71 | 0;
								b = b >>> 0 >= 63 ? 63 : b;
							}
							c = b << 4;
							y[a + 4 >> 2] = c + 5728;
							c = c + 5736 | 0;
							y[a + 8 >> 2] = y[c >> 2];
							y[c >> 2] = a;
							y[y[a + 8 >> 2] + 4 >> 2] = a;
							c = y[1691];
							a = b & 31;
							if ((b & 63) >>> 0 >= 32) {
								b = 1 << a;
								e = 0;
							} else {
								e = 1 << a;
								b = e - 1 & 1 >>> 32 - a;
							}
							y[1690] = e | y[1690];
							y[1691] = b | c;
						}
						return (d | 0) != -1;
					}
					function tb(a, b) {
						var c = 0, d = 0, e = 0;
						c = Y + -64 | 0;
						Y = c;
						d = y[a >> 2];
						e = y[d - 8 >> 2];
						d = y[d - 4 >> 2];
						a: {
							if (y[d + 4 >> 2] == y[b + 4 >> 2]) {
								a = e ? 0 : a;
								break a;
							}
							e = a + e | 0;
							if ((e | 0) <= (a | 0)) {
								y[c + 16 >> 2] = 0;
								y[c + 20 >> 2] = 0;
								y[c + 12 >> 2] = b;
								y[c + 8 >> 2] = a;
								y[c + 4 >> 2] = d;
								y[c + 24 >> 2] = 0;
								y[c + 28 >> 2] = 0;
								y[c + 32 >> 2] = 0;
								y[c + 36 >> 2] = 0;
								y[c + 40 >> 2] = 0;
								y[c + 44 >> 2] = 0;
								y[c + 48 >> 2] = 0;
								y[c + 60 >> 2] = 0;
								y[c + 52 >> 2] = 1;
								y[c + 56 >> 2] = 16777216;
								_[y[y[d >> 2] + 20 >> 2]](d, c + 4 | 0, e, e, 1, 0);
								if (y[c + 28 >> 2]) {
									break a;
								}
							}
							y[c + 16 >> 2] = 0;
							y[c + 20 >> 2] = 0;
							y[c + 12 >> 2] = 4984;
							y[c + 8 >> 2] = a;
							y[c + 4 >> 2] = b;
							y[c + 24 >> 2] = 0;
							y[c + 28 >> 2] = 0;
							y[c + 32 >> 2] = 0;
							y[c + 36 >> 2] = 0;
							y[c + 40 >> 2] = 0;
							y[c + 44 >> 2] = 0;
							y[c + 48 >> 2] = 0;
							y[c + 52 >> 2] = 0;
							a = 0;
							w[c + 55 | 0] = 0;
							w[c + 56 | 0] = 0;
							w[c + 57 | 0] = 0;
							w[c + 58 | 0] = 0;
							y[c + 60 >> 2] = 0;
							w[c + 59 | 0] = 1;
							_[y[y[d >> 2] + 24 >> 2]](d, c + 4 | 0, e, 1, 0);
							b: {
								switch (y[c + 40 >> 2]) {
									case 0:
										a = y[c + 44 >> 2] == 1 ? y[c + 32 >> 2] == 1 ? y[c + 36 >> 2] == 1 ? y[c + 24 >> 2] : 0 : 0 : 0;
										break a;
									case 1: break b;
									default: break a;
								}
							}
							if (y[c + 28 >> 2] != 1) {
								if (y[c + 44 >> 2] | y[c + 32 >> 2] != 1 | y[c + 36 >> 2] != 1) {
									break a;
								}
							}
							a = y[c + 20 >> 2];
						}
						Y = c - -64 | 0;
						return a;
					}
					function _b(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						e = a + 4 | 0;
						d = e + 7 & -8;
						c = y[a >> 2];
						if (d + b >>> 0 <= (c + a | 0) - 4 >>> 0) {
							f = y[a + 4 >> 2];
							g = y[a + 8 >> 2];
							y[f + 8 >> 2] = g;
							y[g + 4 >> 2] = f;
							if ((d | 0) != (e | 0)) {
								d = d - e | 0;
								f = a - (y[a - 4 >> 2] & -2) | 0;
								e = d + y[f >> 2] | 0;
								y[f >> 2] = e;
								y[(f + (e & -4) | 0) - 4 >> 2] = e;
								a = a + d | 0;
								c = c - d | 0;
								y[a >> 2] = c;
							}
							a: {
								if (b + 24 >>> 0 <= c >>> 0) {
									e = a + b | 0;
									c = (c - b | 0) - 8 | 0;
									y[e + 8 >> 2] = c;
									g = e + 8 | 0;
									y[(g + (c & -4) | 0) - 4 >> 2] = c | 1;
									d = y[e + 8 >> 2] - 8 | 0;
									b: {
										if (d >>> 0 <= 127) {
											c = (d >>> 3 | 0) - 1 | 0;
											break b;
										}
										f = H(d);
										c = ((d >>> 29 - f ^ 4) - (f << 2) | 0) + 110 | 0;
										if (d >>> 0 <= 4095) {
											break b;
										}
										c = ((d >>> 30 - f ^ 2) - (f << 1) | 0) + 71 | 0;
										c = c >>> 0 >= 63 ? 63 : c;
									}
									d = c << 4;
									y[e + 12 >> 2] = d + 5728;
									d = d + 5736 | 0;
									y[e + 16 >> 2] = y[d >> 2];
									y[d >> 2] = g;
									y[y[e + 16 >> 2] + 4 >> 2] = g;
									d = y[1690];
									f = y[1691];
									e = c & 31;
									if ((c & 63) >>> 0 >= 32) {
										c = 1 << e;
										g = 0;
									} else {
										g = 1 << e;
										c = g - 1 & 1 >>> 32 - e;
									}
									y[1690] = g | d;
									y[1691] = c | f;
									c = b + 8 | 0;
									y[a >> 2] = c;
									b = (c & -4) + a | 0;
									break a;
								}
								b = a + c | 0;
							}
							y[b - 4 >> 2] = c;
							a = a + 4 | 0;
						} else {
							a = 0;
						}
						return a;
					}
					function ya(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0;
						g = Y - 16 | 0;
						Y = g;
						k = y[b + 44 >> 2];
						f = 1;
						while (1) {
							a: {
								b: {
									if (f >>> 0 > k >>> 0) {
										e = -1;
										break b;
									}
									e = -1;
									h = y[a >> 2];
									j = y[h + 8 >> 2];
									d = y[h >> 2];
									if (B[h + 4 >> 2] <= j >>> 0) {
										break b;
									}
									d = z[d + j | 0] >>> 7 - y[h + 12 >> 2] & 1;
									y[g + 12 >> 2] = d;
									Tb(h);
									if ((i | 0) < 0) {
										break b;
									}
									i = d | i << 1;
									if (B[b + 44 >> 2] < f >>> 0) {
										break a;
									}
									d = f << 2;
									e = y[d + y[b + 48 >> 2] >> 2];
									if (e >>> 0 > i >>> 0) {
										break a;
									}
									e = i - e | 0;
									if (e >>> 0 >= B[d + y[b + 60 >> 2] >> 2]) {
										break a;
									}
									d = y[(y[b + 84 >> 2] + (y[d + y[b + 72 >> 2] >> 2] << 2) | 0) + (e << 2) >> 2];
									e = 1;
									if (z[b + 1 | 0] == 1 & (d | 0) == (y[b + 4 >> 2] - 1 | 0)) {
										break b;
									}
									e = -1;
									f = y[a >> 2];
									a = d << 2;
									if ((Fa(f, y[a + y[b + 20 >> 2] >> 2], g + 12 | 0) | 0) == -1) {
										break b;
									}
									e = 0;
									f = y[a + y[b + 32 >> 2] >> 2];
									a = y[g + 12 >> 2];
									y[c >> 2] = f + ((d | 0) == (y[b + 4 >> 2] + (z[b + 1 | 0] ? -3 : -2) | 0) ? 0 - a | 0 : a);
								}
								Y = g + 16 | 0;
								return e;
							}
							f = f + 1 | 0;
							continue;
						}
					}
					function ma(a) {
						a = a | 0;
						var b = 0, c = 0, d = 0, e = 0, f = 0;
						if (a) {
							b = a - 4 | 0;
							f = y[b >> 2];
							c = f;
							d = b;
							e = y[a - 8 >> 2];
							a = e & -2;
							if ((a | 0) != (e | 0)) {
								d = b - a | 0;
								c = y[d + 4 >> 2];
								e = y[d + 8 >> 2];
								y[c + 8 >> 2] = e;
								y[e + 4 >> 2] = c;
								c = a + f | 0;
							}
							a = b + f | 0;
							b = y[a >> 2];
							if ((b | 0) != y[(a + b | 0) - 4 >> 2]) {
								f = y[a + 4 >> 2];
								a = y[a + 8 >> 2];
								y[f + 8 >> 2] = a;
								y[a + 4 >> 2] = f;
								c = b + c | 0;
							}
							y[d >> 2] = c;
							y[((c & -4) + d | 0) - 4 >> 2] = c | 1;
							b = y[d >> 2] - 8 | 0;
							a: {
								if (b >>> 0 <= 127) {
									a = (b >>> 3 | 0) - 1 | 0;
									break a;
								}
								c = H(b);
								a = ((b >>> 29 - c ^ 4) - (c << 2) | 0) + 110 | 0;
								if (b >>> 0 <= 4095) {
									break a;
								}
								a = ((b >>> 30 - c ^ 2) - (c << 1) | 0) + 71 | 0;
								a = a >>> 0 >= 63 ? 63 : a;
							}
							b = a << 4;
							y[d + 4 >> 2] = b + 5728;
							b = b + 5736 | 0;
							y[d + 8 >> 2] = y[b >> 2];
							y[b >> 2] = d;
							y[y[d + 8 >> 2] + 4 >> 2] = d;
							b = y[1690];
							c = y[1691];
							d = a & 31;
							if ((a & 63) >>> 0 >= 32) {
								a = 1 << d;
								e = 0;
							} else {
								e = 1 << d;
								a = e - 1 & 1 >>> 32 - d;
							}
							y[1690] = e | b;
							y[1691] = a | c;
						}
					}
					function fd(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						a: {
							b: {
								c = y[a + 4 >> 2];
								d = y[a >> 2];
								e = c - d | 0;
								f = e >> 3;
								c: {
									if (f >>> 0 < b >>> 0) {
										d = y[a + 8 >> 2] - d | 0;
										if (d >> 3 >>> 0 >= b >>> 0) {
											b = (b - f << 3) + c | 0;
											while (1) {
												if ((b | 0) != (c | 0)) {
													y[c >> 2] = 0;
													y[c + 4 >> 2] = 0;
													c = c + 8 | 0;
													continue;
												}
												break;
											}
											y[a + 4 >> 2] = b;
											return;
										}
										if (b >>> 0 >= 536870912) {
											break b;
										}
										c = d >> 2;
										d = d >>> 0 >= 2147483640 ? 536870911 : b >>> 0 < c >>> 0 ? c : b;
										if (d >>> 0 >= 536870912) {
											break a;
										}
										c = b - f << 3;
										g = na(d << 3);
										b = g + e | 0;
										f = c + b | 0;
										c = b;
										while (1) {
											if ((c | 0) != (f | 0)) {
												y[c >> 2] = 0;
												y[c + 4 >> 2] = 0;
												c = c + 8 | 0;
												continue;
											}
											break;
										}
										e = b;
										b = y[a >> 2];
										c = y[a + 4 >> 2] - b | 0;
										e = e - c | 0;
										if (c) {
											p(e, b, c);
										}
										y[a + 4 >> 2] = f;
										y[a >> 2] = e;
										y[a + 8 >> 2] = g + (d << 3);
										if (!b) {
											break c;
										}
										ma(b);
										return;
									}
									if (b >>> 0 >= f >>> 0) {
										break c;
									}
									y[a + 4 >> 2] = d + (b << 3);
								}
								return;
							}
							za();
							o();
						}
						Wa();
						o();
					}
					function Wb(a, b, c, d, e) {
						var f = 0, g = 0, h = 0;
						a: {
							b: {
								c: {
									if ((d | 0) < 0) {
										break c;
									}
									if ((c | 0) <= (d | 0)) {
										break a;
									}
									g = 0 - (e ^ 1) | 0;
									e = d & 7;
									if (e) {
										f = d >>> 3 | 0;
										if (f >>> 0 >= b >>> 0) {
											break c;
										}
										e = (z[a + f | 0] ^ g) & 255 >>> e;
										if (e) {
											break b;
										}
										d = d + 7 | 0;
									}
									e = d >>> 3 | 0;
									h = c + 7 >>> 3 | 0;
									while (1) {
										d = e;
										e = d + 4 | 0;
										if (h >>> 0 < e >>> 0) {
											e = g & 255;
											while (1) {
												if (d >>> 0 >= h >>> 0) {
													break a;
												}
												if (b >>> 0 <= d >>> 0) {
													break c;
												}
												f = z[a + d | 0];
												if ((f | 0) != (e | 0)) {
													a = H((f ^ g) << 24) | d << 3;
													return (a | 0) > (c | 0) ? c : a;
												} else {
													d = d + 1 | 0;
													continue;
												}
											}
										}
										if (b >>> 0 < d >>> 0 | b - d >>> 0 <= 3) {
											break c;
										}
										f = a + d | 0;
										f = z[f | 0] | z[f + 1 | 0] << 8 | (z[f + 2 | 0] << 16 | z[f + 3 | 0] << 24);
										f = ((Ae(f, 16) ^ f) & -16711936) >>> 8 ^ Ae(f, 8);
										if ((f | 0) == (g | 0)) {
											continue;
										}
										break;
									}
									a = H(f ^ g) + (d << 3) | 0;
									return (a | 0) > (c | 0) ? c : a;
								}
								o();
							}
							c = H(e << 24) | d & 2147483640;
						}
						return c;
					}
					function gb(a, b, c, d, e) {
						var f = 0, g = 0, h = 0;
						a: {
							d = (d | 0) > 0 ? d : 0;
							f = (e | 0) >= 0 ? (c | 0) < (e | 0) ? c : e : 0;
							if ((d | 0) >= (f | 0)) {
								break a;
							}
							b: {
								h = d >>> 3 | 0;
								if (h >>> 0 >= b >>> 0) {
									break b;
								}
								e = d & 7;
								c = a + h | 0;
								g = f - 1 | 0;
								f = g >>> 3 | 0;
								if ((f | 0) == (h | 0)) {
									a = g & 7;
									while (1) {
										if (a >>> 0 < e >>> 0) {
											break a;
										}
										w[c | 0] = z[c | 0] + (-128 >> e);
										e = e + 1 | 0;
										continue;
									}
								}
								d = z[c | 0];
								while (1) if ((e | 0) == 8) {
									w[c | 0] = d;
									if (b >>> 0 <= f >>> 0) {
										break b;
									}
									d = (g & 7) + 1 | 0;
									g = a + f | 0;
									c = z[g | 0];
									e = 0;
									while (1) if ((d | 0) == (e | 0)) {
										w[g | 0] = c;
										c = h + 1 | 0;
										if (c >>> 0 >= f >>> 0) {
											break a;
										}
										e = f + (h ^ -1) | 0;
										if (e >>> 0 > b - c >>> 0) {
											break b;
										}
										c = a + c | 0;
										while (1) {
											if ((e | 0) <= 0) {
												break a;
											}
											w[c | 0] = 0;
											e = e - 1 | 0;
											c = c + 1 | 0;
											continue;
										}
									} else {
										c = (-128 >> e) + c | 0;
										e = e + 1 | 0;
										continue;
									}
								} else {
									d = (-128 >> e) + d | 0;
									e = e + 1 | 0;
									continue;
								}
							}
							o();
						}
					}
					function zb(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						a: {
							b: {
								c = y[a + 4 >> 2];
								d = y[a >> 2];
								e = c - d | 0;
								f = e >> 2;
								c: {
									if (f >>> 0 < b >>> 0) {
										d = y[a + 8 >> 2] - d | 0;
										if (d >> 2 >>> 0 >= b >>> 0) {
											b = (b - f << 2) + c | 0;
											while (1) {
												if ((b | 0) != (c | 0)) {
													y[c >> 2] = 0;
													c = c + 4 | 0;
													continue;
												}
												break;
											}
											y[a + 4 >> 2] = b;
											return;
										}
										if (b >>> 0 >= 1073741824) {
											break b;
										}
										c = d >> 1;
										d = d >>> 0 >= 2147483644 ? 1073741823 : b >>> 0 < c >>> 0 ? c : b;
										if (d >>> 0 >= 1073741824) {
											break a;
										}
										c = b - f << 2;
										g = na(d << 2);
										b = g + e | 0;
										f = c + b | 0;
										c = b;
										while (1) {
											if ((c | 0) != (f | 0)) {
												y[c >> 2] = 0;
												c = c + 4 | 0;
												continue;
											}
											break;
										}
										e = b;
										b = y[a >> 2];
										c = y[a + 4 >> 2] - b | 0;
										e = e - c | 0;
										if (c) {
											p(e, b, c);
										}
										y[a + 4 >> 2] = f;
										y[a >> 2] = e;
										y[a + 8 >> 2] = g + (d << 2);
										if (!b) {
											break c;
										}
										ma(b);
										return;
									}
									if (b >>> 0 >= f >>> 0) {
										break c;
									}
									y[a + 4 >> 2] = d + (b << 2);
								}
								return;
							}
							za();
							o();
						}
						Wa();
						o();
					}
					function ka(a, b) {
						var c = 0, d = 0, e = 0, f = 0;
						c = z[b + 1 | 0];
						if (c >>> 0 < 47) {
							c = E(c, 6);
							e = A[c + 1808 >> 1];
							d = y[a + 8 >> 2] - e | 0;
							y[a + 8 >> 2] = d;
							c = c + 1808 | 0;
							f = y[a + 4 >> 2];
							a: {
								if (d >>> 0 > f >>> 16 >>> 0) {
									if (d & 32768) {
										return z[b | 0];
									}
									if (d >>> 0 < e >>> 0) {
										d = z[b | 0] ^ 1;
										e = z[c + 3 | 0];
										if (z[c + 4 | 0] == 1) {
											w[b | 0] = d & 1;
										}
										w[b + 1 | 0] = e;
										b = d & 1;
										break a;
									}
									w[b + 1 | 0] = z[c + 2 | 0];
									b = z[b | 0];
									break a;
								}
								y[a + 4 >> 2] = f - (d << 16);
								b: {
									if (d >>> 0 < e >>> 0) {
										w[b + 1 | 0] = z[c + 2 | 0];
										b = z[b | 0];
										break b;
									}
									d = z[b | 0] ^ 1;
									f = z[c + 3 | 0];
									if (z[c + 4 | 0] == 1) {
										w[b | 0] = d & 1;
									}
									w[b + 1 | 0] = f;
									b = d & 1;
								}
								y[a + 8 >> 2] = e;
							}
							c = y[a + 12 >> 2];
							while (1) {
								if (!c) {
									Ec(a);
									c = y[a + 12 >> 2];
								}
								c = c - 1 | 0;
								y[a + 12 >> 2] = c;
								d = y[a + 8 >> 2];
								y[a + 8 >> 2] = d << 1;
								y[a + 4 >> 2] = y[a + 4 >> 2] << 1;
								if (!(d & 16384)) {
									continue;
								}
								break;
							}
							return b;
						}
						o();
					}
					function tc(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0, l = 0;
						e = Y - 32 | 0;
						Y = e;
						x[a >> 1] = 0;
						t(a + 4 | 0, 0, 92);
						y[e + 28 >> 2] = 0;
						y[e + 20 >> 2] = 0;
						y[e + 24 >> 2] = 0;
						a: {
							b: {
								d = c + 2 | 0;
								if (d) {
									if (d >>> 0 >= 536870912) {
										break b;
									}
									d = d << 3;
									f = na(d);
									y[e + 20 >> 2] = f;
									g = d + f | 0;
									y[e + 28 >> 2] = g;
									d = f;
									while (1) {
										if ((d | 0) != (g | 0)) {
											y[d >> 2] = 0;
											y[d + 4 >> 2] = 0;
											d = d + 8 | 0;
											continue;
										}
										break;
									}
									y[e + 24 >> 2] = g;
								}
								i = b + c | 0;
								d = 0;
								while (1) {
									if ((b | 0) == (i | 0)) {
										break a;
									}
									j = z[b | 0];
									h = (d << 3) + f | 0;
									y[h + 4 >> 2] = d;
									w[h + 1 | 0] = 0;
									w[h | 0] = j;
									b = b + 1 | 0;
									d = d + 1 | 0;
									continue;
								}
							}
							za();
							o();
						}
						b = (c << 3) + f | 0;
						y[b + 4 >> 2] = 0;
						x[b >> 1] = 0;
						y[b + 12 >> 2] = 0;
						x[b + 8 >> 1] = 0;
						y[e + 16 >> 2] = g - f >> 3;
						y[e + 12 >> 2] = f;
						w[e + 8 | 0] = 0;
						k = a, l = gd(a, e + 8 | 0), w[k | 0] = l;
						va(e + 20 | 0);
						Y = e + 32 | 0;
						return a;
					}
					function _d(a, b, c, d, e) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						a: {
							if (Pa(a, y[b + 8 >> 2], e)) {
								if (y[b + 28 >> 2] == 1 | y[b + 4 >> 2] != (c | 0)) {
									break a;
								}
								y[b + 28 >> 2] = d;
								return;
							}
							if (Pa(a, y[b >> 2], e)) {
								if (!(y[b + 16 >> 2] != (c | 0) & y[b + 20 >> 2] != (c | 0))) {
									if ((d | 0) != 1) {
										break a;
									}
									y[b + 32 >> 2] = 1;
									return;
								}
								y[b + 32 >> 2] = d;
								b: {
									if (y[b + 44 >> 2] == 4) {
										break b;
									}
									x[b + 52 >> 1] = 0;
									a = y[a + 8 >> 2];
									_[y[y[a >> 2] + 20 >> 2]](a, b, c, c, 1, e);
									if (z[b + 53 | 0] == 1) {
										y[b + 44 >> 2] = 3;
										if (!z[b + 52 | 0]) {
											break b;
										}
										break a;
									}
									y[b + 44 >> 2] = 4;
								}
								y[b + 20 >> 2] = c;
								y[b + 40 >> 2] = y[b + 40 >> 2] + 1;
								if (y[b + 36 >> 2] != 1 | y[b + 24 >> 2] != 2) {
									break a;
								}
								w[b + 54 | 0] = 1;
								return;
							}
							a = y[a + 8 >> 2];
							_[y[y[a >> 2] + 24 >> 2]](a, b, c, d, e);
						}
					}
					function Yb(a, b, c, d, e, f) {
						var g = 0, h = 0, i = 0, j = 0, k = 0, l = 0;
						l = ((e & 536870911) << 3 | d >>> 29) & -8;
						a: {
							b: {
								c: while (1) {
									d: {
										if (c >>> 0 <= g >>> 0) {
											break d;
										}
										j = z[b + g | 0];
										if ((j | 0) == 255) {
											break b;
										}
										h = y[f >> 2];
										if (h >>> 0 >= l >>> 0) {
											break b;
										}
										i = h >>> 3 | 0;
										if (i >>> 0 >= e >>> 0) {
											break d;
										}
										i = z[d + i | 0];
										y[f >> 2] = h + 1;
										k = k << 1 | (i << (h & 7) & 128) >>> 7;
										g = g + 1 | 0;
										h = g + E(j, 3) | 0;
										while (1) {
											if ((g | 0) >= (h | 0)) {
												continue c;
											}
											if (c >>> 0 <= g >>> 0) {
												break d;
											}
											if (z[b + g | 0] == (k | 0)) {
												d = g + 1 | 0;
												if (d >>> 0 >= c >>> 0) {
													break d;
												}
												e = c;
												c = g + 2 | 0;
												if (e >>> 0 <= c >>> 0) {
													break d;
												}
												x[a >> 1] = z[b + d | 0] | z[b + c | 0] << 8;
												b = 1;
												break a;
											} else {
												g = g + 3 | 0;
												continue;
											}
										}
									}
									break;
								}
								o();
							}
							w[a | 0] = 0;
							b = 0;
						}
						w[a + 2 | 0] = b;
					}
					function Wc(a, b, c, d, e, f, g) {
						y[a + 8 >> 2] = 0;
						a: {
							b: {
								if (!(b & 255)) {
									c: {
										switch (c | 0) {
											case 1:
												y[a + 4 >> 2] = e;
												y[a >> 2] = d;
												y[a + 8 >> 2] = f - 1;
												return;
											case 3:
												y[a + 4 >> 2] = e;
												break a;
											case 0:
												y[a >> 2] = d;
												y[a + 8 >> 2] = f - 1;
												y[a + 4 >> 2] = (e - g | 0) + 1;
												return;
											case 2: break c;
											default: break b;
										}
									}
									y[a + 4 >> 2] = (e - g | 0) + 1;
									break a;
								}
								d: {
									switch (c | 0) {
										case 1:
											y[a + 4 >> 2] = d;
											y[a >> 2] = e;
											y[a + 8 >> 2] = g - 1;
											return;
										case 3:
											y[a + 4 >> 2] = d;
											y[a + 8 >> 2] = g - 1;
											y[a >> 2] = (e - f | 0) + 1;
											return;
										case 0:
											y[a >> 2] = e;
											y[a + 4 >> 2] = (d - g | 0) + 1;
											return;
										case 2: break d;
										default: break b;
									}
								}
								y[a + 4 >> 2] = (d - g | 0) + 1;
								y[a >> 2] = (e - f | 0) + 1;
							}
							return;
						}
						y[a >> 2] = (d - f | 0) + 1;
					}
					function fb(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0;
						a: {
							c = y[a + 4 >> 2];
							d = y[a >> 2];
							e = c - d | 0;
							f = e >> 1;
							if (f >>> 0 < b >>> 0) {
								g = y[a + 8 >> 2];
								if (g - d >> 1 >>> 0 >= b >>> 0) {
									b = (b - f << 1) + c | 0;
									while (1) {
										if ((b | 0) != (c | 0)) {
											w[c | 0] = 0;
											w[c + 1 | 0] = 0;
											c = c + 2 | 0;
											continue;
										}
										break;
									}
									y[a + 4 >> 2] = b;
									return;
								}
								d = Cc(d, g, b);
								if (d) {
									h = Bc(d);
								}
								c = b - f << 1;
								b = e + h | 0;
								f = c + b | 0;
								c = b;
								while (1) {
									if ((c | 0) != (f | 0)) {
										w[c | 0] = 0;
										w[c + 1 | 0] = 0;
										c = c + 2 | 0;
										continue;
									}
									break;
								}
								e = b;
								b = y[a >> 2];
								c = y[a + 4 >> 2] - b | 0;
								e = e - c | 0;
								if (c) {
									p(e, b, c);
								}
								y[a + 4 >> 2] = f;
								y[a >> 2] = e;
								y[a + 8 >> 2] = (d << 1) + h;
								if (!b) {
									break a;
								}
								ma(b);
								return;
							}
							if (b >>> 0 >= f >>> 0) {
								break a;
							}
							y[a + 4 >> 2] = d + (b << 1);
						}
					}
					function sd(a, b, c) {
						var d = 0, e = 0;
						d = Y - 32 | 0;
						Y = d;
						y[a + 24 >> 2] = 0;
						y[a + 28 >> 2] = 0;
						y[a + 16 >> 2] = 0;
						y[a + 20 >> 2] = 0;
						y[a + 8 >> 2] = 0;
						y[a + 12 >> 2] = 0;
						y[a >> 2] = 0;
						y[a + 4 >> 2] = 0;
						a: {
							b: {
								if (b - 2147483617 >>> 0 < 2147483680 | (c | 0) <= 0) {
									break b;
								}
								e = b + 31 & 2147483616;
								if (2147483616 / (e >>> 0) >>> 0 < c >>> 0) {
									break b;
								}
								y[a + 24 >> 2] = c;
								y[a + 20 >> 2] = b;
								b = e >>> 3 | 0;
								y[a + 28 >> 2] = b;
								b = ze(c, 0, b, 0);
								if (Z) {
									break a;
								}
								b = Gb(d, b);
								c = y[b >> 2];
								y[d + 12 >> 2] = c;
								e = y[b + 4 >> 2];
								y[d + 16 >> 2] = e;
								y[d + 20 >> 2] = y[b + 8 >> 2];
								y[b + 8 >> 2] = 0;
								y[b >> 2] = 0;
								y[b + 4 >> 2] = 0;
								y[d + 28 >> 2] = e - c;
								y[d + 24 >> 2] = c;
								c = d + 12 | 0;
								ec(a, c);
								va(c);
								va(b);
							}
							Y = d + 32 | 0;
							return a;
						}
						o();
					}
					function Fa(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0;
						e = -1;
						g = y[a >> 2];
						a: {
							f = y[a + 8 >> 2];
							d = y[a + 4 >> 2];
							if (f >>> 0 >= d >>> 0) {
								break a;
							}
							b: {
								if ((d | 0) == 536870912 | d >>> 0 > 536870912) {
									break b;
								}
								f = y[a + 12 >> 2] + (f << 3) | 0;
								if (f >>> 0 > (((d & 536870911) << 3 | g >>> 29) & -8) >>> 0) {
									break a;
								}
								y[c >> 2] = 0;
								g = y[a >> 2];
								d = y[a + 4 >> 2];
								if ((d | 0) == 536870912 | d >>> 0 > 536870912) {
									break b;
								}
								d = ((d & 536870911) << 3 | g >>> 29) & -8;
								e = d >>> 0 < b + f >>> 0 ? d - f | 0 : b;
								while (1) {
									if (!e) {
										e = 0;
										break a;
									}
									b = y[a + 8 >> 2];
									if (b >>> 0 >= B[a + 4 >> 2]) {
										break b;
									}
									y[c >> 2] = z[b + y[a >> 2] | 0] >>> 7 - y[a + 12 >> 2] & 1 | y[c >> 2] << 1;
									Tb(a);
									e = e - 1 | 0;
									continue;
								}
							}
							o();
						}
						return e;
					}
					function Aa(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, j = 0, k = 0;
						f = Y - 16 | 0;
						Y = f;
						i = ka(b, y[a >> 2] + 2 | 0);
						d = i | 2;
						while (1) {
							a: {
								if ((e | 0) == 5) {
									e = 5;
									break a;
								}
								d = d << 1;
								g = ka(b, d + y[a >> 2] | 0);
								d = d | g;
								if (!g) {
									break a;
								}
								e = e + 1 | 0;
								continue;
							}
							break;
						}
						g = 0;
						e = e << 3;
						h = y[e + 2092 >> 2];
						h = (h | 0) > 0 ? h : 0;
						k = e + 2092 | 0;
						e = 0;
						while (1) {
							if ((e | 0) != (h | 0)) {
								d = d << 1;
								j = ka(b, d + y[a >> 2] | 0);
								d = j | d;
								d = (d | 0) > 255 ? d & 255 | 256 : d;
								g = g << 1 | j;
								e = e + 1 | 0;
								continue;
							}
							break;
						}
						w[f + 8 | 0] = 1;
						y[f + 12 >> 2] = y[k + 4 >> 2];
						e = 0;
						d = 0;
						if (z[La(f + 8 | 0, g) | 0]) {
							a = y[f + 12 >> 2];
							b = a >> 31;
							e = i ? b - (a ^ b) | 0 : a;
							d = !i | (e | 0) != 0;
						}
						y[c >> 2] = e;
						Y = f + 16 | 0;
						return d;
					}
					function zc(a, b, c, d, e) {
						var f = 0, g = 0;
						y[a >> 2] = 0;
						f = na(24);
						y[f + 8 >> 2] = 0;
						y[f + 12 >> 2] = 0;
						g = b;
						b = (c | 0) == 268435456 | c >>> 0 < 268435456;
						y[f >> 2] = b ? g : 0;
						y[f + 4 >> 2] = b ? c : 0;
						y[f + 16 >> 2] = 0;
						y[f + 20 >> 2] = 0;
						y[a + 8 >> 2] = 0;
						y[a + 12 >> 2] = 0;
						y[a + 4 >> 2] = f;
						y[a + 16 >> 2] = 0;
						y[a + 20 >> 2] = 0;
						y[a + 24 >> 2] = 0;
						y[a + 28 >> 2] = 0;
						y[a + 32 >> 2] = 0;
						c = na(64);
						y[a + 36 >> 2] = c;
						b = c - -64 | 0;
						y[a + 44 >> 2] = b;
						f = 0;
						while (1) {
							if ((f | 0) != 64) {
								y[c + f >> 2] = 0;
								f = f + 4 | 0;
								continue;
							}
							break;
						}
						y[a + 52 >> 2] = 10;
						w[a + 49 | 0] = 0;
						w[a + 50 | 0] = 0;
						w[a + 48 | 0] = e;
						y[a + 40 >> 2] = b;
						t(a + 56 | 0, 0, 49);
						w[a + 112 | 0] = 0;
						y[a + 108 >> 2] = d;
						return a;
					}
					function Ob(a, b) {
						var c = 0, d = 0, e = 0, f = 0;
						e = Y - 16 | 0;
						Y = e;
						c = 4;
						a: {
							b: {
								if (y[a + 4 >> 2] - 1 >>> 0 > 65534 | y[a + 8 >> 2] - 1 >>> 0 >= 65535) {
									break b;
								}
								y[a + 52 >> 2] = 2;
								f = y[b >> 2];
								d = y[f >> 2];
								if (!d) {
									c = ua(a + 4 | 0, a + 8 | 0);
									y[e + 12 >> 2] = 0;
									oa(f, c);
									la(e + 12 | 0);
									d = y[f >> 2];
								}
								c = y[d + 16 >> 2];
								if (!c) {
									oa(f, 0);
									c = -1;
									break b;
								}
								d = y[d + 12 >> 2];
								while (1) {
									if ((c | 0) > 0) {
										w[d | 0] = 0;
										c = c - 1 | 0;
										d = d + 1 | 0;
										continue;
									}
									break;
								}
								y[a + 60 >> 2] = 0;
								x[a + 56 >> 1] = 1;
								y[a + 24 >> 2] = 0;
								y[a + 28 >> 2] = 0;
								y[a + 32 >> 2] = 0;
								y[a + 36 >> 2] = 0;
								y[a + 40 >> 2] = 0;
								y[a + 44 >> 2] = 0;
								y[a + 48 >> 2] = 0;
								c = nd(a, b);
								break a;
							}
							y[a + 52 >> 2] = c;
						}
						Y = e + 16 | 0;
						return c;
					}
					function _c(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0;
						a: {
							c = y[a + 4 >> 2];
							d = y[a + 8 >> 2];
							b: {
								if (c >>> 0 < d >>> 0) {
									e = y[b >> 2];
									y[b >> 2] = 0;
									y[c >> 2] = e;
									b = c + 4 | 0;
									break b;
								}
								f = y[a >> 2];
								e = c - f | 0;
								h = e >> 2;
								c = h + 1 | 0;
								if (c >>> 0 >= 1073741824) {
									break a;
								}
								d = d - f | 0;
								g = d >> 1;
								g = d >>> 0 >= 2147483644 ? 1073741823 : c >>> 0 < g >>> 0 ? g : c;
								c: {
									if (!g) {
										c = e;
										d = 0;
										break c;
									}
									d = Fb(g);
									f = y[a >> 2];
									c = y[a + 4 >> 2] - f | 0;
									h = c >> 2;
								}
								i = y[b >> 2];
								y[b >> 2] = 0;
								b = d + e | 0;
								y[b >> 2] = i;
								e = b - (h << 2) | 0;
								if (c) {
									p(e, f, c);
								}
								y[a + 8 >> 2] = (g << 2) + d;
								b = b + 4 | 0;
								y[a + 4 >> 2] = b;
								y[a >> 2] = e;
								if (!f) {
									break b;
								}
								ma(f);
							}
							y[a + 4 >> 2] = b;
							return;
						}
						za();
						o();
					}
					function rb(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							Vb(c + 80 | 0);
							ta(c + 76 | 0);
							ta(c + 72 | 0);
							Ha(c + 60 | 0);
							b = y[c + 36 >> 2];
							if (b) {
								a = y[c + 40 >> 2];
								while (1) {
									if ((a | 0) != (b | 0)) {
										a = pa(a - 4 | 0);
										continue;
									}
									break;
								}
								y[c + 40 >> 2] = b;
								ma(y[c + 36 >> 2]);
							}
							la(c + 32 | 0);
							b = y[c + 20 >> 2];
							if (b) {
								a = y[c + 24 >> 2];
								while (1) {
									if ((a | 0) != (b | 0)) {
										a = Ub(a - 4 | 0);
										continue;
									}
									break;
								}
								y[c + 24 >> 2] = b;
								ma(y[c + 20 >> 2]);
							}
							b = y[c + 8 >> 2];
							if (b) {
								a = y[c + 12 >> 2];
								while (1) {
									if ((a | 0) != (b | 0)) {
										a = Vb(a - 4 | 0);
										continue;
									}
									break;
								}
								y[c + 12 >> 2] = b;
								ma(y[c + 8 >> 2]);
							}
							a = y[c + 4 >> 2];
							y[c + 4 >> 2] = 0;
							if (a) {
								ma(a);
							}
							ma(sb(c));
						}
					}
					function xd(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0;
						d = Y - 16 | 0;
						Y = d;
						a: {
							e = y[a + 4 >> 2];
							b: {
								if (e >>> 0 > b >>> 0) {
									break b;
								}
								c = e;
								if (y[a + 8 >> 2] << 5 >>> 0 < b >>> 0) {
									if ((b | 0) < 0) {
										break a;
									}
									f = (b - 1 >>> 5 | 0) + 1 | 0;
									g = na(f << 2);
									h = y[a >> 2];
									c = y[a + 4 >> 2];
									i = c ? (c - 1 >>> 3 & 536870908) + 4 | 0 : 0;
									if (i) {
										p(g, h, i);
									}
									y[a >> 2] = g;
									y[d + 4 >> 2] = h;
									y[a + 4 >> 2] = c;
									y[d + 8 >> 2] = c;
									c = y[a + 8 >> 2];
									y[a + 8 >> 2] = f;
									y[d + 12 >> 2] = c;
									lc(d + 4 | 0);
									c = y[a + 4 >> 2];
								}
								if ((b | 0) == (e | 0)) {
									break b;
								}
								$c(y[a >> 2] + (c >>> 3 & 536870908) | 0, c & 31, b - e | 0);
							}
							y[a + 4 >> 2] = b;
							Y = d + 16 | 0;
							return;
						}
						za();
						o();
					}
					function Hc(a, b, c, d, e, f) {
						var g = 0, h = 0, i = 0, j = 0, k = 0, l = 0, m = 0, n = 0, o = 0;
						h = Y - 16 | 0;
						Y = h;
						l = ((b & 536870911) << 3 | a >>> 29) & -8;
						j = 1;
						while (1) {
							a: {
								if (B[c >> 2] >= l >>> 0) {
									break a;
								}
								k = j & 1;
								n = k ? 325 : 326;
								o = k ? 1056 : 1392;
								i = 0;
								while (1) {
									Yb(h + 12 | 0, o, n, a, b, c);
									if (!z[h + 14 | 0]) {
										while (1) {
											if (B[c >> 2] >= l >>> 0) {
												break a;
											}
											if (!Ia(a, b, c)) {
												continue;
											}
											break;
										}
										break a;
									}
									g = A[h + 12 >> 1];
									i = g + i | 0;
									if ((i | 0) > (f | 0)) {
										break a;
									}
									if (g >>> 0 >= 64) {
										continue;
									}
									break;
								}
								g = i + m | 0;
								if (!k) {
									gb(d, e, f, m, g);
								}
								j = j ^ 1;
								m = g;
								if ((f | 0) > (g | 0)) {
									continue;
								}
							}
							break;
						}
						Y = h + 16 | 0;
					}
					function te(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						e = y[y[b >> 2] >> 2];
						if (!y[a + 48 >> 2]) {
							c = y[e + 16 >> 2];
							y[a + 44 >> 2] = y[e + 12 >> 2];
							y[a + 48 >> 2] = c;
						}
						c = y[a + 4 >> 2];
						if (c) {
							c = c - 1 | 0;
							f = c >>> 3 | 0;
							g = (c & 7) + 1 | 0;
							c = y[a + 24 >> 2];
							while (1) {
								a: {
									if (B[a + 8 >> 2] <= c >>> 0) {
										b = 4;
									} else {
										if (!jc(a, b, 2204, f, g)) {
											return -1;
										}
										Db(a, e);
										d = y[b + 16 >> 2];
										c = y[a + 24 >> 2];
										if (!d | (c >>> 0) % 50) {
											break a;
										}
										d = _[y[y[d >> 2] + 8 >> 2]](d) | 0;
										c = y[a + 24 >> 2];
										if (!d) {
											break a;
										}
										y[a + 24 >> 2] = c + 1;
										b = 3;
									}
									y[a + 52 >> 2] = b;
									return b | 0;
								}
								c = c + 1 | 0;
								y[a + 24 >> 2] = c;
								continue;
							}
						}
						o();
					}
					function xe(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						d = y[y[b >> 2] >> 2];
						if (!y[a + 48 >> 2]) {
							c = y[d + 16 >> 2];
							y[a + 44 >> 2] = y[d + 12 >> 2];
							y[a + 48 >> 2] = c;
						}
						c = y[a + 4 >> 2];
						if (c) {
							e = y[a + 8 >> 2] & 2147483647;
							c = c - 1 | 0;
							f = c >>> 3 | 0;
							g = (c & 7) + 1 | 0;
							c = y[a + 24 >> 2];
							while (1) {
								a: {
									if (c >>> 0 >= e >>> 0) {
										b = 4;
									} else {
										if (!jc(a, b, 2140, f, g)) {
											return -1;
										}
										Db(a, d);
										c = y[b + 16 >> 2];
										if (!c) {
											break a;
										}
										if (!(_[y[y[c >> 2] + 8 >> 2]](c) | 0)) {
											break a;
										}
										y[a + 24 >> 2] = y[a + 24 >> 2] + 1;
										b = 3;
									}
									y[a + 52 >> 2] = b;
									return b | 0;
								}
								c = y[a + 24 >> 2] + 1 | 0;
								y[a + 24 >> 2] = c;
								continue;
							}
						}
						o();
					}
					function Xd(a, b, c) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						var d = 0, e = 0;
						if (y[b + 4 >> 2] == 5252) {
							b = y[a + 12 >> 2];
							a: {
								if (b) {
									a = 5240;
									if (tb(b, 5128)) {
										break a;
									}
								}
								a = 5248;
							}
							y[c >> 2] = a;
							return 1;
						}
						e = y[a + 8 >> 2];
						b: {
							c: {
								if (!(e & 24)) {
									d = tb(b, 5080);
									if (!d) {
										break c;
									}
									c = 1;
									if (!Pa(a, b, (y[d + 8 >> 2] & 24) != 0)) {
										break c;
									}
									break b;
								}
								c = 1;
								if (Pa(a, b, 1)) {
									break b;
								}
							}
							c = 0;
							b = tb(b, 5180);
							if (!b) {
								break b;
							}
							d = y[b + 8 >> 2];
							if (d & (e ^ -1) & 7 | (d ^ -1) & e & 96 | y[y[a + 12 >> 2] + 4 >> 2] != y[y[b + 12 >> 2] + 4 >> 2]) {
								break b;
							}
							c = y[y[a + 16 >> 2] + 4 >> 2] == y[y[b + 16 >> 2] + 4 >> 2];
						}
						return c | 0;
					}
					function za() {
						var a = 0, b = 0, c = 0, d = 0;
						c = vb(8);
						y[c >> 2] = 5476;
						a = 4523;
						b = 0;
						a: {
							if (!z[4523]) {
								break a;
							}
							b: {
								c: {
									while (1) {
										a = a + 1 | 0;
										if (!(a & 3)) {
											break c;
										}
										if (z[a | 0]) {
											continue;
										}
										break;
									}
									break b;
								}
								while (1) {
									b = a;
									a = a + 4 | 0;
									d = y[b >> 2];
									if (((16843008 - d | d) & -2139062144) == -2139062144) {
										continue;
									}
									break;
								}
								while (1) {
									a = b;
									b = a + 1 | 0;
									if (z[a | 0]) {
										continue;
									}
									break;
								}
							}
							b = a - 4523 | 0;
						}
						a = na(b + 13 | 0);
						y[a + 8 >> 2] = 0;
						y[a + 4 >> 2] = b;
						y[a >> 2] = b;
						a = a + 12 | 0;
						b = b + 1 | 0;
						if (b) {
							p(a, 4523, b);
						}
						y[c >> 2] = 5524;
						y[c + 4 >> 2] = a;
						P(c | 0, 5536, 1);
						o();
					}
					function ve(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0, d = 0, e = 0, f = 0;
						d = y[y[b >> 2] >> 2];
						if (!y[a + 48 >> 2]) {
							c = y[d + 16 >> 2];
							y[a + 44 >> 2] = y[d + 12 >> 2];
							y[a + 48 >> 2] = c;
						}
						c = y[a + 4 >> 2];
						if (c) {
							c = c - 1 | 0;
							e = c >>> 3 | 0;
							f = (c & 7) + 1 | 0;
							c = y[a + 24 >> 2];
							while (1) {
								a: {
									if (B[a + 8 >> 2] <= c >>> 0) {
										b = 4;
									} else {
										if (!jc(a, b, 2172, e, f)) {
											return -1;
										}
										Db(a, d);
										c = y[b + 16 >> 2];
										if (!c) {
											break a;
										}
										if (!(_[y[y[c >> 2] + 8 >> 2]](c) | 0)) {
											break a;
										}
										y[a + 24 >> 2] = y[a + 24 >> 2] + 1;
										b = 3;
									}
									y[a + 52 >> 2] = b;
									return b | 0;
								}
								c = y[a + 24 >> 2] + 1 | 0;
								y[a + 24 >> 2] = c;
								continue;
							}
						}
						o();
					}
					function Ec(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0;
						e = 255;
						b = y[a + 16 >> 2];
						a: {
							if (z[a + 1 | 0] == 255) {
								f = 8;
								d = y[b + 8 >> 2];
								c = d + 1 | 0;
								if (c >>> 0 >= B[b + 4 >> 2]) {
									break a;
								}
								c = z[c + y[b >> 2] | 0];
								if (c >>> 0 > 143) {
									break a;
								}
								Dc(b);
								w[a + 1 | 0] = c;
								y[a + 4 >> 2] = (y[a + 4 >> 2] - (c << 9) | 0) + 65024;
								b = y[a + 16 >> 2];
								d = y[b + 8 >> 2];
								f = 7;
								break a;
							}
							Dc(b);
							f = 8;
							b = y[a + 16 >> 2];
							d = y[b + 8 >> 2];
							c = y[b >> 2];
							e = B[b + 4 >> 2] > d >>> 0 ? z[c + d | 0] : e;
							w[a + 1 | 0] = e;
							y[a + 4 >> 2] = (y[a + 4 >> 2] - (e << 8) | 0) + 65280;
						}
						y[a + 12 >> 2] = f;
						if (B[b + 4 >> 2] <= d >>> 0) {
							w[a | 0] = 1;
						}
					}
					function Jb(a, b) {
						var c = 0, d = 0, e = 0, f = 0;
						a: {
							b: {
								if ((a | 0) != (b | 0)) {
									f = y[b + 4 >> 2];
									d = y[b >> 2];
									b = f - d | 0;
									c = y[a >> 2];
									if (b >>> 0 <= y[a + 8 >> 2] - c >>> 0) {
										e = y[a + 4 >> 2] - c | 0;
										if (e >>> 0 < b >>> 0) {
											if (e) {
												p(c, d, e);
											}
											b = y[a + 4 >> 2];
											d = d + e | 0;
											c = f - d | 0;
											if (c) {
												p(b, d, c);
											}
											break a;
										}
										if (b) {
											p(c, d, b);
										}
										break a;
									}
									kc(a);
									e = Cc(y[a >> 2], y[a + 8 >> 2], b >> 1);
									if ((e | 0) < 0) {
										break b;
									}
									c = Bc(e);
									y[a + 4 >> 2] = c;
									y[a >> 2] = c;
									y[a + 8 >> 2] = c + (e << 1);
									if (b) {
										p(c, d, b);
									}
									y[a + 4 >> 2] = b + c;
								}
								return a;
							}
							za();
							o();
						}
						y[a + 4 >> 2] = b + c;
						return a;
					}
					function Bb(a, b, c, d) {
						var e = 0, f = 0, g = 0, h = 0, i = 0;
						f = b - 1 | 0;
						g = y[d >> 2];
						e = y[d + 4 >> 2];
						a: {
							if ((ia(a, f, g, e) | 0) != (c | 0)) {
								break a;
							}
							if ((ia(a, b, g, e) | 0) != (c | 0)) {
								break a;
							}
							h = b + 1 | 0;
							if ((ia(a, h, g, e) | 0) != (c | 0)) {
								break a;
							}
							g = y[d + 8 >> 2];
							e = y[d + 12 >> 2];
							if ((ia(a, f, g, e) | 0) != (c | 0)) {
								break a;
							}
							if ((ia(a, h, g, e) | 0) != (c | 0)) {
								break a;
							}
							e = f;
							f = y[d + 16 >> 2];
							d = y[d + 20 >> 2];
							if ((ia(a, e, f, d) | 0) != (c | 0)) {
								break a;
							}
							if ((ia(a, b, f, d) | 0) != (c | 0)) {
								break a;
							}
							i = (ia(a, h, f, d) | 0) == (c | 0);
						}
						return i;
					}
					function Rb(a, b) {
						var c = 0, d = 0, e = 0, f = 0, g = 0;
						a: {
							c = y[a >> 2];
							d = y[a + 4 >> 2] - c | 0;
							e = d >> 2;
							if (e >>> 0 < b >>> 0) {
								f = y[a + 8 >> 2];
								if (f - c >> 2 >>> 0 >= b >>> 0) {
									qd(a, b - e | 0);
									return;
								}
								f = pd(c, f, b);
								g = Fb(f);
								c = d + g | 0;
								e = c + (b - e << 2) | 0;
								b = c;
								while (1) {
									if ((b | 0) != (e | 0)) {
										y[b >> 2] = 0;
										b = b + 4 | 0;
										continue;
									}
									break;
								}
								d = c;
								b = y[a >> 2];
								c = y[a + 4 >> 2] - b | 0;
								d = d - c | 0;
								if (c) {
									p(d, b, c);
								}
								y[a + 4 >> 2] = e;
								y[a >> 2] = d;
								y[a + 8 >> 2] = (f << 2) + g;
								if (!b) {
									break a;
								}
								ma(b);
								return;
							}
							if (b >>> 0 >= e >>> 0) {
								break a;
							}
							y[a + 4 >> 2] = c + (b << 2);
						}
					}
					function hd(a, b, c, d, e, f, g, h, i, j) {
						var k = 0, l = 0;
						Ea(y[b + 20 >> 2], d, i, j, e);
						i = y[a + 12 >> 2];
						j = y[c >> 2];
						b = ia(y[b + 20 >> 2], d + 2 | 0, g, h);
						y[c + 4 >> 2] = e;
						y[c >> 2] = b | j << 1 & 2;
						e = y[c + 8 >> 2];
						a = y[a + 20 >> 2];
						b = (d - i | 0) + 2 | 0;
						k = c, l = ia(y[a + 20 >> 2], b, y[f >> 2], y[f + 4 >> 2]) | e << 1 & 2, y[k + 8 >> 2] = l;
						d = y[c + 12 >> 2];
						k = c, l = ia(y[a + 20 >> 2], b, y[f + 8 >> 2], y[f + 12 >> 2]) | d << 1 & 6, y[k + 12 >> 2] = l;
						d = y[c + 16 >> 2];
						k = c, l = ia(y[a + 20 >> 2], b, y[f + 16 >> 2], y[f + 20 >> 2]) | d << 1 & 6, y[k + 16 >> 2] = l;
					}
					function mc(a) {
						var b = 0, c = 0, d = 0, e = 0;
						e = Y - 16 | 0;
						Y = e;
						b = na(32);
						y[b + 8 >> 2] = 0;
						y[b >> 2] = 0;
						y[b + 4 >> 2] = 0;
						c = y[a + 4 >> 2];
						d = y[a >> 2];
						y[e + 8 >> 2] = b;
						if ((c | 0) != (d | 0)) {
							Eb(b, c - d | 0);
							Xb(b, d, c);
						}
						w[e + 12 | 0] = 1;
						gc(e + 8 | 0);
						c = y[b >> 2];
						d = y[b + 4 >> 2];
						a: {
							if ((c | 0) != (d | 0)) {
								y[b + 12 >> 2] = c;
								y[b + 16 >> 2] = d - c;
								break a;
							}
							c = y[a + 16 >> 2];
							y[b + 12 >> 2] = y[a + 12 >> 2];
							y[b + 16 >> 2] = c;
						}
						y[b + 20 >> 2] = y[a + 20 >> 2];
						y[b + 24 >> 2] = y[a + 24 >> 2];
						y[b + 28 >> 2] = y[a + 28 >> 2];
						Y = e + 16 | 0;
						return b;
					}
					function Gc(a, b, c, d, e, f) {
						var g = 0, h = 0, i = 0, j = 0, k = 0;
						i = y[a + 4 >> 2];
						a: {
							b: {
								c: {
									if ((c | 0) < 0) {
										h = y[a >> 2];
										a = 1;
										break c;
									}
									g = c >>> 3 | 0;
									if (g >>> 0 >= i >>> 0) {
										break b;
									}
									h = y[a >> 2];
									a = (z[g + h | 0] << (c & 7) & 128) >>> 7 | 0;
								}
								g = a ^ 1;
								c = Wb(h, i, b, c + 1 | 0, g);
								y[e >> 2] = c;
								if ((b | 0) <= (c | 0)) {
									break a;
								}
								d: {
									if ((a | 0) == (d | 0)) {
										g = a;
										break d;
									}
									c = Wb(h, i, b, c + 1 | 0, a);
									y[e >> 2] = c;
								}
								if ((b | 0) <= (c | 0)) {
									break a;
								}
								j = f, k = Wb(h, i, b, c + 1 | 0, g), y[j >> 2] = k;
								return;
							}
							o();
						}
						y[f >> 2] = b;
						y[e >> 2] = b;
					}
					function Id(a, b) {
						var c = 0;
						c = y[b + 4 >> 2];
						y[a >> 2] = y[b >> 2];
						y[a + 4 >> 2] = c;
						c = y[a + 8 >> 2];
						if (c) {
							y[a + 12 >> 2] = c;
							ma(c);
							y[a + 16 >> 2] = 0;
							y[a + 8 >> 2] = 0;
							y[a + 12 >> 2] = 0;
						}
						y[a + 8 >> 2] = y[b + 8 >> 2];
						y[a + 12 >> 2] = y[b + 12 >> 2];
						y[a + 16 >> 2] = y[b + 16 >> 2];
						y[b + 16 >> 2] = 0;
						y[b + 8 >> 2] = 0;
						y[b + 12 >> 2] = 0;
						$a(a + 20 | 0, b + 20 | 0);
						$a(a + 32 | 0, b + 32 | 0);
						y[a + 44 >> 2] = y[b + 44 >> 2];
						_a(a + 48 | 0, b + 48 | 0);
						_a(a + 60 | 0, b + 60 | 0);
						_a(a + 72 | 0, b + 72 | 0);
						_a(a + 84 | 0, b + 84 | 0);
					}
					function Wd(a, b, c, d, e) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						a: {
							if (Pa(a, y[b + 8 >> 2], e)) {
								if (y[b + 28 >> 2] == 1 | y[b + 4 >> 2] != (c | 0)) {
									break a;
								}
								y[b + 28 >> 2] = d;
								return;
							}
							if (!Pa(a, y[b >> 2], e)) {
								break a;
							}
							if (!(y[b + 16 >> 2] != (c | 0) & y[b + 20 >> 2] != (c | 0))) {
								if ((d | 0) != 1) {
									break a;
								}
								y[b + 32 >> 2] = 1;
								return;
							}
							y[b + 20 >> 2] = c;
							y[b + 32 >> 2] = d;
							y[b + 40 >> 2] = y[b + 40 >> 2] + 1;
							if (!(y[b + 36 >> 2] != 1 | y[b + 24 >> 2] != 2)) {
								w[b + 54 | 0] = 1;
							}
							y[b + 44 >> 2] = 4;
						}
					}
					function ae(a, b, c) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						var d = 0, e = 0;
						d = Y + -64 | 0;
						Y = d;
						a: {
							e = 1;
							b: {
								if (y[a + 4 >> 2] == y[b + 4 >> 2]) {
									break b;
								}
								b = tb(b, 5032);
								e = 0;
								if (!b) {
									break b;
								}
								e = y[c >> 2];
								if (!e) {
									break a;
								}
								t(d + 8 | 0, 0, 56);
								w[d + 59 | 0] = 1;
								y[d + 16 >> 2] = -1;
								y[d + 12 >> 2] = a;
								y[d + 4 >> 2] = b;
								y[d + 52 >> 2] = 1;
								_[y[y[b >> 2] + 28 >> 2]](b, d + 4 | 0, e, 1);
								a = y[d + 28 >> 2];
								if ((a | 0) == 1) {
									y[c >> 2] = y[d + 20 >> 2];
								}
								e = (a | 0) == 1;
							}
							Y = d - -64 | 0;
							return e | 0;
						}
						Sc();
						o();
					}
					function wd(a, b, c, d, e) {
						var f = 0, g = 0, h = 0, i = 0;
						a: {
							if (!d) {
								break a;
							}
							g = c;
							h = b;
							if (e & 1) {
								if (f | g) {
									f = 32 - g | 0;
									e = d >>> 0 < f >>> 0 ? d : f;
									y[h >> 2] = y[h >> 2] | -1 << g & -1 >>> f - e;
									h = h + 4 | 0;
									e = d - e | 0;
								} else {
									e = d;
								}
								f = e;
								i = f >>> 5 | 0;
								e = i;
								g = h;
								while (1) {
									if (e) {
										y[g >> 2] = -1;
										e = e - 1 | 0;
										g = g + 4 | 0;
										continue;
									}
									break;
								}
								f = f & 31;
								if (!f) {
									break a;
								}
								e = (i << 2) + h | 0;
								y[e >> 2] = y[e >> 2] | -1 >>> 32 - f;
								break a;
							}
							$c(h, g, d);
						}
						y[a >> 2] = b;
						y[a + 4 >> 2] = c;
						oc(a, d);
					}
					function ad(a, b, c, d) {
						var e = 0, f = 0;
						e = Y - 16 | 0;
						Y = e;
						dc(e + 8 | 0, b, c);
						a: {
							b: {
								if (!z[e + 12 | 0]) {
									y[a >> 2] = 0;
									y[a + 4 >> 2] = 0;
									break b;
								}
								if (!((d | 0) > 0 & (y[b + 24 >> 2] - c | 0) >= (d | 0))) {
									y[a >> 2] = 0;
									y[a + 4 >> 2] = 0;
									break b;
								}
								f = y[b + 16 >> 2];
								c = y[e + 8 >> 2];
								if (f >>> 0 < c >>> 0) {
									break a;
								}
								d = E(y[b + 28 >> 2], d);
								if (d >>> 0 > f - c >>> 0) {
									break a;
								}
								b = c + y[b + 12 >> 2] | 0;
								if (b & 3) {
									break a;
								}
								y[a >> 2] = b;
								y[a + 4 >> 2] = d >>> 2;
							}
							Y = e + 16 | 0;
							return;
						}
						o();
					}
					function Rc(a, b, c, d) {
						w[a + 53 | 0] = 1;
						a: {
							if (y[a + 4 >> 2] != (c | 0)) {
								break a;
							}
							w[a + 52 | 0] = 1;
							c = y[a + 16 >> 2];
							b: {
								if (!c) {
									y[a + 36 >> 2] = 1;
									y[a + 24 >> 2] = d;
									y[a + 16 >> 2] = b;
									if ((d | 0) != 1) {
										break a;
									}
									if (y[a + 48 >> 2] == 1) {
										break b;
									}
									break a;
								}
								if ((b | 0) == (c | 0)) {
									c = y[a + 24 >> 2];
									if ((c | 0) == 2) {
										y[a + 24 >> 2] = d;
										c = d;
									}
									if (y[a + 48 >> 2] != 1) {
										break a;
									}
									if ((c | 0) == 1) {
										break b;
									}
									break a;
								}
								y[a + 36 >> 2] = y[a + 36 >> 2] + 1;
							}
							w[a + 54 | 0] = 1;
						}
					}
					function Fd(a, b) {
						var c = 0, d = 0, e = 0;
						d = a, e = Da(), y[d >> 2] = e;
						d = a, e = Da(), y[d + 4 >> 2] = e;
						d = a, e = Da(), y[d + 8 >> 2] = e;
						d = a, e = Da(), y[d + 12 >> 2] = e;
						d = a, e = Da(), y[d + 16 >> 2] = e;
						d = a, e = Da(), y[d + 20 >> 2] = e;
						d = a, e = Da(), y[d + 24 >> 2] = e;
						d = a, e = Da(), y[d + 28 >> 2] = e;
						d = a, e = Da(), y[d + 32 >> 2] = e;
						c = na(16);
						w[c + 12 | 0] = b;
						y[c + 8 >> 2] = 0;
						y[c >> 2] = 0;
						y[c + 4 >> 2] = 0;
						fb(c, 1 << b);
						y[a + 36 >> 2] = c;
						return a;
					}
					function ld(a, b) {
						var c = 0, d = 0, e = 0;
						c = Y - 32 | 0;
						Y = c;
						a: {
							d = y[a + 40 >> 2];
							if (d) {
								e = y[a + 48 >> 2];
								y[c + 24 >> 2] = y[a + 44 >> 2];
								y[c + 28 >> 2] = e;
								b = y[b + 28 >> 2];
								if (b >>> 0 > d >>> 0) {
									break a;
								}
								a = y[a + 36 >> 2];
								y[c + 20 >> 2] = b;
								y[c + 16 >> 2] = a;
								a = y[c + 28 >> 2];
								y[c + 8 >> 2] = y[c + 24 >> 2];
								y[c + 12 >> 2] = a;
								a = y[c + 20 >> 2];
								y[c >> 2] = y[c + 16 >> 2];
								y[c + 4 >> 2] = a;
								Ca(c + 8 | 0, c);
							}
							Y = c + 32 | 0;
							return;
						}
						o();
					}
					function gd(a, b) {
						var c = 0, d = 0, e = 0;
						w[a + 1 | 0] = z[b | 0];
						c = y[b + 8 >> 2];
						y[a + 4 >> 2] = c;
						b = y[b + 4 >> 2];
						fd(a + 8 | 0, c);
						zb(a + 20 | 0, c);
						zb(a + 32 | 0, c);
						e = (c << 3) + b | 0;
						c = 0;
						while (1) {
							if ((b | 0) == (e | 0)) {
								a = Ld(a);
							} else {
								y[y[a + 8 >> 2] + (c << 3) >> 2] = z[b | 0];
								d = c << 2;
								y[d + y[a + 20 >> 2] >> 2] = z[b + 1 | 0];
								y[y[a + 32 >> 2] + d >> 2] = y[b + 4 >> 2];
								b = b + 8 | 0;
								c = c + 1 | 0;
								continue;
							}
							break;
						}
						return a;
					}
					function qa(a, b) {
						var c = 0, d = 0, e = 0, f = 0;
						a: {
							c = y[a + 4 >> 2];
							d = y[a + 8 >> 2];
							if (c >>> 0 > d + 3 >>> 0) {
								if (d >>> 0 >= c >>> 0 | d + 1 >>> 0 >= c >>> 0 | d + 2 >>> 0 >= c >>> 0) {
									break a;
								}
								c = b;
								b = y[a >> 2] + d | 0;
								b = z[b | 0] | z[b + 1 | 0] << 8 | (z[b + 2 | 0] << 16 | z[b + 3 | 0] << 24);
								e = c, f = ((Ae(b, 16) ^ b) & -16711936) >>> 8 ^ Ae(b, 8), y[e >> 2] = f;
								y[a + 8 >> 2] = y[a + 8 >> 2] + 4;
								a = 0;
							} else {
								a = -1;
							}
							return a;
						}
						o();
					}
					function ec(a, b) {
						var c = 0, d = 0;
						if ((a | 0) != (b | 0)) {
							kc(a);
							y[a >> 2] = y[b >> 2];
							y[a + 4 >> 2] = y[b + 4 >> 2];
							y[a + 8 >> 2] = y[b + 8 >> 2];
							y[b + 8 >> 2] = 0;
							y[b >> 2] = 0;
							y[b + 4 >> 2] = 0;
							c = y[a >> 2];
							d = y[a + 4 >> 2];
							a: {
								if ((c | 0) != (d | 0)) {
									y[a + 12 >> 2] = c;
									y[a + 16 >> 2] = d - c;
									break a;
								}
								c = y[b + 16 >> 2];
								y[a + 12 >> 2] = y[b + 12 >> 2];
								y[a + 16 >> 2] = c;
							}
							y[b + 12 >> 2] = 0;
							y[b + 16 >> 2] = 0;
						}
					}
					function fc(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0;
						d = y[a >> 2];
						if (y[a + 8 >> 2] - d >> 2 >>> 0 >= b >>> 0) {
							e = y[a + 4 >> 2] - d >> 2;
							f = b >>> 0 > e >>> 0 ? e : b;
							g = d;
							while (1) {
								if (f) {
									y[g >> 2] = y[c >> 2];
									f = f - 1 | 0;
									g = g + 4 | 0;
									continue;
								}
								break;
							}
							if (b >>> 0 > e >>> 0) {
								dd(a, b - e | 0, c);
								return;
							}
							y[a + 4 >> 2] = (b << 2) + d;
							return;
						}
						kc(a);
						ed(a, pd(y[a >> 2], y[a + 8 >> 2], b));
						dd(a, b, c);
					}
					function Pa(a, b, c) {
						var d = 0;
						if (!c) {
							return y[a + 4 >> 2] == y[b + 4 >> 2];
						}
						if ((a | 0) == (b | 0)) {
							return 1;
						}
						c = y[a + 4 >> 2];
						a = z[c | 0];
						b = y[b + 4 >> 2];
						d = z[b | 0];
						a: {
							if (!a | (d | 0) != (a | 0)) {
								break a;
							}
							while (1) {
								d = z[b + 1 | 0];
								a = z[c + 1 | 0];
								if (!a) {
									break a;
								}
								b = b + 1 | 0;
								c = c + 1 | 0;
								if ((a | 0) == (d | 0)) {
									continue;
								}
								break;
							}
						}
						return (a | 0) == (d | 0);
					}
					function Ic(a, b) {
						var c = 0, d = 0, e = 0, f = 0;
						if ((a | 0) != (b | 0)) {
							f = y[b + 4 >> 2];
							c = y[b >> 2];
							b = f - c | 0;
							d = y[a >> 2];
							if (b >>> 0 <= y[a + 8 >> 2] - d >>> 0) {
								e = y[a + 4 >> 2] - d | 0;
								if (b >>> 0 > e >>> 0) {
									if (e) {
										p(d, c, e);
									}
									Xb(a, c + e | 0, f);
									return;
								}
								if (b) {
									p(d, c, b);
								}
								y[a + 4 >> 2] = b + d;
								return;
							}
							kc(a);
							Eb(a, Fc(y[a >> 2], y[a + 8 >> 2], b));
							Xb(a, c, f);
						}
					}
					function Ca(a, b) {
						var c = 0, d = 0, e = 0;
						a: {
							c = y[a + 4 >> 2];
							b: {
								if (!c) {
									break b;
								}
								if (!y[b + 4 >> 2]) {
									a = y[a >> 2];
									while (1) {
										if ((c | 0) <= 0) {
											break b;
										}
										w[a | 0] = 0;
										c = c - 1 | 0;
										a = a + 1 | 0;
										continue;
									}
								}
								e = y[b >> 2];
								d = y[b + 4 >> 2];
								c = y[a >> 2];
								b = 0;
								if (1 & B[a + 4 >> 2] < d >>> 0) {
									break a;
								}
								if (!(b | d) | !d) {
									break b;
								}
								p(c, e, d);
							}
							return;
						}
						o();
					}
					function Dd(a) {
						var b = 0, c = 0, d = 0, e = 0, f = 0, g = 0;
						d = Y - 16 | 0;
						Y = d;
						e = nc();
						f = e + 24 | 0;
						g = y[a + 28 >> 2];
						c = y[a + 24 >> 2];
						while (1) {
							if ((c | 0) != (g | 0)) {
								b = y[c >> 2];
								if (b) {
									b = mc(b);
								} else {
									b = 0;
								}
								y[d + 12 >> 2] = b;
								b = d + 12 | 0;
								_c(f, b);
								c = c + 4 | 0;
								la(b);
								continue;
							}
							break;
						}
						c = Jb(e, a);
						Jb(c + 12 | 0, a + 12 | 0);
						Y = d + 16 | 0;
						return c;
					}
					function ja(a, b, c) {
						var d = 0, e = 0, f = 0;
						d = Y - 16 | 0;
						Y = d;
						dc(d + 8 | 0, b, c);
						a: {
							b: {
								if (!z[d + 12 | 0]) {
									y[a >> 2] = 0;
									y[a + 4 >> 2] = 0;
									break b;
								}
								e = y[b + 16 >> 2];
								c = y[d + 8 >> 2];
								if (e >>> 0 < c >>> 0) {
									break a;
								}
								f = y[b + 28 >> 2];
								if (f >>> 0 > e - c >>> 0) {
									break a;
								}
								b = y[b + 12 >> 2];
								y[a + 4 >> 2] = f;
								y[a >> 2] = b + c;
							}
							Y = d + 16 | 0;
							return;
						}
						o();
					}
					function Qc(a, b, c) {
						var d = 0;
						d = y[a + 36 >> 2];
						if (!d) {
							y[a + 24 >> 2] = c;
							y[a + 16 >> 2] = b;
							y[a + 36 >> 2] = 1;
							y[a + 20 >> 2] = y[a + 56 >> 2];
							return;
						}
						a: {
							if (!(y[a + 20 >> 2] != y[a + 56 >> 2] | y[a + 16 >> 2] != (b | 0))) {
								if (y[a + 24 >> 2] != 2) {
									break a;
								}
								y[a + 24 >> 2] = c;
								return;
							}
							w[a + 54 | 0] = 1;
							y[a + 24 >> 2] = 2;
							y[a + 36 >> 2] = d + 1;
						}
					}
					function Na(a) {
						var b = 0, c = 0, d = 0, e = 0;
						b = na(20);
						y[b + 16 >> 2] = a;
						w[b | 0] = 0;
						c = 255;
						d = y[a >> 2];
						e = y[a + 4 >> 2];
						a = y[a + 8 >> 2];
						if (e >>> 0 > a >>> 0) {
							c = z[a + d | 0];
						}
						w[b + 1 | 0] = c;
						y[b + 4 >> 2] = ((c ^ -1) & 255) << 16;
						Ec(b);
						y[b + 8 >> 2] = 32768;
						y[b + 4 >> 2] = y[b + 4 >> 2] << 7;
						y[b + 12 >> 2] = y[b + 12 >> 2] - 7;
						return b;
					}
					function $c(a, b, c) {
						var d = 0, e = 0;
						if (b) {
							d = 32 - b | 0;
							e = c >>> 0 < d >>> 0 ? c : d;
							y[a >> 2] = y[a >> 2] & (-1 << b & -1 >>> d - e ^ -1);
							c = c - e | 0;
							a = a + 4 | 0;
						}
						e = c >>> 5 | 0;
						b = e;
						d = a;
						while (1) {
							if (b) {
								y[d >> 2] = 0;
								b = b - 1 | 0;
								d = d + 4 | 0;
								continue;
							}
							break;
						}
						b = c & 31;
						if (b) {
							a = (e << 2) + a | 0;
							y[a >> 2] = y[a >> 2] & (-1 >>> 32 - b ^ -1);
						}
					}
					function ob(a, b) {
						var c = 0;
						c = 1;
						a: {
							if (qa(y[a + 4 >> 2], b)) {
								break a;
							}
							if (qa(y[a + 4 >> 2], b + 4 | 0)) {
								break a;
							}
							if (qa(y[a + 4 >> 2], b + 8 | 0)) {
								break a;
							}
							if (qa(y[a + 4 >> 2], b + 12 | 0)) {
								break a;
							}
							if (wa(y[a + 4 >> 2], b + 16 | 0) | (y[b >> 2] > 4096 | y[b + 4 >> 2] > 4096) & z[a + 112 | 0] == 1) {
								break a;
							}
							c = 0;
						}
						return c;
					}
					function jd(a, b, c, d) {
						var e = 0;
						e = Y - 32 | 0;
						Y = e;
						ja(e + 24 | 0, c, (b ^ -1) + d | 0);
						y[a >> 2] = y[e + 24 >> 2];
						y[a + 4 >> 2] = y[e + 28 >> 2];
						b = d - b | 0;
						ja(e + 16 | 0, c, b);
						y[a + 8 >> 2] = y[e + 16 >> 2];
						y[a + 12 >> 2] = y[e + 20 >> 2];
						ja(e + 8 | 0, c, b + 1 | 0);
						y[a + 16 >> 2] = y[e + 8 >> 2];
						y[a + 20 >> 2] = y[e + 12 >> 2];
						Y = e + 32 | 0;
					}
					function Cd(a, b, c) {
						var d = 0, e = 0;
						d = na(32);
						e = y[b + 12 >> 2];
						y[d + 16 >> 2] = y[b + 8 >> 2];
						y[d + 20 >> 2] = e;
						e = y[b + 4 >> 2];
						y[d + 8 >> 2] = y[b >> 2];
						y[d + 12 >> 2] = e;
						b = y[c >> 2];
						y[c >> 2] = 0;
						y[d >> 2] = a;
						y[d + 24 >> 2] = b;
						b = y[a + 4 >> 2];
						y[d + 4 >> 2] = b;
						y[b >> 2] = d;
						y[a + 4 >> 2] = d;
						y[a + 8 >> 2] = y[a + 8 >> 2] + 1;
					}
					function Ga(a, b, c) {
						var d = 0, e = 0, f = 0, g = 0;
						d = y[b + 8 >> 2];
						g = (d | 0) > 0 ? d : 0;
						d = 0;
						while (1) {
							a: {
								if ((d | 0) == (g | 0)) {
									e = 0;
									break a;
								}
								e = Ka(a, y[y[b + 12 >> 2] + (d << 2) >> 2]);
								if (!(!e | (z[e + 4 | 0] & 63) != 53)) {
									if ((c | 0) == (f | 0)) {
										break a;
									}
									f = f + 1 | 0;
								}
								d = d + 1 | 0;
								continue;
							}
							break;
						}
						return e;
					}
					function Kb(a, b) {
						var c = 0;
						y[a + 8 >> 2] = 0;
						y[a >> 2] = 0;
						y[a + 4 >> 2] = 0;
						a: {
							if (b) {
								if (b >>> 0 >= 1073741824) {
									break a;
								}
								c = b << 2;
								b = na(c);
								y[a >> 2] = b;
								c = b + c | 0;
								y[a + 8 >> 2] = c;
								while (1) {
									if ((b | 0) != (c | 0)) {
										y[b >> 2] = 0;
										b = b + 4 | 0;
										continue;
									}
									break;
								}
								y[a + 4 >> 2] = c;
							}
							return a;
						}
						za();
						o();
					}
					function cb(a, b) {
						var c = 0;
						y[a + 8 >> 2] = 0;
						y[a >> 2] = 0;
						y[a + 4 >> 2] = 0;
						a: {
							if (b) {
								if (b >>> 0 >= 1073741824) {
									break a;
								}
								c = Fb(b);
								y[a >> 2] = c;
								b = (b << 2) + c | 0;
								y[a + 8 >> 2] = b;
								while (1) {
									if ((b | 0) != (c | 0)) {
										y[c >> 2] = 0;
										c = c + 4 | 0;
										continue;
									}
									break;
								}
								y[a + 4 >> 2] = b;
							}
							return a;
						}
						za();
						o();
					}
					function Cb(a, b, c) {
						var d = 0;
						d = Y - 32 | 0;
						Y = d;
						ja(d + 24 | 0, b, c - 1 | 0);
						y[a >> 2] = y[d + 24 >> 2];
						y[a + 4 >> 2] = y[d + 28 >> 2];
						ja(d + 16 | 0, b, c);
						y[a + 8 >> 2] = y[d + 16 >> 2];
						y[a + 12 >> 2] = y[d + 20 >> 2];
						ja(d + 8 | 0, b, c + 1 | 0);
						y[a + 16 >> 2] = y[d + 8 >> 2];
						y[a + 20 >> 2] = y[d + 12 >> 2];
						Y = d + 32 | 0;
					}
					function Mc(a, b) {
						var c = 0, d = 0, e = 0;
						c = Y - 16 | 0;
						Y = c;
						d = z[a + 4 | 0];
						if ((d | 0) == 255) {
							a = vb(4);
							y[a >> 2] = 4936;
							P(a | 0, 4948, 2);
							o();
						}
						y[c + 4 >> 2] = c + 3;
						e = y[b + 4 >> 2];
						y[c + 8 >> 2] = y[b >> 2];
						y[c + 12 >> 2] = e;
						a = _[y[(c + 8 | 0) + (d << 2) >> 2]](c + 4 | 0, a) | 0;
						Y = c + 16 | 0;
						return a;
					}
					function lb() {
						var a = 0;
						a = na(80);
						x[a + 56 >> 1] = 0;
						y[a + 12 >> 2] = 0;
						y[a + 24 >> 2] = 0;
						y[a + 28 >> 2] = 0;
						y[a + 32 >> 2] = 0;
						y[a + 36 >> 2] = 0;
						y[a + 40 >> 2] = 0;
						y[a + 44 >> 2] = 0;
						y[a + 48 >> 2] = 0;
						y[a + 60 >> 2] = 0;
						y[a + 64 >> 2] = 0;
						y[a + 68 >> 2] = 0;
						y[a + 72 >> 2] = 0;
						y[a + 76 >> 2] = 0;
						return a;
					}
					function ze(a, b, c, d) {
						var e = 0, f = 0, g = 0, h = 0, i = 0, j = 0;
						e = c >>> 16 | 0;
						f = a >>> 16 | 0;
						j = E(e, f);
						g = c & 65535;
						h = a & 65535;
						i = E(g, h);
						f = (i >>> 16 | 0) + E(f, g) | 0;
						e = (f & 65535) + E(e, h) | 0;
						Z = (E(b, c) + j | 0) + E(a, d) + (f >>> 16) + (e >>> 16) | 0;
						return i & 65535 | e << 16;
					}
					function Ea(a, b, c, d, e) {
						var f = 0;
						a: {
							if (!(!d | (b | 0) < 0 | (a | 0) <= (b | 0))) {
								f = b & 7;
								a = b >>> 3 | 0;
								if (e) {
									if (a >>> 0 >= d >>> 0) {
										break a;
									}
									a = a + c | 0;
									w[a | 0] = z[a | 0] | 128 >>> f;
									return;
								}
								if (a >>> 0 >= d >>> 0) {
									break a;
								}
								a = a + c | 0;
								w[a | 0] = z[a | 0] & -129 >> f;
							}
							return;
						}
						o();
					}
					function od(a) {
						var b = 0, c = 0, d = 0;
						y[a + 56 >> 2] = 2;
						c = 1;
						b = 4;
						d = y[a + 52 >> 2];
						a: {
							b: {
								if ((d | 0) == 5) {
									break b;
								}
								if ((d | 0) >= 3) {
									y[a + 52 >> 2] = 5;
									break b;
								}
								b = yc(a);
								c = !b;
								if (y[a + 56 >> 2] == 3) {
									break a;
								}
								y[a + 52 >> 2] = 5;
								b = b ? -1 : 4;
							}
							y[a + 56 >> 2] = b;
						}
						return c;
					}
					function Ka(a, b) {
						var c = 0, d = 0;
						c = y[a >> 2];
						a: {
							if (c) {
								c = Ka(c, b);
								if (c) {
									break a;
								}
							}
							d = y[a + 12 >> 2];
							a = y[a + 8 >> 2];
							while (1) {
								if ((a | 0) == (d | 0)) {
									return 0;
								}
								c = y[a >> 2];
								a = a + 4 | 0;
								if (y[c >> 2] != (b | 0)) {
									continue;
								}
								break;
							}
						}
						return c;
					}
					function Bd(a) {
						var b = 0;
						a: {
							if (z[a + 16 | 0] != 3 | z[a + 17 | 0] != 255 | (z[a + 18 | 0] != 253 | z[a + 19 | 0] != 255)) {
								break a;
							}
							if (z[a + 20 | 0] != 2 | z[a + 21 | 0] != 254 | (z[a + 22 | 0] != 254 | z[a + 23 | 0] != 254)) {
								break a;
							}
							b = z[a + 2 | 0] ^ 1;
						}
						return b & 1;
					}
					function Sa(a, b) {
						var c = 0, d = 0, e = 0;
						a: {
							c = y[a + 8 >> 2];
							e = c + 1 | 0;
							d = y[a + 4 >> 2];
							if (e >>> 0 < d >>> 0) {
								if (c >>> 0 >= d >>> 0) {
									break a;
								}
								d = b;
								b = y[a >> 2];
								x[d >> 1] = z[b + c | 0] << 8 | z[b + e | 0];
								y[a + 8 >> 2] = c + 2;
								a = 0;
							} else {
								a = -1;
							}
							return a;
						}
						o();
					}
					function id(a, b, c, d, e, f, g, h) {
						return y[c + 16 >> 2] | y[c + 12 >> 2] << 3 | y[c + 8 >> 2] << 6 | ia(y[y[a + 20 >> 2] + 20 >> 2], w[a + 26 | 0] + (d - y[a + 12 >> 2] | 0) | 0, e, f) << 8 | y[c + 4 >> 2] << 9 | y[c >> 2] << 10 | ia(b, w[a + 24 | 0] + d | 0, g, h) << 12;
					}
					function Db(a, b) {
						var c = 0;
						c = y[a + 40 >> 2];
						y[a + 28 >> 2] = y[a + 36 >> 2];
						y[a + 32 >> 2] = c;
						c = y[a + 48 >> 2];
						b = y[b + 28 >> 2];
						if (c >>> 0 < b >>> 0) {
							o();
						}
						y[a + 40 >> 2] = c;
						y[a + 48 >> 2] = c - b;
						c = y[a + 44 >> 2];
						y[a + 36 >> 2] = c;
						y[a + 44 >> 2] = b + c;
					}
					function ra(a, b) {
						var c = 0, d = 0, e = 0;
						d = Y - 16 | 0;
						Y = d;
						e = b << 2;
						c = y[e + y[a + 36 >> 2] >> 2];
						if (!c) {
							b = rd(na(96), b);
							c = y[a + 36 >> 2];
							y[d + 12 >> 2] = 0;
							pb(c + e | 0, b);
							pa(d + 12 | 0);
							c = y[y[a + 36 >> 2] + e >> 2];
						}
						Y = d + 16 | 0;
						return c;
					}
					function $a(a, b) {
						var c = 0;
						c = y[a >> 2];
						if (c) {
							y[a + 4 >> 2] = c;
							ma(c);
							y[a + 8 >> 2] = 0;
							y[a >> 2] = 0;
							y[a + 4 >> 2] = 0;
						}
						y[a >> 2] = y[b >> 2];
						y[a + 4 >> 2] = y[b + 4 >> 2];
						y[a + 8 >> 2] = y[b + 8 >> 2];
						y[b + 8 >> 2] = 0;
						y[b >> 2] = 0;
						y[b + 4 >> 2] = 0;
					}
					function Qb() {
						var a = 0;
						a = na(180);
						y[a + 144 >> 2] = 0;
						y[a + 148 >> 2] = 0;
						x[a + 28 >> 1] = 0;
						y[a + 152 >> 2] = 0;
						y[a + 156 >> 2] = 0;
						y[a + 160 >> 2] = 0;
						y[a + 164 >> 2] = 0;
						y[a + 168 >> 2] = 0;
						y[a + 172 >> 2] = 0;
						t(a + 32 | 0, 0, 104);
						return a;
					}
					function Jc(a, b, c) {
						var d = 0, e = 0;
						e = ((b & 536870911) << 3 | a >>> 29) & -8;
						d = y[c >> 2];
						a: {
							while (1) {
								if (B[c >> 2] >= e >>> 0) {
									break a;
								}
								if (!Ia(a, b, c)) {
									continue;
								}
								break;
							}
							if (y[c >> 2] - d >>> 0 > 11) {
								break a;
							}
							y[c >> 2] = d;
						}
					}
					function xb(a, b) {
						var c = 0, d = 0;
						if (z[a | 0] == 1) {
							c = y[a + 4 >> 2];
							b = ze(c, c >> 31, b, 0);
							c = Z;
							d = !(b - -2147483648 >>> 0 < 2147483648 ? c + 1 | 0 : c);
							c = 0 | d;
							b = d ? b : 0;
						} else {
							b = 0;
						}
						y[a >> 2] = c;
						y[a + 4 >> 2] = b;
						return a;
					}
					function oc(a, b) {
						var c = 0;
						c = y[a + 4 >> 2];
						a: {
							if ((b | 0) >= 0) {
								b = b + c | 0;
								c = y[a >> 2] + (b >>> 3 & 536870908) | 0;
								break a;
							}
							b = b + c | 0;
							c = y[a >> 2] + ((b - 31 | 0) / 32 << 2) | 0;
						}
						y[a >> 2] = c;
						y[a + 4 >> 2] = b & 31;
						return a;
					}
					function Lc(a, b) {
						var c = 0, d = 0, e = 0;
						c = Y - 16 | 0;
						Y = c;
						d = z[a + 4 | 0];
						if ((d | 0) != 255) {
							e = y[b + 4 >> 2];
							y[c + 8 >> 2] = y[b >> 2];
							y[c + 12 >> 2] = e;
							_[y[(c + 8 | 0) + (d << 2) >> 2]](c + 7 | 0, a);
						}
						w[a + 4 | 0] = 255;
						Y = c + 16 | 0;
					}
					function Ab(a, b, c, d, e, f, g) {
						var h = 0, i = 0;
						h = Y - 16 | 0;
						Y = h;
						if (y[a + 16 >> 2]) {
							i = y[a + 24 >> 2];
							y[h + 8 >> 2] = y[a + 20 >> 2];
							y[h + 12 >> 2] = i;
							y[h >> 2] = 0;
							y[h + 4 >> 2] = 0;
							cd(a, b, c, d, e, f, g, h);
						}
						Y = h + 16 | 0;
					}
					function Xc(a, b) {
						var c = 0;
						c = Y - 16 | 0;
						Y = c;
						y[c + 8 >> 2] = 0;
						a: {
							if (z[a + 4 | 0] == 1) {
								oa(a, b);
								break a;
							}
							Xa(a);
							w[a + 4 | 0] = 1;
							y[a >> 2] = b;
						}
						y[c + 12 >> 2] = 0;
						la(c + 12 | 0);
						la(c + 8 | 0);
						Y = c + 16 | 0;
						return a;
					}
					function Ac(a, b, c) {
						var d = 0, e = 0, f = 0;
						d = 1;
						while (1) {
							e = z[a + 12 | 0];
							if (e >>> 0 <= (f & 255) >>> 0) {
								y[c >> 2] = (-1 << e) + d;
							} else {
								d = d << 1;
								d = ka(b, d + y[a >> 2] | 0) | d;
								f = f + 1 | 0;
								continue;
							}
							break;
						}
					}
					function wb(a, b, c, d) {
						var e = 0;
						e = Y - 16 | 0;
						Y = e;
						y[e + 12 >> 2] = d;
						d = 1;
						w[e + 8 | 0] = 1;
						a: {
							if (!z[La(e + 8 | 0, b >> c) | 0]) {
								d = 0;
								w[a | 0] = 0;
								break a;
							}
							y[a >> 2] = y[e + 12 >> 2];
						}
						w[a + 4 | 0] = d;
						Y = e + 16 | 0;
					}
					function rc(a) {
						var b = 0;
						b = y[a + 36 >> 2];
						y[a + 36 >> 2] = 0;
						if (b) {
							ma(Ha(b));
						}
						Ba(a + 32 | 0);
						Ba(a + 28 | 0);
						Ba(a + 24 | 0);
						Ba(a + 20 | 0);
						Ba(a + 16 | 0);
						Ba(a + 12 | 0);
						Ba(a + 8 | 0);
						Ba(a + 4 | 0);
						Ba(a);
					}
					function Lb(a, b) {
						var c = 0;
						c = y[a + 4 >> 2];
						if (b) {
							c = c + 1 | 0;
							y[a + 4 >> 2] = c;
						}
						b = y[a + 12 >> 2] - y[a + 8 >> 2] >> 3;
						if (b >>> 0 <= c >>> 0) {
							b = b + 16 | 0;
							fd(a + 8 | 0, b);
							zb(a + 20 | 0, b);
							zb(a + 32 | 0, b);
						}
					}
					function yb(a, b, c) {
						a: {
							switch (a | 0) {
								case 1: return b & c;
								case 2: return b ^ c;
								case 3: return b ^ c ^ -1;
								default: o();
								case 0:
									b = b | c;
									break;
								case 4: break a;
							}
						}
						return b;
					}
					function $d(a, b, c, d, e, f) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						f = f | 0;
						if (Pa(a, y[b + 8 >> 2], f)) {
							Rc(b, c, d, e);
							return;
						}
						a = y[a + 8 >> 2];
						_[y[y[a >> 2] + 20 >> 2]](a, b, c, d, e, f);
					}
					function Gb(a, b) {
						var c = 0;
						c = Y - 16 | 0;
						Y = c;
						y[a + 8 >> 2] = 0;
						y[a >> 2] = 0;
						y[a + 4 >> 2] = 0;
						y[c + 8 >> 2] = a;
						if (b) {
							Eb(a, b);
							kd(a, b);
						}
						w[c + 12 | 0] = 1;
						gc(c + 8 | 0);
						Y = c + 16 | 0;
						return a;
					}
					function xc(a) {
						var b = 0, c = 0, d = 0;
						c = E(z[a + 1 | 0], y[a + 4 >> 2] + 1 | 0);
						if (c >>> 0 <= 65535) {
							d = z[a + 2 | 0];
							b = lb();
							a = z[a | 0];
							y[b + 8 >> 2] = d;
							y[b + 4 >> 2] = c;
							w[b | 0] = a;
						}
						return b;
					}
					function Zc(a, b, c) {
						var d = 0;
						if (!(b & 1) | z[a | 0] != 1) {
							b = 0;
							c = 0;
						} else {
							b = y[a + 4 >> 2];
							d = b;
							b = b + c | 0;
							c = ((d ^ b) & (b ^ c)) >= 0;
							b = c ? b : 0;
						}
						y[a >> 2] = c;
						y[a + 4 >> 2] = b;
						return a;
					}
					function me(a, b, c) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						var d = 0;
						d = y[a + 4 >> 2];
						a = y[a + 8 >> 2];
						b = (a >> 1) + b | 0;
						c = y[c >> 2];
						if (a & 1) {
							d = y[d + y[b >> 2] >> 2];
						}
						return _[d | 0](b, c) | 0;
					}
					function Zd(a, b, c, d) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						if (y[a + 4 >> 2] == y[y[b + 8 >> 2] + 4 >> 2]) {
							Qc(b, c, d);
							return;
						}
						a = y[a + 8 >> 2];
						_[y[y[a >> 2] + 28 >> 2]](a, b, c, d);
					}
					function zd(a, b, c, d) {
						if (b >>> 0 <= d >>> 0) {
							b = (b << 2) + a | 0;
							while (1) {
								if ((a | 0) != (b | 0)) {
									y[c >> 2] = y[a >> 2];
									c = c + 4 | 0;
									a = a + 4 | 0;
									continue;
								}
								break;
							}
							return;
						}
						o();
					}
					function ia(a, b, c, d) {
						a: {
							if (!d | (b | 0) < 0 | (a | 0) <= (b | 0)) {
								a = 0;
							} else {
								a = b >>> 3 | 0;
								if (a >>> 0 >= d >>> 0) {
									break a;
								}
								a = z[a + c | 0] >>> ((b ^ -1) & 7) & 1;
							}
							return a;
						}
						o();
					}
					function dd(a, b, c) {
						var d = 0;
						d = y[a + 4 >> 2];
						b = d + (b << 2) | 0;
						while (1) {
							if ((b | 0) == (d | 0)) {
								y[a + 4 >> 2] = b;
							} else {
								y[d >> 2] = y[c >> 2];
								d = d + 4 | 0;
								continue;
							}
							break;
						}
					}
					function Oa(a) {
						var b = 0;
						va(a + 84 | 0);
						va(a + 72 | 0);
						va(a + 60 | 0);
						va(a + 48 | 0);
						Ha(a + 32 | 0);
						Ha(a + 20 | 0);
						b = y[a + 8 >> 2];
						if (b) {
							y[a + 12 >> 2] = b;
							ma(b);
						}
						return a;
					}
					function bd(a, b) {
						var c = 0, d = 0;
						if (z[a | 0] == 1) {
							c = y[a + 4 >> 2];
							d = c - b | 0;
							c = ((c ^ d) & (b ^ c)) >= 0;
							b = c ? d : 0;
						} else {
							b = 0;
							c = 0;
						}
						y[a >> 2] = c;
						y[a + 4 >> 2] = b;
						return a;
					}
					function La(a, b) {
						var c = 0, d = 0;
						if (z[a | 0] == 1) {
							c = y[a + 4 >> 2];
							d = c + b | 0;
							c = ((d ^ c) & (b ^ d)) >= 0;
							b = c ? d : 0;
						} else {
							b = 0;
							c = 0;
						}
						y[a >> 2] = c;
						y[a + 4 >> 2] = b;
						return a;
					}
					function dc(a, b, c) {
						var d = 0;
						a: {
							if (!(!(!y[b + 16 >> 2] | (c | 0) < 0) & y[b + 24 >> 2] > (c | 0))) {
								w[a | 0] = 0;
								break a;
							}
							y[a >> 2] = E(y[b + 28 >> 2], c);
							d = 1;
						}
						w[a + 4 | 0] = d;
					}
					function Za(a) {
						var b = 0, c = 0;
						b = y[a >> 2];
						if (b) {
							c = y[a + 4 >> 2];
							while (1) {
								if ((c | 0) != (b | 0)) {
									c = la(c - 4 | 0);
									continue;
								}
								break;
							}
							y[a + 4 >> 2] = b;
							ma(y[a >> 2]);
						}
					}
					function wa(a, b) {
						var c = 0, d = 0;
						d = y[a >> 2];
						c = y[a + 8 >> 2];
						if (c >>> 0 < B[a + 4 >> 2]) {
							w[b | 0] = z[d + c | 0];
							y[a + 8 >> 2] = y[a + 8 >> 2] + 1;
							a = 0;
						} else {
							a = -1;
						}
						return a;
					}
					function ye() {
						var a = 0, b = 0, c = 0;
						while (1) {
							b = a << 4;
							c = b + 5728 | 0;
							y[b + 5732 >> 2] = c;
							y[b + 5736 >> 2] = c;
							a = a + 1 | 0;
							if ((a | 0) != 64) {
								continue;
							}
							break;
						}
						Md(48);
					}
					function Tc(a) {
						a = a | 0;
						var b = 0, c = 0, d = 0;
						y[a >> 2] = 5476;
						b = y[a + 4 >> 2];
						c = b - 4 | 0;
						d = y[c >> 2] - 1 | 0;
						y[c >> 2] = d;
						if ((d | 0) < 0) {
							ma(b - 12 | 0);
						}
						return a | 0;
					}
					function qd(a, b) {
						var c = 0;
						c = y[a + 4 >> 2];
						b = c + (b << 2) | 0;
						while (1) {
							if ((b | 0) == (c | 0)) {
								y[a + 4 >> 2] = b;
							} else {
								y[c >> 2] = 0;
								c = c + 4 | 0;
								continue;
							}
							break;
						}
					}
					function kd(a, b) {
						var c = 0;
						c = b;
						b = y[a + 4 >> 2];
						c = c + b | 0;
						while (1) {
							if ((b | 0) == (c | 0)) {
								y[a + 4 >> 2] = c;
							} else {
								w[b | 0] = 0;
								b = b + 1 | 0;
								continue;
							}
							break;
						}
					}
					function Xb(a, b, c) {
						var d = 0;
						d = y[a + 4 >> 2];
						while (1) {
							if ((b | 0) != (c | 0)) {
								w[d | 0] = z[b | 0];
								d = d + 1 | 0;
								b = b + 1 | 0;
								continue;
							}
							break;
						}
						y[a + 4 >> 2] = d;
					}
					function Ia(a, b, c) {
						var d = 0;
						d = c;
						c = y[c >> 2];
						y[d >> 2] = c + 1;
						d = b;
						b = c >>> 3 | 0;
						if (d >>> 0 <= b >>> 0) {
							o();
						}
						return (z[a + b | 0] << (c & 7) & 128) >>> 7 | 0;
					}
					function vd(a, b) {
						var c = 0;
						c = ze(b, 0, a, 0);
						if (Z | c >>> 0 > 2147479550) {
							a = 0;
						} else {
							b = E(a, b);
							a = hb(b);
							if (b ? a : 0) {
								t(a, 0, b);
							}
						}
						return a;
					}
					function pd(a, b, c) {
						if (c >>> 0 >= 1073741824) {
							za();
							o();
						}
						a = b - a | 0;
						b = a >> 1;
						return a >>> 0 >= 2147483644 ? 1073741823 : b >>> 0 > c >>> 0 ? b : c;
					}
					function sa(a) {
						var b = 0, c = 0;
						if (y[a + 12 >> 2]) {
							b = y[a + 8 >> 2] + 1 | 0;
							if (b) {
								c = y[a + 4 >> 2];
								y[a + 8 >> 2] = b >>> 0 < c >>> 0 ? b : c;
							}
							y[a + 12 >> 2] = 0;
						}
					}
					function eb(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							pa(c + 68 | 0);
							la(c - -64 | 0);
							Sb(c + 60 | 0);
							Va(c + 56 | 0);
							va(c + 12 | 0);
							ma(c);
						}
					}
					function md(a) {
						var b = 0;
						a: {
							b = a;
							a = y[a + 16 >> 2];
							if ((b | 0) == (a | 0)) {
								b = 16;
							} else {
								if (!a) {
									break a;
								}
								b = 20;
							}
							_[y[b + y[a >> 2] >> 2]](a);
						}
					}
					function _a(a, b) {
						kc(a);
						y[a >> 2] = y[b >> 2];
						y[a + 4 >> 2] = y[b + 4 >> 2];
						y[a + 8 >> 2] = y[b + 8 >> 2];
						y[b + 8 >> 2] = 0;
						y[b >> 2] = 0;
						y[b + 4 >> 2] = 0;
					}
					function Nb(a, b) {
						var c = 0;
						c = y[a + 52 >> 2];
						if ((c | 0) == 3) {
							if (A[a + 56 >> 1] != 1) {
								y[a + 52 >> 2] = -1;
								return -1;
							}
							c = nd(a, b);
						}
						return c;
					}
					function pe(a) {
						a = a | 0;
						var b = 0, c = 0;
						b = na(12);
						y[b >> 2] = 2244;
						c = y[a + 8 >> 2];
						y[b + 4 >> 2] = y[a + 4 >> 2];
						y[b + 8 >> 2] = c;
						return b | 0;
					}
					function cc(a, b, c, d) {
						var e = 0;
						e = Y - 16 | 0;
						Y = e;
						ad(e + 8 | 0, b, c, d);
						b = y[e + 12 >> 2];
						y[a >> 2] = y[e + 8 >> 2];
						y[a + 4 >> 2] = b;
						Y = e + 16 | 0;
					}
					function Tb(a) {
						var b = 0;
						b = y[a + 12 >> 2];
						a: {
							if ((b | 0) == 7) {
								y[a + 8 >> 2] = y[a + 8 >> 2] + 1;
								b = 0;
								break a;
							}
							b = b + 1 | 0;
						}
						y[a + 12 >> 2] = b;
					}
					function Fc(a, b, c) {
						if ((c | 0) < 0) {
							za();
							o();
						}
						a = b - a | 0;
						b = a << 1;
						return a >>> 0 >= 1073741823 ? 2147483647 : b >>> 0 > c >>> 0 ? b : c;
					}
					function ed(a, b) {
						var c = 0;
						if (b >>> 0 >= 1073741824) {
							za();
							o();
						}
						c = Fb(b);
						y[a + 4 >> 2] = c;
						y[a >> 2] = c;
						y[a + 8 >> 2] = (b << 2) + c;
					}
					function Ya(a) {
						var b = 0, c = 0;
						b = y[a + 4 >> 2];
						if (!b) {
							o();
						}
						c = y[a >> 2];
						y[a >> 2] = c + 4;
						y[a + 4 >> 2] = b - 1;
						return y[c >> 2];
					}
					function Yc(a, b) {
						a: {
							b: {
								if (!z[a + 4 | 0]) {
									if (y[a >> 2] != (b | 0)) {
										break b;
									}
									break a;
								}
								Xa(a);
								w[a + 4 | 0] = 0;
							}
							y[a >> 2] = b;
						}
					}
					function Cc(a, b, c) {
						if ((c | 0) < 0) {
							za();
							o();
						}
						a = b - a | 0;
						return a >>> 0 >= 2147483646 ? 2147483647 : a >>> 0 > c >>> 0 ? a : c;
					}
					function rd(a, b) {
						var c = 0, d = 0;
						x[a >> 1] = 0;
						t(a + 4 | 0, 0, 92);
						c = a, d = gd(a, E(b, 12) + 2708 | 0), w[c | 0] = d;
						return a;
					}
					function Vd(a, b, c, d, e, f) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						e = e | 0;
						f = f | 0;
						if (Pa(a, y[b + 8 >> 2], f)) {
							Rc(b, c, d, e);
						}
					}
					function ib(a) {
						var b = 0, c = 0;
						while (1) {
							b = c;
							c = b + 1 | 0;
							if (1 << b >>> 0 < a >>> 0) {
								continue;
							}
							break;
						}
						return b & 255;
					}
					function bc(a) {
						var b = 0, c = 0;
						b = y[a + 4 >> 2];
						if (!b) {
							o();
						}
						c = y[a >> 2];
						y[a >> 2] = c + 4;
						y[a + 4 >> 2] = b - 1;
						return c;
					}
					function oe(a, b) {
						a = a | 0;
						b = b | 0;
						var c = 0;
						y[b >> 2] = 2244;
						c = y[a + 8 >> 2];
						y[b + 4 >> 2] = y[a + 4 >> 2];
						y[b + 8 >> 2] = c;
					}
					function ud(a, b) {
						var c = 0;
						c = Y - 16 | 0;
						Y = c;
						y[c + 12 >> 2] = b;
						b = a + 24 | 0;
						a = c + 12 | 0;
						_c(b, a);
						la(a);
						Y = c + 16 | 0;
					}
					function kc(a) {
						var b = 0;
						b = y[a >> 2];
						if (b) {
							y[a + 4 >> 2] = b;
							ma(b);
							y[a + 8 >> 2] = 0;
							y[a >> 2] = 0;
							y[a + 4 >> 2] = 0;
						}
					}
					function Dc(a) {
						var b = 0, c = 0;
						b = y[a + 8 >> 2] + 1 | 0;
						if (b) {
							c = a;
							a = y[a + 4 >> 2];
							y[c + 8 >> 2] = a >>> 0 > b >>> 0 ? b : a;
						}
					}
					function Kd(a, b) {
						var c = 0;
						if ((b | 0) < 0) {
							za();
							o();
						}
						c = na(b);
						y[a + 4 >> 2] = c;
						y[a >> 2] = c;
						y[a + 8 >> 2] = b + c;
					}
					function Eb(a, b) {
						var c = 0;
						if ((b | 0) < 0) {
							za();
							o();
						}
						c = Ad(b);
						y[a + 4 >> 2] = c;
						y[a >> 2] = c;
						y[a + 8 >> 2] = b + c;
					}
					function Ae(a, b) {
						var c = 0, d = 0;
						c = b & 31;
						d = (-1 << c & a) >>> c | 0;
						c = a;
						a = 0 - b & 31;
						return d | (c & -1 >>> a) << a;
					}
					function Yd(a, b, c, d) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						d = d | 0;
						if (y[a + 4 >> 2] == y[y[b + 8 >> 2] + 4 >> 2]) {
							Qc(b, c, d);
						}
					}
					function Qd(a) {
						a = a | 0;
						var b = 0;
						b = y[a + 64 >> 2];
						a = y[a + 52 >> 2] + 7 >>> 3 | 0;
						return (a >>> 0 > b >>> 0 ? b : a) | 0;
					}
					function Mb(a, b, c) {
						c = 0 - c | 0;
						while (1) {
							if ((b | 0) > 0) {
								w[a | 0] = c;
								b = b - 1 | 0;
								a = a + 1 | 0;
								continue;
							}
							break;
						}
					}
					function Kc(a, b) {
						b = b - a | 0;
						while (1) {
							if ((b | 0) > 0) {
								w[a | 0] = 255;
								b = b - 1 | 0;
								a = a + 1 | 0;
								continue;
							}
							break;
						}
					}
					function Ib(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							Za(c + 24 | 0);
							Ha(c + 12 | 0);
							ma(Ha(c));
						}
					}
					function Da() {
						var a = 0;
						a = na(12);
						y[a + 8 >> 2] = 0;
						y[a >> 2] = 0;
						y[a + 4 >> 2] = 0;
						fb(a, 512);
						return a;
					}
					function uc(a, b, c, d, e, f, g, h) {
						if (!(!y[a + 16 >> 2] | !y[f + 16 >> 2])) {
							cd(f, a, b, c, d, e, h, g);
						}
					}
					function Ad(a) {
						a: {
							if (a >>> 0 <= 2147479550) {
								a = hb(a);
								if (a) {
									break a;
								}
							}
							Jd();
							o();
						}
						return a;
					}
					function Oc(a, b) {
						var c = 0;
						return (z[a + 16 | 0] != (b | 0) | z[a + 17 | 0] != 255 ? c : z[a + 2 | 0] ^ 1) & 1;
					}
					function Nc(a) {
						a = a | 0;
						y[a + 40 >> 2] = 0;
						y[a + 44 >> 2] = 0;
						va(a + 80 | 0);
						va(a + 68 | 0);
						return a | 0;
					}
					function qc(a) {
						var b = 0;
						b = y[a >> 2];
						y[a >> 2] = 0;
						if (b) {
							va(b + 124 | 0);
							Oa(b + 28 | 0);
							ma(b);
						}
					}
					function mb(a, b) {
						var c = 0;
						c = vd(b, 2);
						if (!c) {
							Jd();
							o();
						}
						y[a + 4 >> 2] = b;
						y[a >> 2] = c;
					}
					function Pd(a) {
						a = a | 0;
						Kc(y[a + 80 >> 2], y[a + 84 >> 2]);
						y[a + 52 >> 2] = 0;
						return 1;
					}
					function Pb(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							Za(c + 4 | 0);
							ma(c);
						}
					}
					function Ha(a) {
						var b = 0;
						b = y[a >> 2];
						if (b) {
							y[a + 4 >> 2] = b;
							ma(b);
						}
						return a;
					}
					function oa(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							va(c);
							ma(c);
						}
					}
					function Ub(a) {
						var b = 0;
						b = y[a >> 2];
						y[a >> 2] = 0;
						if (b) {
							ma(b);
						}
						return a;
					}
					function wc(a) {
						var b = 0;
						b = na(16);
						y[b >> 2] = a;
						cb(b + 4 | 0, a);
						return b;
					}
					function le(a, b) {
						a = a | 0;
						b = b | 0;
						return (y[b + 4 >> 2] == 2532 ? a + 4 | 0 : 0) | 0;
					}
					function pb(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							ma(Oa(c));
						}
					}
					function Fb(a) {
						if (a >>> 0 >= 1073741824) {
							Wa();
							o();
						}
						return na(a << 2);
					}
					function bb(a, b, c, d, e, f, g) {
						if (y[a + 16 >> 2]) {
							Ab(f, a, b, c, d, e, g);
						}
					}
					function Wa() {
						var a = 0;
						a = vb(4);
						y[a >> 2] = 5372;
						P(a | 0, 5428, 2);
						o();
					}
					function Ba(a) {
						var b = 0;
						b = y[a >> 2];
						y[a >> 2] = 0;
						if (b) {
							ma(Ha(b));
						}
					}
					function na(a) {
						a = hb(a >>> 0 <= 1 ? 1 : a);
						if (!a) {
							Sc();
							o();
						}
						return a;
					}
					function va(a) {
						var b = 0;
						b = y[a >> 2];
						if (b) {
							y[a + 4 >> 2] = b;
							ma(b);
						}
					}
					function Ra(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						if (c) {
							ma(c);
						}
					}
					function Ua(a) {
						var b = 0;
						b = y[a >> 2];
						y[a >> 2] = 0;
						if (b) {
							ma(b);
						}
					}
					function kb() {
						var a = 0;
						a = na(28);
						y[a + 20 >> 2] = 0;
						return a;
					}
					function Be(a) {
						if (a) {
							return 31 - H(a - 1 ^ a) | 0;
						}
						return 32;
					}
					function Bc(a) {
						if ((a | 0) < 0) {
							Wa();
							o();
						}
						return na(a << 1);
					}
					function ua(a, b) {
						return sd(na(32), y[a >> 2], y[b >> 2]);
					}
					function Hd(a, b) {
						var c = 0;
						c = y[a >> 2];
						y[a >> 2] = b;
						ma(c);
					}
					function td(a) {
						var b = 0;
						b = na(4);
						y[b >> 2] = a;
						return b;
					}
					function nc() {
						var a = 0;
						a = na(36);
						t(a, 0, 36);
						return a;
					}
					function be(a, b, c) {
						a = a | 0;
						b = b | 0;
						c = c | 0;
						return 0;
					}
					function Jd() {
						y[(Y - 16 | 0) + 12 >> 2] = 5684;
						sc();
						o();
					}
					function Ma(a, b, c, d) {
						return (yb(a, b, c) ^ c) & d ^ c;
					}
					function ub(a, b) {
						a = a | 0;
						b = b | 0;
						return y[b >> 2];
					}
					function ne(a) {
						a = a | 0;
						_[y[y[a >> 2] + 4 >> 2]](a);
					}
					function gc(a) {
						if (!z[a + 4 | 0]) {
							va(y[a >> 2]);
						}
					}
					function ee(a) {
						a = a | 0;
						T();
						S(a + 128 | 0);
						o();
					}
					function hc(a, b) {
						return sd(na(32), a, b);
					}
					function lc(a) {
						a = y[a >> 2];
						if (a) {
							ma(a);
						}
					}
					function Td(a) {
						a = a | 0;
						return y[a + 4 >> 2];
					}
					function vb(a) {
						return hb(a | 80) + 80 | 0;
					}
					function Nd(a) {
						a = a | 0;
						return hb(a) | 0;
					}
					function xa(a) {
						return rd(na(96), a);
					}
					function je(a, b) {
						a = a | 0;
						b = b | 0;
						la(b);
					}
					function ge(a, b) {
						a = a | 0;
						b = b | 0;
						Ja(b);
					}
					function ac(a) {
						return (Ta(a) | 0) != 0;
					}
					function ke(a) {
						a = a | 0;
						return 2512;
					}
					function de(a) {
						a = a | 0;
						return 4530;
					}
					function ce(a) {
						a = a | 0;
						return 4504;
					}
					function Ud(a) {
						a = a | 0;
						return 4553;
					}
					function Ta(a) {
						return Mc(a, 4584);
					}
					function $b(a) {
						return Mc(a, 4600);
					}
					function sb(a) {
						rb(a, 0);
						return a;
					}
					function qb(a) {
						a = a | 0;
						return a | 0;
					}
					function pc(a) {
						Va(a + 24 | 0);
						ma(a);
					}
					function pa(a) {
						pb(a, 0);
						return a;
					}
					function la(a) {
						oa(a, 0);
						return a;
					}
					function Vb(a) {
						eb(a, 0);
						return a;
					}
					function Rd(a) {
						a = a | 0;
						ma(Nc(a));
					}
					function Pc(a) {
						a = a | 0;
						ma(Tc(a));
					}
					function yd(a) {
						return Oc(a, 3);
					}
					function fe(a) {
						a = a | 0;
						sc();
						o();
					}
					function Hb(a) {
						return Oc(a, 2);
					}
					function Vc(a, b) {
						a = a | 0;
						b = b | 0;
					}
					function Qa(a) {
						a = a | 0;
						ma(a);
					}
					function Xa(a) {
						Lc(a, 4576);
					}
					function Uc(a) {
						Lc(a, 4592);
					}
					function ta(a) {
						Ra(a, 0);
					}
					function Va(a) {
						Ib(a, 0);
					}
					function Sc() {
						sc();
						o();
					}
					function Sb(a) {
						Pb(a, 0);
					}
					function Ja(a) {
						Hd(a, 0);
					}
					function sc() {
						U();
						o();
					}
					function ic(a) {
						a = a | 0;
					}
					// EMSCRIPTEN_END_FUNCS
					a = z;
					m(n);
					var _ = [
						null,
						Tc,
						qb,
						xe,
						we,
						ve,
						ue,
						te,
						se,
						re,
						qe,
						qb,
						Nc,
						Rd,
						Qd,
						Pd,
						Od,
						qb,
						Qa,
						pe,
						oe,
						ic,
						ne,
						me,
						le,
						ke,
						Vc,
						je,
						ub,
						ub,
						Vc,
						ge,
						ub,
						ub,
						ee,
						fe,
						Qa,
						de,
						Qa,
						ce,
						qb,
						Qa,
						ic,
						ic,
						be,
						Qa,
						Xd,
						Qa,
						Ud,
						Pc,
						Td,
						Pc,
						Qa,
						ae,
						Vd,
						Wd,
						Yd,
						Qa,
						$d,
						_d,
						Zd
					];
					function $() {
						return v.byteLength >> 16;
					}
					function ea(fa) {
						fa = fa | 0;
						var aa = $() | 0;
						var ba = aa + fa | 0;
						if (aa < ba && ba < 65536 && ba <= 32768) {
							var ca = new ArrayBuffer(ba << 16);
							var da = new Int8Array(ca);
							da.set(w);
							w = new Int8Array(ca);
							x = new Int16Array(ca);
							y = new Int32Array(ca);
							z = new Uint8Array(ca);
							A = new Uint16Array(ca);
							B = new Uint32Array(ca);
							C = new Float32Array(ca);
							D = new Float64Array(ca);
							v = ca;
							a = z;
						}
						return aa;
					}
					return {
						j: Object.create(Object.prototype, {
							grow: { value: ea },
							buffer: { get: function() {
								return v;
							} }
						}),
						k: ye,
						l: Nd,
						m: ma,
						n: he,
						o: ie,
						p: Sd
					};
				}
				return ga(ha);
			})(info);
		},
		instantiate: function(binary, info) {
			return { then: function(ok) {
				var module = new WebAssembly.Module(binary);
				ok({ instance: new WebAssembly.Instance(module, info) });
			} };
		},
		RuntimeError: Error,
		isWasm2js: true
	};
	if (WebAssembly.isWasm2js) {
		wasmBinary = [];
	}
	var ABORT = false;
	var EXITSTATUS;
	class EmscriptenEH {}
	class EmscriptenSjLj extends EmscriptenEH {}
	var runtimeInitialized = false;
	function getMemoryBuffer() {
		return wasmMemory.buffer;
	}
	function updateMemoryViews() {
		var _HEAP8$buffer;
		if (HEAP8 === null || HEAP8 === void 0 || (_HEAP8$buffer = HEAP8.buffer) === null || _HEAP8$buffer === void 0 ? void 0 : _HEAP8$buffer.resizable) return;
		var b = getMemoryBuffer();
		HEAP8 = new Int8Array(b);
		HEAPU8 = new Uint8Array(b);
		HEAPU32 = new Uint32Array(b);
	}
	function preRun() {
		var preRun = Module["preRun"];
		if (preRun) {
			if (typeof preRun == "function") preRun = [preRun];
			onPreRuns.push(...preRun);
		}
		callRuntimeCallbacks(onPreRuns);
	}
	function initRuntime() {
		runtimeInitialized = true;
		wasmExports["k"]();
	}
	function postRun() {
		var postRun = Module["postRun"];
		if (postRun) {
			if (typeof postRun == "function") postRun = [postRun];
			onPostRuns.push(...postRun);
		}
		callRuntimeCallbacks(onPostRuns);
	}
	function abort(what) {
		var _Module$onAbort;
		(_Module$onAbort = Module["onAbort"]) === null || _Module$onAbort === void 0 ? void 0 : _Module$onAbort.call(Module, what);
		what = `Aborted(${what})`;
		err(what);
		ABORT = true;
		what += ". Build with -sASSERTIONS for more info.";
		var e = new WebAssembly.RuntimeError(what);
		throw e;
	}
	var wasmBinaryFile;
	function findWasmBinary(file) {}
	function getBinarySync(file) {}
	function instantiateSync(file, info) {
		var module;
		var binary = getBinarySync(file);
		module = new WebAssembly.Module(binary);
		var instance = new WebAssembly.Instance(module, info);
		return [instance, module];
	}
	function getWasmImports() {
		var imports = { a: wasmImports };
		return imports;
	}
	function createWasm() {
		var _wasmBinaryFile;
		function receiveInstance(instance) {
			wasmExports = instance.exports;
			assignWasmExports(wasmExports);
			updateMemoryViews();
			return wasmExports;
		}
		var info = getWasmImports();
		var instantiateWasm = Module["instantiateWasm"];
		if (instantiateWasm) {
			return new Promise((resolve) => {
				instantiateWasm(info, (inst) => resolve(receiveInstance(inst)));
			});
		}
		(_wasmBinaryFile = wasmBinaryFile) !== null && _wasmBinaryFile !== void 0 ? _wasmBinaryFile : wasmBinaryFile = findWasmBinary();
		var result = instantiateSync(wasmBinaryFile, info);
		return receiveInstance(result[0]);
	}
	class ExitStatus {
		constructor(status) {
			_defineProperty(this, "name", "ExitStatus");
			this.message = `Program terminated with exit(${status})`;
			this.status = status;
		}
	}
	var HEAP8;
	var callRuntimeCallbacks = (callbacks) => {
		while (callbacks.length > 0) {
			callbacks.shift()(Module);
		}
	};
	var onPostRuns = [];
	var onPreRuns = [];
	var noExitRuntime = true;
	var HEAPU32;
	class ExceptionInfo {
		constructor(excPtr) {
			this.excPtr = excPtr;
			this.ptr = excPtr - 24;
		}
		set_type(type) {
			HEAPU32[this.ptr + 4 >> 2] = type;
		}
		get_type() {
			return HEAPU32[this.ptr + 4 >> 2];
		}
		set_destructor(destructor) {
			HEAPU32[this.ptr + 8 >> 2] = destructor;
		}
		get_destructor() {
			return HEAPU32[this.ptr + 8 >> 2];
		}
		set_caught(caught) {
			caught = caught ? 1 : 0;
			HEAP8[this.ptr + 12] = caught;
		}
		get_caught() {
			return HEAP8[this.ptr + 12] != 0;
		}
		set_rethrown(rethrown) {
			rethrown = rethrown ? 1 : 0;
			HEAP8[this.ptr + 13] = rethrown;
		}
		get_rethrown() {
			return HEAP8[this.ptr + 13] != 0;
		}
		init(type, destructor) {
			this.set_adjusted_ptr(0);
			this.set_type(type);
			this.set_destructor(destructor);
		}
		set_adjusted_ptr(adjustedPtr) {
			HEAPU32[this.ptr + 16 >> 2] = adjustedPtr;
		}
		get_adjusted_ptr() {
			return HEAPU32[this.ptr + 16 >> 2];
		}
	}
	var uncaughtExceptionCount = 0;
	var __Unwind_RaiseException = (ex) => {
		abort();
	};
	var ___cxa_throw = (ptr, type, destructor) => {
		var info = new ExceptionInfo(ptr);
		info.init(type, destructor);
		uncaughtExceptionCount++;
		__Unwind_RaiseException(ptr);
	};
	var __abort_js = () => abort("");
	var runtimeKeepaliveCounter = 0;
	var __emscripten_runtime_keepalive_clear = () => {
		noExitRuntime = false;
		runtimeKeepaliveCounter = 0;
	};
	var timers = {};
	var handleException = (e) => {
		if (e instanceof ExitStatus || e == "unwind") {
			return EXITSTATUS;
		}
		quit_(1, e);
	};
	var keepRuntimeAlive = () => noExitRuntime || runtimeKeepaliveCounter > 0;
	var _proc_exit = (code) => {
		EXITSTATUS = code;
		if (!keepRuntimeAlive()) {
			var _Module$onExit;
			(_Module$onExit = Module["onExit"]) === null || _Module$onExit === void 0 ? void 0 : _Module$onExit.call(Module, code);
			ABORT = true;
		}
		quit_(code, new ExitStatus(code));
	};
	var exitJS = (status, implicit) => {
		EXITSTATUS = status;
		_proc_exit(status);
	};
	var _exit = exitJS;
	var maybeExit = () => {
		if (!keepRuntimeAlive()) {
			try {
				_exit(EXITSTATUS);
			} catch (e) {
				handleException(e);
			}
		}
	};
	var callUserCallback = (func) => {
		if (ABORT) {
			return;
		}
		try {
			return func();
		} catch (e) {
			handleException(e);
		} finally {
			maybeExit();
		}
	};
	var _emscripten_get_now = () => performance.now();
	var __setitimer_js = (which, timeout_ms) => {
		if (timers[which]) {
			clearTimeout(timers[which].id);
			delete timers[which];
		}
		if (!timeout_ms) return 0;
		var id = setTimeout(() => {
			delete timers[which];
			callUserCallback(() => __emscripten_timeout(which, _emscripten_get_now()));
		}, timeout_ms);
		timers[which] = {
			id,
			timeout_ms
		};
		return 0;
	};
	function _createImageData(size) {
		Module.imageData = new Uint8Array(size);
	}
	var getHeapMax = () => 2147483648;
	var alignMemory = (size, alignment) => Math.ceil(size / alignment) * alignment;
	var growMemory = (size) => {
		var oldHeapSize = wasmMemory.buffer.byteLength;
		var pages = (size - oldHeapSize + 65535) / 65536 | 0;
		try {
			wasmMemory.grow(pages);
			updateMemoryViews();
			return 1;
		} catch (e) {}
	};
	var HEAPU8;
	var _emscripten_resize_heap = (requestedSize) => {
		var oldSize = HEAPU8.length;
		requestedSize >>>= 0;
		var maxHeapSize = getHeapMax();
		if (requestedSize > maxHeapSize) {
			return false;
		}
		for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
			var overGrownHeapSize = oldSize * (1 + .2 / cutDown);
			overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296);
			var newSize = Math.min(maxHeapSize, alignMemory(Math.max(requestedSize, overGrownHeapSize), 65536));
			var replacement = growMemory(newSize);
			if (replacement) {
				return true;
			}
		}
		return false;
	};
	function _setImageData(array_ptr, pitch8, pitch32, height) {
		if (pitch32 === pitch8) {
			Module.imageData = new Uint8ClampedArray(HEAPU8.subarray(array_ptr, array_ptr + pitch32 * height));
			return;
		}
		const destSize = pitch8 * height;
		const imageData = Module.imageData = new Uint8ClampedArray(destSize);
		for (let srcStart = array_ptr, destStart = 0; destStart < destSize; srcStart += pitch32, destStart += pitch8) {
			imageData.set(HEAPU8.subarray(srcStart, srcStart + pitch8), destStart);
		}
	}
	function _setLineData(line_ptr, pitch8, offset) {
		Module.imageData.set(HEAPU8.subarray(line_ptr, line_ptr + pitch8), offset);
	}
	var writeArrayToMemory = (array, buffer) => {
		HEAP8.set(array, buffer);
	};
	{
		if (Module["noExitRuntime"]) noExitRuntime = Module["noExitRuntime"];
		if (Module["print"]) out = Module["print"];
		if (Module["printErr"]) err = Module["printErr"];
		if (Module["wasmBinary"]) wasmBinary = Module["wasmBinary"];
		if (Module["arguments"]) programArgs = Module["arguments"];
		if (Module["thisProgram"]) thisProgram = Module["thisProgram"];
		var preInit = Module["preInit"];
		if (preInit) {
			if (typeof preInit == "function") Module["preInit"] = preInit = [preInit];
			while (preInit.length > 0) {
				preInit.shift()();
			}
		}
	}
	Module["writeArrayToMemory"] = writeArrayToMemory;
	var _malloc, _free, _jbig2_decode, _ccitt_decode, __emscripten_timeout, memory, __indirect_function_table, wasmMemory;
	function assignWasmExports(wasmExports) {
		_malloc = Module["_malloc"] = wasmExports["l"];
		_free = Module["_free"] = wasmExports["m"];
		_jbig2_decode = Module["_jbig2_decode"] = wasmExports["n"];
		_ccitt_decode = Module["_ccitt_decode"] = wasmExports["o"];
		__emscripten_timeout = wasmExports["p"];
		memory = wasmMemory = wasmExports["j"];
		__indirect_function_table = wasmExports["__indirect_function_table"];
	}
	var wasmImports = {
		a: ___cxa_throw,
		f: __abort_js,
		e: __emscripten_runtime_keepalive_clear,
		b: __setitimer_js,
		h: _createImageData,
		c: _emscripten_resize_heap,
		d: _proc_exit,
		i: _setImageData,
		g: _setLineData
	};
	async function run() {
		var _Module$onRuntimeInit;
		preRun();
		var setStatus = Module["setStatus"];
		if (setStatus) {
			setStatus("Running...");
			await new Promise((resolve) => setTimeout(resolve, 1));
			setTimeout(setStatus, 1, "");
		}
		if (ABORT) return;
		initRuntime();
		(_Module$onRuntimeInit = Module["onRuntimeInitialized"]) === null || _Module$onRuntimeInit === void 0 ? void 0 : _Module$onRuntimeInit.call(Module);
		postRun();
	}
	var wasmExports;
	wasmExports = createWasm();
	await run();
	;
	return Module;
}
export default JBig2;
